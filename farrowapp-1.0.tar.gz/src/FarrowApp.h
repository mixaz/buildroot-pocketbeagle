#pragma once
#ifdef WIN32
#define COMPILER_MSVC
#endif
#define NOMINMAX

#include "FarrowImageGrabber.h"
#include "FarrowUI.h"
#include "StackedTiffStorer.h"
#include "FarrowAppState.h"
#include "FarrowLog.h"
#include <memory>
#include <atomic>
#include "LoRaCommunicator.h"
#include "XMLSetupParser.h"

enum ERROR_CODE {
	NONE,
	LOW_BATTERY,
	LOW_DISK_SPACE
};

static const std::string SW_VERSION = "v0.17.000";


class FarrowApp
{
public:
	FarrowApp(int argC, char* argv[]); 
	~FarrowApp();
	bool update();
	void setNewState(FarrowAppState *newState);
	void tearDownGlobalLog();
	void ensureGlobalLogExists();
	static std::string getLoraXMLPath();
	FarrowImageGrabber *grabber = nullptr;

	FarrowUI *ui = nullptr;

	FarrowAppState *currentState = nullptr;

	XMLSetupParser::ConstantsFromXML constantsFromXML;

	int grabFrameIntervalMS;
	/*
	int grabFrameRate = 3;


	int stackDurationMinutes = 5;
	int minDiskSpace;
	bool outputIntermediateAnalysisVars = false;
	bool analyseImages = false;
	bool replaceTrackingLog = false;
	bool useSecondsInTif = true;

	bool saveImages = true;
	*/

	//StackedTiffStorer storer
	std::unique_ptr<LoRaCommunicator> loraCom;

	std::string dataPath;
    std::string logPath;
	std::string machinePath;
	std::string deviceSerialId;
	FarrowTimer appTimer;

	//Cached values
	int penNr_cached;
	int sowNr_cached;

	FarrowTimer batteryCheckTimer;
	void checkAndHandleBatteryState();

	//int getPigletCount() { return analyser == nullptr ? -1 : analyser->getPigletCount(); }
	
	//void setPigletCount(int newCount);
	
	void setCurrentSessionId(const std::string& sid)
	{
		std::unique_lock<std::mutex> guard(sessionMtx);
		currentSessionId = sid;
	}

	std::string getCurrentSessionId()
	{
		std::unique_lock<std::mutex> guard(sessionMtx);
		return currentSessionId;
	}

	static void receiveAnalysisResult(AnalysisResult aResult);
	FarrowImageAnalyser *getAnalyserPtr(bool newIfNull);
	std::string getCurrentDataFolder();
	static void receiveTime(Response timeResponse);
	void forceFinishAndCloseRecordingAndAnalysis();

	void stopUI() {
		continueUpdatingUI = false;
	}
	void incrementAccumImgCount() { accumImageCount += 1; }
	unsigned long long getAccumImgCount() { return accumImageCount.load(); }
	std::string getSubFolderOverride() { return subFolderOverride; }

	static std::atomic<int> errCode;
	static std::atomic<bool> timeUpdated;
	std::string getTensorFlowGraphName() { return tensorFlowGraphName; }

	void setBatteryLife(unsigned char life) { batteryLife = life; }
	unsigned char getBatteryLife() { return batteryLife; }
	bool getHasReceivedGatewayTime() { return hasReceivedGatewayTime.load(); }

private:
	std::atomic_bool hasReceivedGatewayTime {false};
	unsigned char batteryLife = 70;
	std::atomic_ullong accumImageCount;
	FarrowImageAnalyser *analyser = nullptr;
	std::string currentDataFolder;
	std::string logFilePath;
	std::vector<int> alarmIntervals;
	void setNewDataFolder();
	void setAnalysisPtr();
	//int accumulatedPiggletCount = 0;
	FarrowLog *globalLog = nullptr;
	
	volatile bool continueUpdatingUI = true;
	std::string subFolderOverride = "";

	std::mutex sessionMtx;
	std::string currentSessionId = "N/A";
	std::string tensorFlowGraphName = "None_Found";
};
