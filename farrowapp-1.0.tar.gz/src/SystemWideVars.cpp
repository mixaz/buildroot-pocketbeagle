#include "SystemWideVars.h"

std::recursive_mutex SystemWideVars::i2cLock;
