#include "HeadlessUI.h"
#include "FarrowApp.h"
#include "FarrowAppState_Running.h"
#include <algorithm> //for std::max
#include <iostream>
#ifdef WIN32
#include "../VSDeveloperDefines.h"
#endif

using namespace std;

HeadlessUI::HeadlessUI(FarrowApp& fA) : app(fA)
{
	UITimer.reset();
}


HeadlessUI::~HeadlessUI()
{
	uiRunning = false;
	AppLog::write("Headless UI destructed");
}
FarrowTimer fT;
bool newStateSet = false;
bool HeadlessUI::update()
{
	if (!hasStartedRunningState)
	{
		app.setNewState(new FarrowAppState_Running(app, true));
		hasStartedRunningState = true;
	}

#ifdef WIN32
	else if (readyForNewInput)
	{
		if (GetAsyncKeyState('R'))
		{
			app.setNewState(new FarrowAppState_Running(app, true));
		}
		else if (GetAsyncKeyState('S'))
		{
			app.setNewState(new FarrowAppState_StandBy(app));
		}
		else if (GetAsyncKeyState('U'))
		{
			app.setNewState(new FarrowAppState_UpdatePigletCount(app));
		}
	}
	//Only listen for input next frame if there  is no input this frame
	bool sPressed = GetAsyncKeyState('S');
	bool rPressed = GetAsyncKeyState('R');
	bool uPressed = GetAsyncKeyState('U');
	readyForNewInput = !sPressed && !uPressed && !rPressed;
#endif

	uint32_t mSecs = UITimer.getStopwatchRawTimeMS();
	uint32_t dsec = mSecs / 200;
	uint32_t secs = (std::max)(1u, mSecs / 1000);
	uint32_t grabbedCount = app.grabber->getGrabbedCount();
	int analysedImages = 0, enqueuedImages = 0, queueSize = 0;
	
	FarrowImageAnalyser *ana = app.getAnalyserPtr(false);
	if (ana != nullptr)
	{
		analysedImages = ana->getAnalysedCount();
		enqueuedImages = ana->getEnqueuedCount();
		queueSize = ana->getQueueSize();
	}

	if ((app.grabber->grabbingEnded() || secs > secForLastPrint) && (imgCountForLastPrint != grabbedCount || analysisCountForLastPrint != analysedImages))
	{
		secForLastPrint = secs;
		imgCountForLastPrint = grabbedCount;
		analysisCountForLastPrint = analysedImages;
		printf("\rImages (grabbed/enqueued/analysed): (%u,%u, %u), analysis rate: (%u) queue size: %u",
			app.grabber->getGrabbedCount(), enqueuedImages, analysedImages, analysedImages / secs, queueSize);
	}
	return true;
}

std::string HeadlessUI::getName()
{
	return "Headless";
}


bool HeadlessUI::hasStartedRunningState = false;

