#include "FarrowAppState.h"
#include "FarrowAppState_Running.h"
#include "CrossPlatform.hpp"
#include "FarrowApp.h"
#include "LoraRequestBuilder.h"
#include "StackedTiffStorer.h"
#include "hashids.h"
#include "tinyxml2.h"
#include <ostream>
#include <string>
#include <thread>

//Used for printing Lepton information upon Running State Start

#ifndef WIN32
#include <dirent.h>
#include <sys/time.h>
#include <stdlib.h>
#endif

#ifdef BEAGLE_BONE
#include "Lepton_I2C.h"
#endif


using namespace std;




////////////////////////////////////////////////
////////	B A S E   S T A T E     ////////////
////////////////////////////////////////////////

void FarrowAppState::setup()
{
	app.ui->clearDisplay(false);
}


void FarrowAppState::drawBattery()
{

	bool batteryBlinkCycleOn = displayBlinkCycle.getValue() > 0;

	int batteryLife = app.getBatteryLife();
	if (batteryLife < 10)
	{
		if (batteryBlinkCycleOnLastFrame != 
			batteryBlinkCycleOn)
		{
			if (batteryBlinkCycleOn)
				app.ui->clearBattery();
			else
				app.ui->drawBattery(batteryLife);
		}
	}
	else
	{
		app.ui->drawBattery(batteryLife);
	}

	batteryBlinkCycleOnLastFrame = batteryBlinkCycleOn;
}

std::string FarrowAppState::getTypeinNrString(int nr)
{
	string result = "";

	bool blinkIsOn = displayBlinkCycle.getValue() > 0;

	
	if (nr < 0)
	{
		result = blinkIsOn ? "_" : "";
	}
	else if (nr == 0)
	{
		result = blinkIsOn ? "_" : "0";
	}
	else
	{
		result = to_string(nr) + (blinkIsOn ? "_" : "");
	}

	return result;
}

bool FarrowAppState::update()
{
	int pressed = app.ui->getNumberPressed();

	static int lastPressed = -2;
	if (pressed != lastPressed)
	{
		//printf("Pressed: %i\n", pressed);
	}

	lastPressed = pressed;


	if (app.ui->getPressedSoftPowerDown())
	{
		app.setNewState(new FarrowAppState_SoftPowerDown(app));
		return false;
	}


	if (app.ui->getPressedLaser())
		app.ui->toggleLaser();

	if (hasTimeMode() && app.ui->getPressedTime())
	{
		showingTime = !showingTime;
		rePaint();
	}

	if (showingTime)
	{
		stringstream ss;
		chrono::system_clock::time_point timeNow = chrono::system_clock::now();
		auto now_t = chrono::system_clock::to_time_t(timeNow);
		tm* ltm = localtime(&now_t);

		if (ltm->tm_sec != lastSecondDisplayed)
		{
			lastSecondDisplayed = ltm->tm_sec;
			// Create date string
			if (ltm->tm_mday < 10)
				ss << 0;
			ss << ltm->tm_mday << "/";

			if (ltm->tm_mon + 1 < 10)
				ss << 0;
			ss << ltm->tm_mon + 1 << "/";

			ss << ltm->tm_year + 1900;
			string date = ss.str();

			// Create time string
			ss.str("");

			if (ltm->tm_hour < 10)
				ss << 0;
			ss << ltm->tm_hour << ":";

			if (ltm->tm_min < 10)
				ss << 0;
			ss << ltm->tm_min << ":";

			if (ltm->tm_sec < 10)
				ss << 0;
			ss << ltm->tm_sec;

			app.ui->setDisplayLine(date, 2);
			app.ui->setDisplayLine(ss.str(), 3);
		}
	}
	
	return true;
}



////////////////////////////////////////////////
////////	S T A N D B Y    ///////////////////
////////////////////////////////////////////////
bool testDigitsBool = false;
bool FarrowAppState_StandBy::update()
{
	inChargerLastNrFrames = app.ui->getIsInCharger() ? inChargerLastNrFrames + 1 : 0;

	if (inChargerLastNrFrames >= 10)
	{
		app.setNewState(new FarrowAppState_Charge(app));
		return true;
	}

	if (!pollingSignal && !inSleepMode.load() && !inSleepTransition.load())
	{
		if (!FarrowAppState::update()) {
			return true;
		}
	}

	if (showWaitFrGateway)
	{
		if (app.getHasReceivedGatewayTime() || waitForGatewayMsgTimer.getStopwatchRawTimeMS() >= 2000)
		{
			showWaitFrGateway = false;
			rePaint();
		}
		else
		{
			app.ui->clearDisplay(false);
			app.ui->setDisplayLine("WAITING", 1);
			app.ui->setDisplayLine("FOR", 2);
			app.ui->setDisplayLine("GATEWAY", 3);
			app.ui->setDisplayLine("TIME", 4);
		}
	}

	if (app.ui->getNumberPressed() == 3)
	{
		togglePollingSignalStrength();
		
		if (!pollingSignal.load())
			rePaint();
	}
	if (pollingSignal)
	{
		app.ui->clearDisplay(false);
		app.ui->setDisplayLine("SIGNAL: ", 2);
		string strengthString = (signalStrength == INT_MIN ? "_" : to_string(signalStrength)) + " db";

		strengthString = Util::padSomeStringsAtStart(strengthString, " ", 7);
		app.ui->setDisplayLine(strengthString, 3);
	}
	else
	{
		drawBattery();
	}
	
	if (app.ui->anyBtnPressed()) {
		timer_sincePress.reset();
	}
	
	try 
	{
		if (app.batteryCheckTimer.getStopwatchRawTimeMS() > 5 * 60 * 1000)
		{
			app.checkAndHandleBatteryState();
		}
		if (inSleepMode.load()) //If sleeping
		{
			if (app.ui->getPressedSoftPowerDown())
			{
				app.setNewState(new FarrowAppState_SoftPowerDown(app));
				return true;
			}
			else if (app.ui->anyBtnPressed())
			{
				transitionToFromSleep(false);
				return true;
			}
			else if (timer_sincePress.getStopwatchRawTimeMS() > 2 * 60 * 60 * 1000)  // Go to soft power down after 2 hours
			{
				app.setNewState(new FarrowAppState_SoftPowerDown(app));
				return true;
			}
		}
		else //If NOT sleeping
		{
			if (inSleepTransition)
			{
				app.ui->clearDisplay(false);
				app.ui->setDisplayLine("GOING", 1);

				app.ui->setDisplayLine("TO SLEEP", 2);
				int dotCount = framesSinceStartSleep++  % 8;
				app.ui->setDisplayLine(Util::padSomeStringsAtStart("_", " ", dotCount), 3);

				app.ui->setDisplayLine(Util::padSomeStringsAtStart("-", " ", camProgress % 8), 4);
			}

			else if (app.ui->getPressedStart())
			{
				if (app.getHasReceivedGatewayTime())
				{
					app.setNewState(new FarrowAppState_UpdatePigletCount(app));
					return true;
				}
				else
				{
					showWaitFrGateway = true;
					waitForGatewayMsgTimer.reset();
				}
			}
			else if (app.ui->getPressedSleep() || timer_sincePress.getStopwatchRawTimeMS() > 10 * 60 * 1000) // enter sleep mode after 10 mins
			{
				transitionToFromSleep(true);
				return true;
			}

			else if (app.ui->getPressedLoraTest())
			{
				/*
				auto ui = app.ui;
				app.loraCom->enqueRequest(LoraRequestBuilder::getSignalTestRequest([ui](std::string s) 
				{ 
					std::string eval = "TEST";

					if (s.substr(s.find_last_of(":") + 1, eval.length()) == eval)
					{
						ui->adaptToExpression(SIGNAL_LORA_TEST);
						AppLog::write("LoRa test response OK");
					}
					else
					{
						AppLog::write("Got wrong LoRa test response from gateway");
					}
				}));
				*/
			}
			else
			{
				app.loraCom->sendHeartbeat();
			}

		}

	}
	catch (int e)
	{
		AppLog::write(string("Got Exception during standby-update: ") + to_string(e));
	}

	return true;
}


void FarrowAppState_StandBy::rePaint()
{
	app.ui->clearDisplay(false);
	app.ui->drawTextCentered("READY");

}

void FarrowAppState_StandBy::setup()
{
	FarrowAppState::setup();

	/*
	app.loraCom->enqueRequest(LoraRequestBuilder::getGetTimeRequest("N/A", [](std::string s)
		{
			// Get the payload of response and remove newline at the end
			s = s.substr(s.find_last_of(":") + 1, s.length() - s.find_last_of(":") - 2);

			// Check if the time response is numbers only by trying to convert to long
			try
			{
				std::stoll(s);
			}
			catch (const std::exception & e)
			{
				AppLog::write("Time string did not only contain numbers, failed to adjust time");
				return;
			}

			// Date command doesn't take ms precision, remove last 3 digits
			std::string cmd = "/bin/date --set @" + s.substr(0, s.length() - 3);
			AppLog::write("Running system command: " + cmd);
			int returned = Util::executeCmdCrossPlatform(cmd);

			if (returned != 0)
			{
				AppLog::write("Failed to adjust time with command '" + cmd + "' | " + Util::strerror_r_cpp(returned));
				return;
			}

			FarrowApp::timeUpdated = true;
		}));

	app.loraCom->enqueRequest(LoraRequestBuilder::getHeartbeatRequest(app.ui->getBatteryStatus(), app.ui->getBatteryVoltage()));
	*/
	
	app.forceFinishAndCloseRecordingAndAnalysis();

	app.ui->setLEDValue(UIOutputType::LED_CODE__STATUS_G, 1);

	rePaint();
}


void FarrowAppState_StandBy::tearDown()
{
	pollingSignal.store(false);
	if (sleepTransitionThread.joinable())
		sleepTransitionThread.join();

	if (signalStrengthPollThread.joinable())
		signalStrengthPollThread.join();
}


void FarrowAppState_StandBy::transitionToFromSleep(bool toSleep)
{
	if (inSleepTransition.load())
		return;

	if (sleepTransitionThread.joinable())
		sleepTransitionThread.join();

	if (toSleep)
	{
		sleepTransitionThread = thread(&FarrowAppState_StandBy::enterSleep, this);
	}
	else
	{
		sleepTransitionThread = thread(&FarrowAppState_StandBy::exitSleep, this);
	}

}

void FarrowAppState_StandBy::togglePollingSignalStrength()
{
	bool willPoll = !pollingSignal.load();
	pollingSignal.store(willPoll);

	if (signalStrengthPollThread.joinable())
		signalStrengthPollThread.join();

	if(willPoll)
		signalStrengthPollThread = thread(&FarrowAppState_StandBy::pollSignalStrength, this);
}

void FarrowAppState_StandBy::pollSignalStrength()
{
	//The following two variables are made static to prevent null references when lambda callback is called from lora thread after state destruction
	static atomic_bool awaitingResponse{ false };

	static int signalStrengthReceived = INT_MIN;
	
	signalStrength = INT_MIN;

	auto pollResponseFnc = [&](Response response) {
		signalStrengthReceived = response.getSignalStrength();
		awaitingResponse.store(false);
	};

	while (pollingSignal.load())
	{
		if (awaitingResponse.load())
			CrossPlatform::threadSleep(50);
		else
		{
			signalStrength = signalStrengthReceived;
			
			app.loraCom->enqueRequest(LoraRequestBuilder::getHeartbeatRequest(pollResponseFnc));
			awaitingResponse.store(true);
		}
	}
}

void FarrowAppState_StandBy::enterSleep()
{
	try
	{
		app.ui->deployWaitMsg(this, "Enter sleep");
		lock_guard<mutex> lck(sleepTransitionMutex);
		framesSinceStartSleep = 0;
		inSleepTransition.store(true);

		//Set LED yellow while transitioning to sleep mode
		app.ui->setLEDValue(LED_CODE__STATUS_G, 1);
		app.ui->setLEDValue(LED_CODE__STATUS_R, 1);

		printf("Setting LEDs to off\n");
		app.ui->setLEDValue(LED_CODE__STATUS_G, 0);
		app.ui->setLEDValue(LED_CODE__STATUS_R, 0);

		//Set LED to OFF when in sleep mode
		printf("Setting display to off\n");
		CrossPlatform::threadSleep(1000);

		app.ui->deployWaitMsg(this, "Enter sleep");
		app.ui->setDisplayOnOff(false);
		printf("closing down cam\n");
		app.grabber->closeDown(); //Stop caemra - it will be automatically started when entering running mode again.
		inSleepMode.store(true);
		inSleepTransition.store(false);
		app.ui->toggleLaser(TOGGLE_OFF);

		app.ui->revokeWaitMsg(this);

	}
	catch (...)
	{
		printf("Caught exception in enter sleep loop\n");
	}
}

void FarrowAppState_StandBy::exitSleep()
{
	try
	{
		lock_guard<mutex> lck(sleepTransitionMutex);
		inSleepTransition.store(true);
		app.ui->setLEDValue(LED_CODE__STATUS_G, 1);


		app.ui->setDisplayOnOff(true);
		inSleepMode.store(false);
		inSleepTransition.store(false);
		rePaint();
		app.ui->toggleLaser(TOGGLE_ON);
	}
	catch (...)
	{
		printf("Caught exception in exit sleep loop\n");
	}
}

///////////////////////////////////////////////////////////////////////
////////	U P D A T E   P I G L E T   C O U N T    -  R I C H   /////
///////////////////////////////////////////////////////////////////////

void FarrowAppState_UpdatePigletCount::setup()
{
	FarrowAppState::setup();
	dataSession.steps.push_back({ { "TYPE SOW", "NUMBER:" }, "SOW", sowNr });
	dataSession.steps.push_back({ { "TYPE PEN", "NUMBER:" }, "PEN", penNr });
	dataSession.steps.push_back({ { "PIGLETS", "BORN:" }, "PIGS", pigletsBorn});
	app.ui->clearDisplay(false);
}


void FarrowAppState_UpdatePigletCount::finnishState()
{
	FarrowImageAnalyser* ana = app.getAnalyserPtr(true);

	ana->setPigletCount(pigletsBorn);
	ana->setSowNr(sowNr);
	ana->setPenNr(penNr);

	// TODO : this whole thing should only be written on successful confirmation, not on tear down ( which is called even if state terminates with error).
	try
	{
		std::string path = app.getCurrentDataFolder() + "countLog.txt";
		CrossPlatform::makeDirectory(app.getCurrentDataFolder());

		std::ofstream fs = std::ofstream(path, std::ios_base::out | std::ios_base::app);
		if (fs.is_open())
		{
			AppLog::write("Opened countLog succesfully");
			fs << Util::getTimeStampNow() << " ## ";
			fs << app.appTimer.convertMSToString(app.appTimer.getStopwatchRawTimeMS(), true, true) << " ## ";
			fs << "Session_start ## {" << "\"SowNr\":\"" + to_string(sowNr) + "\"" << ",";
			fs << "\"PenNr\":\"" << to_string(penNr) + "\"" << ",";
			fs << "\"Piglets_start\":\"" << std::to_string(pigletsBorn) + "\"" << ",";
			fs << "\"Time\":\"" << (FarrowApp::timeUpdated ? "true" : "false") << "\"" << ",";
			fs << "\"Session_ID\":\"" << ana->getSessionID() << "\"}" << "\n";
			fs.close();
		}

		if (fs.good())
		{
			AppLog::write("Successfully wrote logfile: " + app.getCurrentDataFolder() + "countLog.txt");
		}
		else
		{
			AppLog::write("Failed to write logfile: " + app.getCurrentDataFolder() + "countLog.txt");
		}
	}
	catch (const std::exception& e)
	{
		std::string tmp = "Caught exception while writing countLog.txt: " + std::string(e.what());
		AppLog::write(tmp);
	}
	app.setNewState(new FarrowAppState_Running(app, true));
}

bool FarrowAppState_UpdatePigletCount::update()
{
	if (!FarrowAppState::update()) {
		return true;
	}

	if (app.batteryCheckTimer.getStopwatchRawTimeMS() > 5 * 60 * 1000)
	{
		app.checkAndHandleBatteryState();
	}

	if (dataSession.update())
	{
		finnishState();
		return true;
	}
	
	app.loraCom->sendHeartbeat();
	return true;
}

//int FarrowAppState_UpdatePigletCount::sowNr = -1;
//int FarrowAppState_UpdatePigletCount::penNr = -1;


///////////////////////////////////////////////////////////////////////
////////	A S S I S T    S O W                          /////////////
///////////////////////////////////////////////////////////////////////

void FarrowAppState_AssistSow::setup()
{
	//Reset alarm (turn it off, but do not update birth time yet - this only if new pigs are assisted)
	app.getAnalyserPtr(true)->resetAlarm(false);
	FarrowAppState::setup();
	app.ui->drawTextCentered("PAUSED");

	app.grabber->finishGrabThreadBeforeDestruction();
}

void FarrowAppState_AssistSow::startRealAssist()
{
	dataSession.steps.push_back({ { "ASSISTED", "BIRTHS", "LIVE:" }, "LIVE", assistedLive });
	dataSession.steps.push_back({ { "ASSISTED", "BIRTHS", "DEAD:" }, "DEAD", assistedDead });
	app.loraCom->enqueRequest(LoraRequestBuilder::getAssistanceStartedEventRequest(app.getAnalyserPtr(true)->getPigletCount()));
	isPastPauseScreen = true;

	printf("Starting real assist\n");

	try
	{
		std::string path = app.getCurrentDataFolder() + "countLog.txt";
		CrossPlatform::makeDirectory(app.getCurrentDataFolder());

		std::ofstream fs = std::ofstream(path, std::ios_base::out | std::ios_base::app);
		if (fs.is_open())
		{
			AppLog::write("Opened countLog succesfully");
			fs << Util::getTimeStampNow() << " ## ";
			fs << app.appTimer.convertMSToString(app.appTimer.getStopwatchRawTimeMS(), true, true) << " ## ";
			fs << "Assistance_start ## " << "\n";
			fs.close();
		}

		if (fs.good())
		{
			AppLog::write("Successfully wrote logfile: " + app.getCurrentDataFolder() + "countLog.txt");
		}
		else
		{
			AppLog::write("Failed to write logfile: " + app.getCurrentDataFolder() + "countLog.txt");
		}
	}
	catch (const std::exception& e)
	{
		std::string tmp = "Caught exception while writing countLog.txt: " + std::string(e.what());
		AppLog::write(tmp);
	}
}

void FarrowAppState_AssistSow::endRealAssist()
{

	printf("Ending real assist\n");
	try
	{
		std::string path = app.getCurrentDataFolder() + "countLog.txt";
		CrossPlatform::makeDirectory(app.getCurrentDataFolder());

		std::ofstream fs = std::ofstream(path, std::ios_base::out | std::ios_base::app);
		if (fs.is_open())
		{
			AppLog::write("Opened countLog succesfully");
			fs << Util::getTimeStampNow() << " ## ";
			fs << app.appTimer.convertMSToString(app.appTimer.getStopwatchRawTimeMS(), true, true) << " ## ";
			fs << "Assistance_end ## {" << "\"Assisted_birth_live\":\"" + std::to_string(assistedLive) + "\"" << ",";
			fs << "\"Assisted_birth_dead\":\"" + std::to_string(assistedDead) + "\"}" << "\n";
			fs.close();
		}

		if (fs.good())
		{
			AppLog::write("Successfully wrote logfile: " + app.getCurrentDataFolder() + "countLog.txt");
		}
		else
		{
			AppLog::write("Failed to write logfile: " + app.getCurrentDataFolder() + "countLog.txt");
		}
	}
	catch (const std::exception& e)
	{
		std::string tmp = "Caught exception while writing countLog.txt: " + std::string(e.what());
		AppLog::write(tmp);
	}
	// TODO: reset birth time, if any pigs are born / helped during assist
	if (assistedLive > 0 || assistedDead > 0)
	{
		FarrowImageAnalyser* ana = app.getAnalyserPtr(true);
		ana->resetAlarm(true);
		ana->setPigletCount(ana->getPigletCount() + assistedLive + assistedDead);
	}
	app.loraCom->enqueRequest(LoraRequestBuilder::getAssistanceEndedEventRequest(assistedLive, assistedDead, app.getAnalyserPtr(true)->getPigletCount()));
	app.setNewState(new FarrowAppState_Running(app, false));
}


bool FarrowAppState_AssistSow::update()
{
	app.loraCom->sendHeartbeat();
	if (!isPastPauseScreen)
	{
		drawBattery();
		if(app.ui->getPressedOK() || app.ui->getPressedStart() || app.ui->getPressedAssist())
		{
			startRealAssist();
			return true;
		}
		else if (app.ui->getPressedBack())
		{
			//Just go back to running
			app.setNewState(new FarrowAppState_Running(app, false));
			return true;
		}
	}

	if (isPastPauseScreen)
	{
		if (dataSession.update())
		{
			endRealAssist();
			return true;
		}
	}
	
	return true;
}




////////////////////////////////////////////////////////
////////	R U N N I N G     E N D E D        /////////
////////////////////////////////////////////////////////
void FarrowAppState_RunningEnded::setup()
{
	dataSession.steps.push_back({ { "TOTAL BORN", "LIVE:" }, "LIVE", totalBornLive });
	dataSession.steps.push_back({ { "TOTAL BORN", "DEAD:" }, "DEAD", totalBornDead });
	app.getAnalyserPtr(true)->resetAlarm(true);
	stopRunningStateProcessesThread = thread(&FarrowAppState_RunningEnded::tearDownProcesses, this);
}

void FarrowAppState_RunningEnded::tearDown()
{
	if (stopRunningStateProcessesThread.joinable())
	{
		stopRunningStateProcessesThread.join();
	}
	if (!goingBackToRunningState)
	{
		app.ui->clearDisplay(true);
	
		app.loraCom->enqueRequest(LoraRequestBuilder::getRecordingEndedEventRequest(totalBornLive, totalBornDead));

		std::string path = app.getCurrentDataFolder() + "countLog.txt";
		CrossPlatform::makeDirectory(app.getCurrentDataFolder());

		std::ofstream fs = std::ofstream(path, std::ios_base::out | std::ios_base::app);
		if (fs.is_open())
		{
			AppLog::write("Opened countLog succesfully");
			fs << Util::getTimeStampNow() << " ## ";
			fs << app.appTimer.convertMSToString(app.appTimer.getStopwatchRawTimeMS(), true, true) << " ## ";
			fs << "Session_end ## {" << "\"Piglets_live\":\"" + std::to_string(totalBornLive) + "\"" << ",";
			fs << "\"Piglets_dead\":\"" + std::to_string(totalBornDead) + "\"" << ",";
			fs << "\"Automatic_count\":\"" + std::to_string(app.getAnalyserPtr(true)->getPigletCount()) + "\"}" << "\n";
			fs.close();
		}

		if (fs.good())
		{
			AppLog::write("Successfully wrote logfile: " + app.getCurrentDataFolder() + "countLog.txt");
		}
		else
		{
			AppLog::write("Failed to write logfile: " + app.getCurrentDataFolder() + "countLog.txt");
		}
		
		app.getAnalyserPtr(true)->deleteLitterLog();
	}
}

void FarrowAppState_RunningEnded::tearDownProcesses()
{
	tearDownProcessesDone.store(false);

	app.grabber->finishGrabThreadBeforeDestruction();

	if (instantiatedStorer != nullptr) // wait for storer to finnish writing - and then delete it
	{
		//app.ui->clearDisplay(false);
		//app.ui->setDisplayLine("SAVING", 1);
		//
		//app.ui->setDisplayLine("IMAGES", 2);
		//app.ui->update(); // Manually update ui to reflect changes to display
		while (instantiatedStorer->getIsWriting()) {
			CrossPlatform::threadSleep(100);
		};
		//app.ui->clearDisplay(false);
		//app.ui->update();  // Manually update ui to reflect changes to display
		delete instantiatedStorer;

	}
	
	tearDownProcessesDone.store(true);
}

bool FarrowAppState_RunningEnded::update()
{
	app.loraCom->sendHeartbeat();
	
	if (!dataSessionOver)
	{
		int sessionAtIndex = dataSession.getCurrentStepIndex();
		dataSessionOver = dataSession.update();
		
		if (!dataSessionOver)
		{
			if(sessionAtIndex == 0 && app.ui->getPressedBack())
			{
				dataSessionOver = true;
				goingBackToRunningState = true;
			}
		}

	}
	if (dataSessionOver)
	{
		if (tearDownProcessesDone.load())
		{
			if (goingBackToRunningState)
			{
				app.setNewState(new FarrowAppState_Running(app, false));
			}
			else
			{
				app.setNewState(new FarrowAppState_StandBy(app));
				return true;
			}
			
		}
		else
		{
			string dots = Util::padSomeStringsAtStart("", ".", (waitedFrames++/4) % 4 + 1);

			app.ui->clearDisplay(false);
			if (goingBackToRunningState)
			{
				app.ui->setDisplayLine("Continuing", 1);
				app.ui->setDisplayLine("Litter", 2);
				app.ui->setDisplayLine(string("Saving") + dots, 3);
			}
			else
			{
				app.ui->setDisplayLine("ENDING", 1);
				app.ui->setDisplayLine("RUNNING", 2);
				app.ui->setDisplayLine(string("MODE") + dots, 3);
			}

		}

	}
	
	return true;
}



////////////////////////////////////////////////
/////////   F A U L T   ////
////////////////////////////////////////////////

FarrowAppState_Fault::FarrowAppState_Fault(FarrowApp& fA) : FarrowAppState(fA)
{
	app.loraCom->enqueRequest(LoraRequestBuilder::getFaultEventRequest(0xFF));
}
bool FarrowAppState_Fault::update()
{
	app.loraCom->sendHeartbeat();
	if (!FarrowAppState::update()) {
		return true;
	}

	drawBattery();

	if (app.ui->getPressedStart())
			app.setNewState(new FarrowAppState_SoftPowerDown(app));
	
	return true;
}


void FarrowAppState_Fault::setup()
{
	FarrowAppState::setup();

	app.getAnalyserPtr(true)->resetAlarm(true);
	//app.loraCom->enqueRequest(LoraRequestBuilder::getFaultEventRequest(FarrowApp::errCode, app.getCurrentSessionId())); TODO: Remove line
}


void FarrowAppState_Fault::tearDown()
{
	/*
	if (app.getCurrentSessionId() != "N/A")
		app.loraCom->enqueRequest(LoraRequestBuilder::getFaultEndedEventRequest(FarrowApp::errCode, app.getLivePigletCount(), app.getDeadPigletCount(), app.getCurrentSessionId()));
	else
		app.loraCom->enqueRequest(LoraRequestBuilder::getFaultEndedEventRequest(FarrowApp::errCode));
	*/

}



////////////////////////////////////////////////////////
////////	S O F T   P O W E R   D O W N      /////////
////////////////////////////////////////////////////////

void FarrowAppState_SoftPowerDown::setup()
{
	FarrowAppState::setup();
	FarrowImageAnalyser* ana = app.getAnalyserPtr(false);
	
	app.forceFinishAndCloseRecordingAndAnalysis();
	app.loraCom->stop();
	app.ui->clearDisplay(false);
	app.ui->setDisplayLine("SHUTTING", 1);
	app.ui->setDisplayLine("DOWN", 2);
	//app.ui->clearDisplay(true);

	if (app.constantsFromXML.useLoraCom)
	{
		auto doc = app.loraCom->getQueuesAsXML();
		tinyxml2::XMLError err = doc->SaveFile(FarrowApp::getLoraXMLPath().c_str());
		AppLog::write("Saving LoRa requests in file: " + std::string(doc->ErrorName()));
	}

	app.ui->setDisplayOnOff(true);
	app.grabber->closeDown(); //Stop caemra - it will be automatically started when entering running mode again.
	app.ui->toggleLaser(TOGGLE_OFF);

}

bool FarrowAppState_SoftPowerDown::update()
{
	framesInState++;
	string dotStr = Util::padSomeStringsAtStart("-", " ", (framesInState / 10) % 8);

	app.ui->setDisplayLine(dotStr, 3);
	drawBattery();
	if (timer.getStopwatchRawTimeMS() > 2000)
	{
		printf("soft power down last update\n");

		app.ui->setDisplayOnOff(false);
		return false;
	}
	app.loraCom->sendHeartbeat();
	return true;
}

///////////////////////////////////
////////	C H A R G     /////////
///////////////////////////////////

void FarrowAppState_Charge::setup()
{
	inChargerLastFrame = app.ui->getIsInCharger();
	mountingUnmounting.store(true);

	mountThread = thread(&FarrowAppState_Charge::unMount, this);
	rePaint();
}

bool FarrowAppState_Charge::update()
{
	frameCount = (frameCount + 1) % 1000;

	//Handle state transition if we are fully ready to enter standby
	if (awaitingStandby)
	{
		if (fullyRemounted.load())
		{
			app.setNewState(new FarrowAppState_StandBy(app));
			return true;
		}
	}

	inChargerThisFrame = app.ui->getIsInCharger();
	bool mountUnmountThisFrame = mountingUnmounting.load();

	if(!inChargerThisFrame)
	{
		framesNotInCharger++;
	}
	else
	{
		framesNotInCharger = 0;
	}

	if (!mountingUnmounting.load())
	{
		//Flag that we go to stand by
		if (framesNotInCharger >= 20 && !awaitingStandby)
		{
			awaitingStandby = true;
			mountingUnmounting.store(true);
			
			if (mountThread.joinable())
				mountThread.join();

			mountThread = thread(&FarrowAppState_Charge::mount, this);
		}
	}

	if (inChargerThisFrame != inChargerLastFrame || !inChargerThisFrame || mountUnmountThisFrame != wasMountingUnmountingLastFrame)
	{
		rePaint();
	}

	inChargerLastFrame = inChargerThisFrame;
	wasMountingUnmountingLastFrame = mountUnmountThisFrame;
	return true;
}

void FarrowAppState_Charge::tearDown()
{
	if (mountThread.joinable())
		mountThread.join();
}

void FarrowAppState_Charge::rePaint()
{
	app.ui->clearDisplay(false);
	app.ui->setDisplayLine("CHARGING", 2);

	if (mountingUnmounting.load())
	{
		app.ui->setDisplayLine(awaitingStandby ? "Mounting" : "Unmounting", 2);
		app.ui->setDisplayLine("Drive", 3);
		app.ui->setDisplayLine(Util::padSomeStringsAtStart("-", " ", frameCount % 8), 4);
	}
	if (!inChargerThisFrame)
	{
		app.ui->setDisplayLine("UNPLUGGED", 3);
		app.ui->setDisplayLine(Util::padSomeStringsAtStart("-", " ", framesNotInCharger % 8), 4);
	}
	app.ui->update();
}

void FarrowAppState_Charge::mount()
{
	FarrowTimer fT;
	app.ui->deployWaitMsg(&fT, "mounitng");
#ifdef BEAGLE_BONE
	bool succeeded = false;

	if(!Util::executeCmdCrossPlatform("mount /dev/mmcblk0p2"))
	{
		AppLog::writef("Mounting drive failed");
		failString = "Mount fail";
	}
	else
	{
		while (fT.getStopwatchRawTimeMS() < 10000)
		{
			if(Util::executeCmdCrossPlatform("mountpoint -qd /mnt/mmcblk0p2")); //Returns true if mounted
			{
				succeeded = true;
				break;
			}
			CrossPlatform::threadSleep(1000);
		}
	}
#else
	bool succeeded = true;
#endif

	AppLog::writef("Mounting %s", succeeded ? "Succceeded" : "Failed due to timeout");
	app.ui->revokeWaitMsg(&fT);
	mountingUnmounting.store(false);
}

void FarrowAppState_Charge::unMount()
{
	FarrowTimer fT;
	app.ui->deployWaitMsg(&fT, "unmounitng");
#ifdef BEAGLE_BONE
	bool succeeded = false;
	if (!Util::executeCmdCrossPlatform("umount /mnt/mmcblk0p2")) 
	{
		AppLog::writef("un-Mounting drive failed");
		failString = "Unmount fail";
	}
	else
	{
		while (fT.getStopwatchRawTimeMS() < 10000)
		{
			if (!Util::executeCmdCrossPlatform("mountpoint -qd /mnt/mmcblk0p2")); //Returns true if mounted
			{
				succeeded = true;
				break;
			}
			CrossPlatform::threadSleep(1000);
		}
	}
#else
	bool succeeded = true;
#endif
	AppLog::writef("Unmounting %s", succeeded ? "Succceeded" : "Failed due to timeout");
	app.ui->revokeWaitMsg(&fT);
	mountingUnmounting.store(false);
	fullyRemounted.store(true);
}
