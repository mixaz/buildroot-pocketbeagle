#include "BeagleHardwareButton.h"
#include "device_drivers/TCA9555_cpp.hpp"
#include "FarrowLog.h"
#include "SystemWideVars.h"

using namespace std;

BeagleHardwareButton::BeagleHardwareButton(const int btn_id, TCA9555& tca9555, string name) : tca(tca9555)
{

	lock_guard<recursive_mutex> guard(SystemWideVars::i2cLock); // lock is set here, because it is not possible to set in BeagleUI as BeagleHardwarebuttons are initialised before BeagleUIs constructor is called
	buttonId = btn_id;
	btnName = name;
	if (btn_id >= 8 && btn_id <= 15)
	{
		btnRegister = TCA9555_INPUT1;
		configRegister = TCA9555_CONFIG1;
		polarityRegister = TCA9555_POL_INV1;
	}	

	tca.init();

	tca.changePin(configRegister, buttonId % 8, 1);
	tca.changePin(polarityRegister, buttonId % 8, 1);
}


BeagleHardwareButton::~BeagleHardwareButton()
{

}

void BeagleHardwareButton::update()
{
	if (!btnDownLastFrame)
	{
		buttonQuarantined_longPress = false;
		buttonQuarantined_veryLongPress = false;
	}
	btnDownLastFrame = btnDownThisFrame;

	int btnDownNow = 0;
	btnDownNow = tca.checkPin(btnRegister, buttonId % 8);
	
	
	if (btnDownNow && !btnDownLastFrame)
		btnDownTimer.reset();

	btnDownThisFrame = btnDownNow;

	calculateShortPress();
	calculateLongPress();
	calculateVeryLongPress();
}

bool BeagleHardwareButton::getIsShortPress()
{
	return _isShortPress;
}

bool BeagleHardwareButton::getIsLongPress()
{
	return _isLongPress;
}

bool BeagleHardwareButton::getIsVeryLongPress()
{
	return _isVeryLongPress;
}

void BeagleHardwareButton::calculateShortPress()
{
	_isShortPress = !buttonQuarantined_longPress && !btnDownThisFrame && btnDownLastFrame && btnDownTimer.getStopwatchRawTimeMS() > 80;
}

void BeagleHardwareButton::calculateLongPress()
{
	_isLongPress = !buttonQuarantined_longPress && btnDownThisFrame && btnDownTimer.getStopwatchRawTimeMS() > 2500;
	if (_isLongPress)
	{
		buttonQuarantined_longPress = true;
	}
}

void BeagleHardwareButton::calculateVeryLongPress()
{
	_isVeryLongPress = !buttonQuarantined_veryLongPress && btnDownThisFrame && btnDownTimer.getStopwatchRawTimeMS() > 7500;

	if (_isVeryLongPress)
	{
		buttonQuarantined_veryLongPress = true;
	}
}

