#include "GraphicUILED.h"
#include <opencv2/imgproc.hpp>

using namespace cv;

const int ledRadius = 42;
const int ledBlockHeight = 96;
int titleHeight = ledBlockHeight - ledRadius;

Rect ledRect(0, 0, ledRadius, ledRadius);
Rect titleRect(0, ledRadius, ledRadius, titleHeight);




GraphicUILED::GraphicUILED(const Mat& uiPanelMat, int graphicalIndex, std::string titel, Scalar color) :
	uiPanelMat(uiPanelMat), graphIndex(graphicalIndex), titel(titel), color(color)
{
	Rect totalRect(ledRadius * graphicalIndex * 1.5, 0, ledRadius, ledBlockHeight);

	ledBlockROI = Mat(uiPanelMat, totalRect);
	ledROI = Mat(ledBlockROI, ledRect);
	titleROI = Mat(ledBlockROI, titleRect);

	putText(titleROI, titel, Point(0, titleHeight - 5), FONT_HERSHEY_SIMPLEX, 0.4, Color::black);
	setValue(false);
}

GraphicUILED::~GraphicUILED()
{
}

void GraphicUILED::setValue(float value)
{
	ledROI.setTo(Color::black);

	Scalar ledColor = Color::grey * (1.0 - value) + color * value;//on ? color : Color::grey;

	circle(ledROI, Point(ledRadius * 0.5, ledRadius * 0.5), ledRadius * 0.5, ledColor, CV_FILLED);
}


Scalar Color::black(0);

Scalar Color::white(255, 255, 255);

Scalar Color::grey(128, 128, 128);

Scalar Color::blue(255, 0, 0);

Scalar Color::red(0, 0, 255);

Scalar Color::green(0, 255, 0);

Scalar Color::yellow(0, 255, 255);

Scalar Color::darkBlue(128, 0, 0);

Scalar Color::darkRed(0, 0, 128);

Scalar Color::darkGreen(0, 128, 0);
