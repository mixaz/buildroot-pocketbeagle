#include "StackedTiffStorer.h"
#include "CrossPlatform.hpp"
#include "FarrowTimer.h"
//#include "Magick++.h"
#include <iostream>	// for standard I/O (cout)
#include <tiffio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "tiffio.h"
#include "FarrowApp.h"
//#include "TiffWriter.h"
//#include <direct.h>

using namespace std;
using namespace cv;
//using namespace Magick;

FarrowTimer overallTimer;

std::map<int, std::string> StackedTiffStorer::lettersForInts;

StackedTiffStorer::StackedTiffStorer(FarrowApp& app, std::string dirPath) : dirPath(dirPath), app(app)
{
	for(int i = 0; i < 20; i++)
	{
		char c = (char) (i + 'a');
		char cA[2];
		cA[0] = c;
		cA[1] = '\0';

		lettersForInts[i] = string(cA);
	}

	overallTimer.reset();
	TIFFSetErrorHandler(&(StackedTiffStorer::handleTiffError));
}


StackedTiffStorer::~StackedTiffStorer(void)
{
	if(writeThread != nullptr)
	{
		app.ui->deployWaitMsg(this, "Tiff Writer");
		if (writeThread->joinable())
			writeThread->join();
		delete writeThread;
		app.ui->revokeWaitMsg(this);
	}
}

static bool isWriting = false;

bool StackedTiffStorer::getIsWriting()
{
	return isWriting;
}

void StackedTiffStorer::storeImagesAsStackedTiff(ImageAndMetaData *mats, int stackSize, bool useSecondsInFileName)
 {
	if (writeThread != nullptr)
	{
		AppLog::write("Writing tiff images - but awaiting that earlier write is completed.");
		
		if (writeThread->joinable())
			writeThread->join();
	}
	AppLog::writef("start writing stacked tiff of siz %i.", stackSize);
	writeThread = new thread(&StackedTiffStorer::writeTiff, mats, stackSize, useSecondsInFileName, dirPath);
}

void StackedTiffStorer::writeTiff(ImageAndMetaData *mats, int stackSize,
	bool useSecondsInFileName, string dirPath)
{
	try
	{
		isWriting = true;

		int timeSinclast = overallTimer.getStopwatchRawTimeMS() * 0.001;

		overallTimer.reset();


		FarrowTimer writeTimer;

		FarrowImageMetaData metadata0 = mats[0].metaData;

		//string secondsPart = useSecondsInFileName ? (padZerosAtStart(to_string(timeStamp0.seconds)) + "_") : "";

		string stackPath = dirPath + metadata0.stringTime + ".tif";

		AppLog::write("writing stacked tiff: " + stackPath);

		TIFF *tiff = TIFFOpen(stackPath.c_str(), "w");

		string frameTimeString = "";
		long long lastFrameTime = 0;

		//For each image On Stack
		for (int j = 0; j < stackSize; j++)
		{
			if (j != 0)
			{
				TIFFWriteDirectory(tiff);
				//printf("Writing dir: %i\n", j);
			}

			Mat cvImg = mats[j].image;

			FarrowImageMetaData imgMetaData = mats[j].metaData;

			long long frameTimeDif = lastFrameTime == 0 ? 0 : imgMetaData.rawTime - lastFrameTime;

			string rawTimeStr = to_string(frameTimeDif) + ",";

			lastFrameTime = imgMetaData.rawTime;

			frameTimeString += rawTimeStr;

			string comment = imgMetaData.dumpToString();

			TIFFSetField(tiff, TIFFTAG_PAGENUMBER, j, stackSize);
			TIFFSetField(tiff, TIFFTAG_SUBFILETYPE, FILETYPE_PAGE);

			if (comment != "")
			{
				int status = TIFFSetField(tiff, TIFFTAG_IMAGEDESCRIPTION, comment.c_str());
			}

			TIFFSetField(tiff, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);
			TIFFSetField(tiff, TIFFTAG_IMAGEWIDTH, cvImg.cols);
			TIFFSetField(tiff, TIFFTAG_IMAGELENGTH, cvImg.rows);
			TIFFSetField(tiff, TIFFTAG_SAMPLEFORMAT, SAMPLEFORMAT_UINT);

			TIFFSetField(tiff, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_MINISBLACK);

			int depth = cvImg.depth() == CV_16U ? 16 : 8;
			TIFFSetField(tiff, TIFFTAG_BITSPERSAMPLE, depth);
			TIFFSetField(tiff, TIFFTAG_SAMPLESPERPIXEL, 1);

			std::size_t stride = cvImg.cols * depth / 8;

			ushort val100 = depth == 16 ?
				cvImg.at<ushort>(25, 25) : cvImg.at<uchar>(25, 25);

			//printf("Writing image: %i with pixel 100: %i\n", j, val100);

			for (int y = 0; y < cvImg.rows; ++y) {
				int errCode = TIFFWriteScanline(tiff, (void *)(cvImg.data + y * stride), y, 0);

				if (errCode != 1)
				{
					AppLog::write("Error while writing Tiff scanline");
				}
			}
		}

		TIFFClose(tiff);


		int writeProcessDuration = writeTimer.getStopwatchRawTimeMS() * 0.001;


		std::string msg = "Done writing Tiff Stack of size %i. Process Time: " + to_string(writeProcessDuration) +
			". Grab Time: " + to_string(timeSinclast) + ".\n";

		AppLog::writef("Done writing Tiff Stack of size %i. Process Time: %i, grabTime: %i\n", stackSize, writeProcessDuration, timeSinclast);

		//Write frame Times
	/*	std::string frameTimesFilePath = dirPath + metadata0.stringTime + ".dat";
		std::ofstream frameTimeStream(frameTimesFilePath, ios_base::app);
		frameTimeStream << frameTimeString;
		frameTimeStream.flush();
		frameTimeStream.close();*/

		isWriting = false;
	}
	catch (const std::exception& e)
	{
		std::string tmp = "Caught exception while writing tiff file: " + std::string(e.what());
		AppLog::write(tmp);
		throw;
	}
}


void StackedTiffStorer::handleTiffError(const char *module, const char *fmt, va_list ap)
{
	char msg[1024];

	sprintf(msg, "LibTiffError:\n Module: %s,\nfmt: %s,\nap: %s\n", module, fmt, ap);

	AppLog::write(msg);
}

