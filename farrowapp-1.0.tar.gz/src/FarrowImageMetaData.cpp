#include "FarrowImageMetaData.h"
#include "json.hpp"
#include "FarrowTimer.h"


using namespace std;
using json = nlohmann::json;

string c_t_cpu = "t_cpu";
string c_t_fpa = "t_fpa";
string c_t_ext = "t_ext";
string c_t_aux = "t_aux";
string c_rawTime = "raw_time";
string c_stringTime = "string_time";
string c_ImageNr = "image_nr";

FarrowImageMetaData::FarrowImageMetaData()
{
}

long long rawTimeCounterForNonJsonMetadata = 0;
FarrowImageMetaData::FarrowImageMetaData(std::string jsonStr)
{
	try
	{
		json j = json::parse(jsonStr);

		t_fpa = j[c_t_fpa].get<string>();
	
		rawTime = j[c_rawTime];

		string s = j[c_stringTime];		//I have no idea why this temporary 's' variable has to be used. 
		stringTime = s;					//Assignment directly to the member does not work.�- Maybe this should be done with the above "get<>" method as well
														
	}
	catch (std::exception e)
	{
		rawTime = rawTimeCounterForNonJsonMetadata;
		rawTimeCounterForNonJsonMetadata += 5000;
		stringTime = FarrowTimer::convertMSToString(rawTime, true, true);
	
	}
}

FarrowImageMetaData::~FarrowImageMetaData()
{
}

std::string FarrowImageMetaData::dumpToString()
{
	json j;

	j[c_t_fpa] = t_fpa;
	j[c_rawTime] = rawTime;
	j[c_stringTime] = stringTime;
	j[c_ImageNr] = imgNr;

	return j.dump();
}
