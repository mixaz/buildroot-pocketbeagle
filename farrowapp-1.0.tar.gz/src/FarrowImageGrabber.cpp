#include "FarrowImageGrabber.h"
#include <chrono>
#include "FarrowApp.h"
#include <thread>
#include "FarrowLog.h"

using namespace std;
using namespace cv;
//using namespace std::chrono;

FarrowImageGrabber::FarrowImageGrabber(FarrowApp& app) : app(app)
{

	currentImageCount = 0;
}
FarrowImageGrabber::~FarrowImageGrabber(void)
{
	if (cameraSetupThread.joinable())
		cameraSetupThread.join();

	finishGrabThreadBeforeDestruction();
}
void FarrowImageGrabber::startGrabbing()
{
	//grabLoopRunningBoolMutex.lock();
	grabLoopRunning = true;
	//grabLoopRunningBoolMutex.unlock();
	AppLog::write("Start grabbing with: " + getName());

	if (!isSetup.load())
	{
		if (cameraSetupThread.joinable())
		{
			cameraSetupThread.join();
		}
		cameraSetupThread = thread(&FarrowImageGrabber::setupCamera, this);
	}
	std::unique_lock<mutex> lk(cameraSetupMutex);

	//printf("Running lepton 3 grabber internal loop");

	grabberThread = thread(&FarrowImageGrabber::internalGrabberLoop, this);
}

//Returns false if no new image is grabbed or if the internal front buffer is not assigned yet
bool FarrowImageGrabber::getLastGrabbed(ImageAndMetaData& lastImg)
{
	if (!isReady())
	{
		return false;
	}
	doubleBufferMutex.lock(); //Lock mutex for thread safety
	bool frontIsAssigned = currentImageCount > 0;
	
	if(frontIsAssigned)
	{
		lastImg = matDoubleBuffer.getFrontRef();
		setMetaDataNow(lastImg.metaData);
	}

	doubleBufferMutex.unlock();	//Unlock mutex because we are not using the object anymore

	return frontIsAssigned;
}

void FarrowImageGrabber::finishGrabThreadBeforeDestruction()
{
	//grabLoopRunningBoolMutex.lock();
	grabLoopRunning = false;
	//grabLoopRunningBoolMutex.unlock();
	AppLog::write("Finnishing grab thread");
	if(grabberThread.joinable()) //Joinable is a way to check if the thread is initialized at all
		grabberThread.join(); //Join thread to make maisn thread wait for grab thread to finish

	AppLog::write("Grab thread Finnished");
}

void FarrowImageGrabber::closeDown()
{
	finishGrabThreadBeforeDestruction();
	lock_guard<mutex> lock(cameraSetupMutex);
	isSetup.store(false);
	duringCloseDown.store(true);
	auto progressCB = [this]() {
		this->app.currentState->notifyCamProgress(true);
	};
	printf("Calling stop FNC\n");

	stopCameraFNC(progressCB);
	printf("Notifying cam progress\n");
	this->app.currentState->notifyCamProgress(false);
	duringCloseDown.store(false);
	printf("Notifying all\n");
	cv_cameraSetup.notify_all();
	printf("Notified all\n");
}

void FarrowImageGrabber::assignMatToDoubleBuffer(ImageAndMetaData& m)
{
	if(!m.image.empty())
	{

		matDoubleBuffer.getBackRef() = m;
		doubleBufferMutex.lock();
		matDoubleBuffer.swap();
		currentImageCount ++;
		doubleBufferMutex.unlock();
		
	}
}

void FarrowImageGrabber::setMetaDataNow(FarrowImageMetaData& fM)
{
	fM.imgNr = imageNr++;
	chrono::system_clock::time_point timeNow = std::chrono::system_clock::now();
	fM.rawTime = std::chrono::duration_cast<std::chrono::milliseconds>(timeNow.time_since_epoch()).count();
	
	auto now_t = std::chrono::system_clock::to_time_t(timeNow);
	tm *ltm = localtime(&now_t);
	char timeStr[64];
	sprintf(timeStr, "%.4i_%.2i_%.2i_%.2i_%.2i_%.2i", ltm->tm_year + 1900, ltm->tm_mon +1, ltm->tm_mday, ltm->tm_hour, ltm->tm_min, ltm->tm_sec);
	fM.stringTime = timeStr;

	fM.t_fpa = 99;
}

void FarrowImageGrabber::internalGrabberLoop()
{
	try
	{
		std::unique_lock<mutex> lk(cameraSetupMutex);
		while (grabLoopRunning)
		{
			cv_cameraSetup.wait(lk, [this] {
				return this->isReady(); });

			grabberLoopUpdate();

			CrossPlatform::threadSleep(20);
		}
	}
	catch (...)
	{
		printf("Caught exception in grabber loop\n");
	}
}

void FarrowImageGrabber::setupCamera()
{
	try
	{

		lock_guard<mutex> lock(cameraSetupMutex);
		isSetup.store(false);

		auto progressCB = [this]() {
			app.ui->deployWaitMsg(this, "Camera");
			this->app.currentState->notifyCamProgress(true);
		};

		setupCameraFNC(progressCB);
		this->app.currentState->notifyCamProgress(false);
		isSetup.store(true);

		app.ui->revokeWaitMsg(this);
		cv_cameraSetup.notify_all();
	}
	catch (...)
	{
		printf("Caught exception in camera setup\n");
	}
}

int FarrowImageGrabber::imageNr = 1;

