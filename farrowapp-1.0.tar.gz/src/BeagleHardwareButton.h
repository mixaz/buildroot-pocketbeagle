#pragma once
#include "FarrowTimer.h"
#include "device_drivers/TCA9555_cpp.hpp"
class BeagleHardwareButton
{
public:
	BeagleHardwareButton(const int btn_id, TCA9555& tca9555, std::string name = "");
	~BeagleHardwareButton();
	void update();
	bool getIsShortPress();
	bool getIsLongPress();
	bool getIsVeryLongPress();

	FarrowTimer btnDownTimer;
	std::string btnName;

private:

	void calculateShortPress();
	void calculateLongPress();
	void calculateVeryLongPress();
	int buttonId;
	unsigned char btnRegister = 0x00;
	unsigned char configRegister = 0x06;
	unsigned char polarityRegister = 0x04;
	bool btnDownLastFrame = false;
	bool btnDownThisFrame = false;
	bool buttonQuarantined_longPress = false;

	bool buttonQuarantined_veryLongPress = false;

	bool _isShortPress = false;
	bool _isLongPress = false;
	bool _isVeryLongPress = false;

	TCA9555& tca;
};

