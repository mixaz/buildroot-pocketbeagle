#ifndef TemperatureSensor
#define TemperatureSensor

float readExtTemperature(char* devPath);

void getPathExtTempSensor(char* devPath);

#endif
