// FarrowApp.cpp : Defines the entry point for the console application.

//Standard c++
//#include "stdafx.h"
#include <iostream>
#include <stdio.h>
#include <thread>
#ifdef WIN32
#include <tchar.h>
#endif

#include "FarrowApp.h"
#include "FarrowAppState.h"
#include "FarrowImageMetaData.h"
#include "FarrowLog.h"
#include "FarrowTimer.h"
#include "FarrowUI.h"
#include "LoRaCommunicator.h"
#include "LoraRequestBuilder.h"
#include "StackedTiffStorer.h"
#include "tiffio.h"
#include "tinyxml2.h"
#include "XMLSetupParser.h"
#include "DockerTfUtils.h"

//OpenCV stuff
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>


#ifdef BEAGLE_BONE
#include "PinManager.h"
#include "LoraRequestBuilder.h"
#include "Lepton_I2C.h"
#include "PRU_Test/PRU_test.h"
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#endif // BEAGLE_BONE

#include "Lepton3Grabber.h"
#include <chrono>

using namespace std;
using namespace std::chrono;
using namespace cv;

#define WIRINGPI_CODES = 1;

//using json = nlohmann::json;

// set static variables
std::atomic<int> FarrowApp::errCode{ NONE };
std::atomic<bool> FarrowApp::timeUpdated{ false };

FarrowApp *instantiatedFarrowApp = nullptr;

FarrowApp::FarrowApp(int argC, char* argv[])
{
	appTimer.reset();
	if (argC > 1)
	{
		subFolderOverride = argv[1];
	}

	//webCom.GetData();
	//webCom.SendData();
	instantiatedFarrowApp = this;

	accumImageCount.store(0);

	//obtain static paths
	std::string execPath = CrossPlatform::getExecDir();
	deviceSerialId = CrossPlatform::getDeviceId();

	printf("Paths and serial retrieval done after %llu msecs\n", appTimer.getStopwatchRawTimeMS());

	//////////////////////////////////////////////////////////////////////////
	//Load setup xml-file as it will affect where everything else is located
	////////////////////////////////////////////////////////////////////////// 
	std::vector<std::string> graphNameFiles = CrossPlatform::getFiles(CrossPlatform::getExecDir() +
		"ExecutableSupport" + CrossPlatform::getFolderDelimiter() + "servegraph" + CrossPlatform::getFolderDelimiter() + "1", ".graph");

	if (graphNameFiles.size() > 0)
	{
		tensorFlowGraphName = CrossPlatform::getFilenameFromPath(graphNameFiles[0]);
	}


	string xmlLocation = execPath + "ExecutableSupport/FarrowSetup.xml";
	//If on linux - try to modify permissions on xml file
#ifndef WIN32
	int mode = 0777;
	chmod(xmlLocation.c_str(), mode);
#endif


	std::queue<Request> temp;

	auto doc = make_unique<tinyxml2::XMLDocument>();
	tinyxml2::XMLError err;
	int bufferedLoraRequestsFound = 0;
	try
	{
		if ((err = doc->LoadFile(getLoraXMLPath().c_str())) == tinyxml2::XMLError::XML_SUCCESS)
		{
			tinyxml2::XMLElement* loraElem;

			if ((loraElem = doc->FirstChildElement("root")->FirstChildElement("lorarequests")) != nullptr)
			{
				AppLog::write("loading previously stored / queued LORA requests");
				tinyxml2::XMLElement* requestElem = loraElem->FirstChildElement();
				while (requestElem != nullptr)
				{
					bufferedLoraRequestsFound += 1;
					Request r = Request(requestElem->Attribute("data"));
					string cmdType = "";
					if (r.getCommandTypeHex(cmdType))
					{
						AppLog::write("Stored Request loaded of type: " + cmdType);
						temp.push(r);
					}
					else
					{
						AppLog::write("Could not infer command type from request with data: " + r.data);
					}
					requestElem = requestElem->NextSiblingElement();
				}
			}

			loraCom = std::unique_ptr<LoRaCommunicator>(new LoRaCommunicator(*this, temp));
		}
		else
		{
			loraCom = std::unique_ptr<LoRaCommunicator>(new LoRaCommunicator(*this));
		}
	}
	catch (const std::exception & e)
	{
		AppLog::write("Failed to load stored LoRa requests from file: " + std::string(e.what()));
		loraCom = std::unique_ptr<LoRaCommunicator>(new LoRaCommunicator(*this));
	}

	printf("Lora com setup after %llu msecs and %i buffered requests\n", appTimer.getStopwatchRawTimeMS(), bufferedLoraRequestsFound);

	

	unique_ptr<tinyxml2::XMLDocument> xDoc = XMLSetupParser::loadXMLfromFile(xmlLocation, 5);

	if (xDoc->Error())
	{
		AppLog::write("Error reading FarrowSetup.xml in the ExecutableSupport directory error: " + string(xDoc->ErrorName()) + " - exiting\n(Sometimes restart of app solves this)");
		exit(0);
	}
	else
	{
		AppLog::write("Successfully read XML-file ");
	}

	tinyxml2::XMLElement *rootElem = xDoc->FirstChildElement("root");
	
	XMLSetupParser::parseToConstants(rootElem, constantsFromXML);

	printf("use lora: %s\n", constantsFromXML.useLoraCom ? "YES" : "NO");
	loraCom->setActive(constantsFromXML.useLoraCom);
	//////////////////////////////////////////////////////////////////////////
	//Set paths based on xml
	//////////////////////////////////////////////////////////////////////////
	//parent

	std::string logParentPath = (CrossPlatform_isBeagleBone ? "/mnt/mmcblk0p2/" : execPath);

	//data
	//CrossPlatform::ensureDirExists("data", dataParentPath);
	CrossPlatform::ensureDirExists("data", logParentPath);

	logPath = logParentPath + "data" + crossPlatformFolderDelimiter;

	//Machine-specific
	CrossPlatform::ensureDirExists(deviceSerialId, logPath);

	machinePath = logPath + deviceSerialId + crossPlatformFolderDelimiter;

	logFilePath = machinePath + "applog.txt";
	
	if(constantsFromXML.useGlobalAppLog)
		ensureGlobalLogExists();

	printf("Logs and directories created after %llu msecs\n", appTimer.getStopwatchRawTimeMS());
	AppLog::write("\n\n#################	Starting App	#################\n");

	
	// Check modification timestamps of FarrowApp and servegraph
	struct stat attr;
	stat((execPath + "/FarrowApp").c_str(), &attr);
	AppLog::write("FarrowApp last modified: " + std::string(ctime(&attr.st_mtime)));

	stat((execPath + "/servegraph/1/saved_model.pb").c_str(), &attr);
	AppLog::write("Graph last modified: " + std::string(ctime(&attr.st_mtime)));

	//////////////////////////////////////////////////////////////////////////
	// Set Constants
	//////////////////////////////////////////////////////////////////////////

	grabFrameIntervalMS = 1000 / constantsFromXML.grabFrameRate;

	int framesPrStack = constantsFromXML.grabFrameRate * 60 * constantsFromXML.stackDurationMinutes;

	//Setup UI from XML
	vector<FarrowUI *> uis = XMLSetupParser::parseToUIs(rootElem, *this);

	if (uis.size() == 0)
	{
		AppLog::write("No ui added to app - exiting");
		exit(0);
	}

	ui = uis[0];
	AppLog::write("UI of type '" + ui->getName() + "' added to app");

	printf("Parsed UIs after %llu msecs\n", appTimer.getStopwatchRawTimeMS());


	//Setup grabber from XML
	vector<FarrowImageGrabber *> grabbers = XMLSetupParser::parseToGrabbers(rootElem, *this);

	if (grabbers.size() == 0)
	{
		AppLog::write("No grabbers added to app - exiting");
		exit(0);
	}

	printf("Grabber created after %llu msecs\n", appTimer.getStopwatchRawTimeMS());

	grabber = grabbers[0];
	AppLog::write("Grabber of type '" + grabber->getName() + "' added to app");

	ui->toggleLaser(TOGGLE_ON);


	if (constantsFromXML.requireGatewayTime)
	{
		hasReceivedGatewayTime.store( false);

		loraCom->enqueRequest(LoraRequestBuilder::getGetTimeRequest(FarrowApp::receiveTime));
	}
	else
	{
		hasReceivedGatewayTime.store(true);
	}
}

FarrowApp::~FarrowApp()
{
	instantiatedFarrowApp = nullptr;
	
	if (grabber != nullptr)
	{
		delete grabber;
		grabber = nullptr;
	}

	if (currentState != nullptr)
	{
		delete currentState;
		currentState = nullptr;
	}

	if (ui != nullptr)
	{
		delete ui;
		ui = nullptr;
	}

	if (analyser != nullptr)
	{
		delete analyser;
		analyser = nullptr;
	}

	tearDownGlobalLog();

	AppLog::stopFileWriteLoop();

}


bool FarrowApp::update()
{

	bool continuing = true;
	
	if (currentState != nullptr)
	{
		//printf("State Update\n");
		continuing = currentState->update() && continuing;
	}

	if (ui != nullptr)
	{
		//printf("UI Update\n");
		FarrowTimer uiUpdateTimer;
		continuing = ui->update() && continuing;
		if (uiUpdateTimer.getStopwatchRawTimeMS() > 300) {
			AppLog::write("ui Update: " + to_string(uiUpdateTimer.getStopwatchRawTimeMS()));
		}
	}


	return continuing;
}


void FarrowApp::setNewState(FarrowAppState *newState)
{

	string oldName = "none";
	if (currentState != nullptr) {
		oldName = currentState->name();
		currentState->tearDown();
		delete currentState;
	}

	currentState = newState;

	string msg = "Changed state from " + oldName + " to " + currentState->name() + "\n";
	AppLog::write(msg);
	currentState->setup();
}

void FarrowApp::tearDownGlobalLog()
{
	if (globalLog != nullptr)
	{
		//AppLog::deregisterLog(globalLog);
		delete globalLog;
		globalLog = nullptr;
	}
}

void FarrowApp::ensureGlobalLogExists()
{
	if (globalLog == nullptr)
	{
		globalLog = new FarrowLog(logFilePath, appTimer, true);

		//AppLog::registerLog(globalLog);
	}
}

std::string FarrowApp::getLoraXMLPath()
{
#ifdef BEAGLE_BONE
	return "/root/requests.xml";
#else
	return CrossPlatform::getExecDir() + "requests.xml";
#endif
}

void FarrowApp::checkAndHandleBatteryState()
{
	batteryCheckTimer.reset();
	unsigned char batteryValue = ui->getBatteryLevelPercent();
	setBatteryLife(batteryValue);
	LoraRequestBuilder::setBattteryLevel(batteryValue);

	double batteryVolt = ui->getBatteryVoltage();
	AppLog::write("Battery life: " + std::to_string(batteryValue) + "% Battery voltage: " + std::to_string(batteryVolt));
	if (constantsFromXML.lowBatShutdown)
	{
		if (batteryVolt < 3.1)
		{
			AppLog::write("Low battery, changing to fault state");
			FarrowApp::errCode = ERROR_CODE::LOW_BATTERY;
			setNewState(new FarrowAppState_Fault(*this));
		}
	}
}




void FarrowApp::receiveAnalysisResult(AnalysisResult aResult)
{
	AppLog::write("App received analysis result: " + to_string(aResult));
	FarrowImageAnalyser* ana = instantiatedFarrowApp->getAnalyserPtr(true);
	if (aResult == BIRTH_RESULT)
	{

		instantiatedFarrowApp->loraCom->enqueRequest(LoraRequestBuilder::getBirthDetectedEventRequest(ana->getPigletCount()));
		AppLog::write("Birth detected");
		
		ana->ProduceReport();

	}
	else if (aResult == BIRTH_PLACENTA)
	{
		instantiatedFarrowApp->loraCom->enqueRequest(LoraRequestBuilder::getPlacentaDetectedEventRequest(ana->getPigletCount()));
	}
}


void FarrowApp::setNewDataFolder()
{
	//Do not perform operation, if there is nothing to be saved anyway. - this is to prevent empty folders
	if (!constantsFromXML.analyseImages && !constantsFromXML.saveImages)
		return;

	if (grabber->getSpecialRunningLogPath() != "")
	{
		currentDataFolder = grabber->getSpecialRunningLogPath() + crossPlatformFolderDelimiter;
	}
	else
	{
		vector<string> matchingImageDirs = CrossPlatform::getDirs(machinePath, "Litter_");

		//printf("Checking directories\n");
		short highestNr = 0;
		for (string dir : matchingImageDirs)
		{
			size_t length = dir.length();
			string subStr = dir.substr(length - 3, 3);
			short nr = stoi(subStr);
			highestNr = max(highestNr, nr);
		}

		//printf("Done checking directories\n");
		char newestDirName[11];
		sprintf(newestDirName, "Litter_%.3i", highestNr + 1);

		currentDataFolder = machinePath + newestDirName + crossPlatformFolderDelimiter;
	}
}

void FarrowApp::setAnalysisPtr()
{
	analyser = new FarrowImageAnalyser(FarrowApp::receiveAnalysisResult, *this, constantsFromXML.alarmIntervals);
}

FarrowImageAnalyser *FarrowApp::getAnalyserPtr(bool newIfNull)
{
	if (analyser == nullptr)
	{
		if (newIfNull)
		{
			setAnalysisPtr();
		}
	}

	return analyser;
}


std::string FarrowApp::getCurrentDataFolder()
{
	return currentDataFolder;
}


void FarrowApp::receiveTime(Response timeResponse)
{
	auto timeBefore = system_clock::now();
	time_t tBefore = system_clock::to_time_t(timeBefore);
	char *timeBeforeString = asctime(gmtime(&tBefore));
	AppLog::writef("Before Receiving time from Lora Gateway - system time is: %s", timeBeforeString);
	unsigned long gatewayTime = timeResponse.getUnixTime();
	duration<long> gatewayDur(gatewayTime);

	time_point<system_clock> gatewayTimePoint(gatewayDur);

	time_t tGateway = system_clock::to_time_t(gatewayTimePoint);
	char *timeGatewayString = asctime(gmtime(&tGateway));

#ifdef BEAGLE_BONE
	if (stime(&tGateway) == 0)
	{
		auto timeNow = system_clock::now();
		time_t tNow = system_clock::to_time_t(timeNow);
		printf("Set time succeeded to %s gateway time:%s\n", asctime(gmtime(&tNow)), timeGatewayString);
	}
	else
	{
		printf("Setting System time to seconds: %lu string: %s failed with error: %s\n", gatewayTime, asctime(gmtime(&tGateway)), strerror(errno));
	}
#else
	AppLog::writef("Received Time from Lora Gateway: %lu: %s", timeResponse.getUnixTime(), timeGatewayString);
#endif

	instantiatedFarrowApp->hasReceivedGatewayTime.store(true);
}

void FarrowApp::forceFinishAndCloseRecordingAndAnalysis()
{
	if (analyser != nullptr)
	{
		ui->deployWaitMsg(this, "analysis end");
		analyser->ProduceReport();
		analyser->resetAlarm(false);
		delete analyser;
		analyser = nullptr;
	}
		ui->revokeWaitMsg(this);
	setNewDataFolder();
}

int main(int argc, char* argv[])
{
// 	unsigned long gatewayTime = 100000;
// 	duration<long> gatewayDur(gatewayTime);
// 
// 	time_point<system_clock> gatewayTimePoint(gatewayDur);
// 
// 	time_t tGateway = system_clock::to_time_t(gatewayTimePoint);
// 	printf("Test time: %lu is %s\n", gatewayTime, asctime(gmtime(&tGateway)));
// 

	//bool valid = Util::isHexString("00000001FFsAF");

	FarrowTimer fT;

#ifdef BEAGLE_BONE
	PinManager::setupAllPins();
#endif
FarrowApp f(argc, argv);

	AppLog::write("\nSoftware version: " + SW_VERSION + "\n");


#ifdef BEAGLE_BONE
	if (f.ui->getIsInCharger())
	{
		f.setNewState(new FarrowAppState_Charge(f));
	}
	else
	{
		f.setNewState(new FarrowAppState_StandBy(f));
	}
#else
	f.setNewState(new FarrowAppState_StandBy(f));
#endif

	f.checkAndHandleBatteryState();

	////////////////////////////////////////////////////////////
	////////	A P P     M A I N    L O O P            ////////
	////////////////////////////////////////////////////////////
	for (;;)
	{
		try
		{
			if (!f.update()) {
				f.stopUI();
				break;
			}
		}
		catch (Exception* e)
		{
			printf("Caught exception in farrowApp\n");
			f.stopUI();
			
			string excMsg = e->what();
			std::string msg = "Caught an exception: " + excMsg + "\n - exiting in 2 seconds\n";
			AppLog::write(msg);
			CrossPlatform::threadSleep(2000);
			break;

		}
		catch (...)
		{
			printf("Caught something\n");
		}
		CrossPlatform::threadSleep(f.currentState->isLowPowerState() ? 100 : 1);

	}

	try
	{
		f.loraCom->stop();
		auto doc = f.loraCom->getQueuesAsXML();
		tinyxml2::XMLError err = doc->SaveFile(FarrowApp::getLoraXMLPath().c_str());
		AppLog::write("Saving LoRa requests in file: " + std::string(doc->ErrorName()));


		f.ui->clearDisplay(true);


#ifdef WIN32
		printf("Final sleep\n");
		CrossPlatform::threadSleep(1000);
		printf("Final sleep Over\n");
#endif
	}
	catch (Exception* e)
	{
		string excMsg = e->what();

		std::string msg = "Caught an exception in program exit: " + excMsg + "\n";
		AppLog::write(msg);
	}
	return 0;
}
