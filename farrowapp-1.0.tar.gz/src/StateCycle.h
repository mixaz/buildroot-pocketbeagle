#pragma once
#include "FarrowTimer.h"

typedef enum _CycleShape {
	SQUARE
} CycleShape;

class StateCycle
{
public:
	StateCycle(int periodMS = 1000, CycleShape shape = CycleShape::SQUARE, float min =  0, float max = 1) :
		periodMS(periodMS), halfPeriod(periodMS * 0.5), inversePeriod(1.0/ periodMS),
		doubleInversePeriod(2.0 / periodMS), shape(shape), minValue(min),
		scale(max - min){};
	virtual ~StateCycle() {};

	float getValue();

	void setFreqMultiplier(float factor, int durationMS);
private:
	float inversePeriod;
	float doubleInversePeriod;
	unsigned long long multiplyUntil = 0;
	float multiplyFactor = 1;
	int periodMS;
	int halfPeriod;
	float minValue;
	float scale;
	CycleShape shape;
	FarrowTimer timer;


};

