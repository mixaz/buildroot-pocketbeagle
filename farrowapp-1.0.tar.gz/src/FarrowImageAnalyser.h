#pragma once
#include "FarrowImageMetaData.h"
#include "FarrowTimer.h"
#include "Alexandra.h"
#include "FarrowLog.h"
#include <thread>
#include <queue>
#include <atomic>

enum AnalysisResult {NORMAL_RESULT, RISK_RESULT, HIGH_RISK_RESULT, BIRTH_RESULT, BIRTH_PLACENTA, OTHER_RESULT};

class FarrowApp;

//enum event {BIRTH};

/*
struct Settings; 
struct SimpleTracker;
struct GraphPlot;
*/
class FarrowImageAnalyser
{
public:
	FarrowImageAnalyser(void(*receiveResultCallback)(AnalysisResult result), FarrowApp &app, std::vector<int> birthAlarmIntervals);

	~FarrowImageAnalyser();
	void update();
	void EnqueueFOrAnalysis(ImageAndMetaData& iAMD, std::string origin, bool forceAnalyseNow);
	int getQueueSize() { return analysisQueueSize; }
	float GetTimeSinceLastBirthSecs();
	void transmitResult(AnalysisResult result);
	void ProduceReport();
	std::atomic_llong imagesEnqueued;
	FarrowImageMetaData lastAnalysedMetaData;
	std::vector<FarrowImageMetaData> birthMetaData;
	volatile long long lastBirthRawTime = 0;
	void resetLastBirthTime() { lastBirthRawTime = 0; }
	int getPigletCount() { return accumulatedPigletCount; }

	//int getPigletCountLive() { return pigletCountLive; }

	//int getPigletCountDead() { return pigletCountDead; }

	int getPenNr() { return penNr; }
	int getSowNr() { return sowNr; }

	int getSessionID() { return sessionID; }
	void setPenNr(int newNr) { penNr = newNr; }
	void setSowNr(int newNr) { sowNr = newNr; }

	void setPigletCount(int newCount);
	void resetAlarm(bool updateLastBirthTime);
	bool getIsAlarmed() { return isAlarmed; }
	int getAnalysedCount() { return imagesAnalysed; }
	int getEnqueuedCount() { return imagesEnqueued; }
	void createLogsWithPath(std::string path, FarrowTimer timer);
	FarrowLog *getLitterLog() { return litterLog; }
	void deleteLitterLog();
private:
	void AnalyseImageAndMetadata(std::tuple<ImageAndMetaData, std::string> iAMDAndOrigin);
	//std::condition_variable checkDockerRunningCondVar;
	//std::mutex checkDockerRunningCondMutex;
	
	Settings pigletSettings;
	volatile int imagesAnalysed = 0;
	FarrowLog* litterLog = nullptr;
	FarrowLog *trackingVarsLogLog = nullptr;
	FarrowLog *replacedTrackingLog = nullptr;
	void setAlarm();
	void setBirthMetaData(FarrowImageMetaData fIM);
	FarrowApp &app;
	void(*receiveResult)(AnalysisResult result);
	
	float lastFPATemp = 0;
	int analysisQueueSize = 0;
	int getAllowedIntervalForCurrentBirth();
	long long timeForLastImage = 0;
	std::vector<int> birthAlarmIntervals;
	
	//State of current litter
	int sowNr;
	int penNr;
	int accumulatedPigletCount = 0;
	int sessionID;
	//int pigletCountLive = 0;
	//int pigletCountDead = 0;
	bool isAlarmed = false;
	static void receiveAnalysisEvent(event e);

	static void printIntermediateTrackingVars(TrackingVars tV);
	static void printToReplacedTrackingLog(std::string msg);
	static void handleTrackerError(std::string errorMsg);
	// Filter to modify image values
	cv::Mat imMatFilter; // Contains values 0 to 255
	
	//Analysis queue
	std::queue<std::tuple<ImageAndMetaData, std::string>> analysisQueue;
	std::mutex analysisMutexLock;
	int queueMax = 10000;

	std::thread analysisThread;

	void analysisLoop();

	std::atomic_bool forceStartRestartDockerContainer;

	volatile bool analysisLoopIsRunning{ false };

	void finishAnalysisThreadBeforeDestruction();

};

