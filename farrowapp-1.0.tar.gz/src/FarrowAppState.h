#pragma once
#include "StackedTiffStorer.h"
#include "DoubleBuffer.hpp"
#include "FarrowImageAnalyser.h"
#include "StateCycle.h"
#include "DataInsertion.h"

class FarrowApp;

class FarrowAppState
{
public:
	FarrowAppState(FarrowApp& fA) : app(fA) {};
	
	virtual ~FarrowAppState() {};
	virtual void registerCamHardReset() {};
	virtual bool update();
	virtual void setup();
	virtual void tearDown() {};
	virtual std::string name() = 0;

	virtual bool isLowPowerState() { return false; }

	virtual void notifyCamProgress(bool inProgress) { camProgress = inProgress ? camProgress + 1 : 0; }
	virtual bool hasTimeMode() { return false; }

	virtual void rePaint() {};
protected:
	//Classes for holding a generic data insertion session
	void drawBattery();

	std::string getTypeinNrString(int nr);
	FarrowApp& app;

	StateCycle displayBlinkCycle;
	bool batteryBlinkCycleOnLastFrame = false;
	bool showingTime = false;
	int camProgress = 0;
private:
	int lastSecondDisplayed = -1;
};

////////////////////////////////////////////////
////////	S T A N D B Y    ///////////////////
////////////////////////////////////////////////
class FarrowAppState_StandBy : public FarrowAppState
{
public:
	FarrowAppState_StandBy(FarrowApp& fA) : FarrowAppState(fA) {}
	virtual ~FarrowAppState_StandBy() {};

	virtual bool update() override;

	virtual void rePaint() override;

	virtual std::string name() override { return "standBy"; };

	virtual void setup() override;

	virtual void tearDown() override;

	virtual bool isLowPowerState() override { return true; }



	virtual bool hasTimeMode() override { return true; }

private:
	int inChargerLastNrFrames = 0;
	void transitionToFromSleep(bool toSleep);
	void togglePollingSignalStrength();
	void pollSignalStrength();
	void enterSleep();
	void exitSleep();
	FarrowTimer timer_sincePress;

	std::mutex sleepTransitionMutex;
	std::thread sleepTransitionThread;
	std::thread signalStrengthPollThread;
	std::atomic_bool inSleepTransition{ false };

	std::atomic_bool inSleepMode{ false };

	std::atomic_bool pollingSignal{ false };
	int framesSinceStartSleep = 0;

	int signalStrength = INT_MIN;

	bool showWaitFrGateway = false;
	FarrowTimer waitForGatewayMsgTimer;
};


///////////////////////////////////////////////////////////////////////
////////	U P D A T E   P I G L E T   C O U N T    R I C H      /////////////
///////////////////////////////////////////////////////////////////////

class FarrowAppState_UpdatePigletCount : public FarrowAppState
{
public:
	enum SubState { TYPEIN_SOW_NR = 0, TYPEIN_PEN_NR = 1, TYPEIN_PIGLETS_BORN = 2 };

	FarrowAppState_UpdatePigletCount(FarrowApp& fA) :FarrowAppState(fA), dataSession(app) {};

	virtual ~FarrowAppState_UpdatePigletCount() {}


	virtual std::string name() override { return "Update Piglet Count - Rich"; };

	virtual void setup() override;

	void finnishState();
	virtual bool update() override;
private:
	DataInsertionSession dataSession;
	int sownNr_cached;
	int penNr_cached;

	//Static to "cache" them between different runs
	/*static */int sowNr = -1;
	/*static */int penNr = -1;
	int pigletsBorn = 0;
	SubState currentSubState = TYPEIN_SOW_NR;

};


///////////////////////////////////////////////////////////////////////
////////	A S S I S T    S O W                          /////////////
///////////////////////////////////////////////////////////////////////

class FarrowAppState_AssistSow : public FarrowAppState
{
public:
	enum SubState { PAUSED = 0, TYPEIN_ASSISTED_LIVE = 1, TYPEIN_ASSISTED_DEAD = 2 };

	FarrowAppState_AssistSow(FarrowApp& fA) : FarrowAppState(fA), dataSession(app) {};

	virtual std::string name() override { return "Assist Sow"; }

	virtual bool update() override;

	virtual void setup() override;

	void startRealAssist();
	void endRealAssist();

	

private:
	int assistedLive = 0;
	int assistedDead = 0;
	bool isPastPauseScreen = false;
	DataInsertionSession dataSession;
};

///////////////////////////////////////////////////////////////////////
////////	R U N N I N G     E N D E D                   /////////////
///////////////////////////////////////////////////////////////////////

class FarrowAppState_RunningEnded : public FarrowAppState
{
public:
	enum SubState { TYPEIN_BORN_LIVE = 0, TYPEIN_BORN_DEAD = 1 };

	FarrowAppState_RunningEnded(FarrowApp& fA, StackedTiffStorer *storer) :
		FarrowAppState(fA), dataSession(app), instantiatedStorer(storer) {}
	virtual std::string name() override { return "Running Ended"; }

	virtual bool update() override;

	virtual void setup() override;


	virtual void tearDown() override;

private:
	int waitedFrames = 0;
	bool goingBackToRunningState = false;
	bool dataSessionOver = false;
	void tearDownProcesses();
	StackedTiffStorer* instantiatedStorer = nullptr;
	int totalBornLive = 0;
	int totalBornDead = 0;
	DataInsertionSession dataSession;
	SubState currentSubState = TYPEIN_BORN_LIVE;
	std::thread stopRunningStateProcessesThread;
	std::atomic_bool tearDownProcessesDone{ true };

};


////////////////////////////////////////////////
////////	F A U L T         //////
////////////////////////////////////////////////

class FarrowAppState_Fault : public FarrowAppState
{
public:
	FarrowAppState_Fault(FarrowApp& fA);
	virtual ~FarrowAppState_Fault() {};

	virtual std::string name() override { return "Fault"; };

	virtual bool update() override;

	virtual void setup() override;

	virtual void tearDown() override;

private:
	FarrowTimer timer;

	int startCount = 0;

};


////////////////////////////////////////////////////////
////////	S O F T   P O W E R   D O W N      /////////
////////////////////////////////////////////////////////

class FarrowAppState_SoftPowerDown : public FarrowAppState
{
public:
	FarrowAppState_SoftPowerDown(FarrowApp& fA) : FarrowAppState(fA) {};
	virtual ~FarrowAppState_SoftPowerDown() {};

	virtual std::string name() override { return "Soft Power Down"; };

	virtual void setup() override;
	virtual bool update() override;

private:
	FarrowTimer timer;
	bool displayIsCleared = false;
	int framesInState = 0;
};


////////////////////////////////////////////////
////////	T R A N S F E R     ////////////////
////////////////////////////////////////////////

class FarrowAppState_DataTransfer : public FarrowAppState
{
public:
	FarrowAppState_DataTransfer(FarrowApp& fA) : FarrowAppState(fA) {}
	virtual ~FarrowAppState_DataTransfer();

	virtual std::string name() override { return "Transfer"; };

	virtual void setup() override;

	virtual void tearDown() override;
private:
	static void transferData(FarrowApp& fA);

	virtual bool update() override;

	std::thread* writeThread = nullptr;

};

////////////////////////////////////
////////	C H A R G E    /////////
////////////////////////////////////

class FarrowAppState_Charge : public FarrowAppState
{
public:
	FarrowAppState_Charge(FarrowApp& fA) : FarrowAppState(fA) {};
	virtual ~FarrowAppState_Charge() {};

	virtual std::string name() override { return "Charge"; };

	virtual void setup() override;
	virtual bool update() override;


	virtual void tearDown() override;


	virtual void rePaint() override;

	virtual bool isLowPowerState() override { return true; }

private:
	void mount();
	void unMount();
	int frameCount;
	std::atomic_bool mountingUnmounting{ false };
	std::atomic_bool fullyRemounted{ false };
	bool awaitingStandby = false;
	std::string failString;
	std::thread mountThread;
	int framesNotInCharger = 0;
	bool inChargerThisFrame = true;
	bool wasMountingUnmountingLastFrame = false;
	bool inChargerLastFrame = false;
	const int updatesWithoutPower = 10;
};

