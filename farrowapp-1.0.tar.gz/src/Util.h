#pragma once
#include <string>
#include <algorithm>
#include <chrono>
#include <atomic>
#include <mutex>
#include <ios>

class Util
{
public:
	Util();
	~Util();


	static std::string padSomeZerosAtStart(std::string s, int length = 2)
	{
		return padSomeStringsAtStart(s, "0", length);
	}

	static std::string padSomeStringsAtStart(std::string s, std::string padStr, int length = 2)
	{
		if (s.size() < length)
		{
			int originalSize = s.size();

			for (int i = 0; i < (length - originalSize); i++)
			{
				s = padStr + s;
			}
		}
		return s;
	}

	static std::string trim(const std::string& str, char trimChar)
	{
		size_t first = str.find_first_not_of(trimChar);
		if (std::string::npos == first)
		{
			return str;
		}
		size_t last = str.find_last_not_of(trimChar);
		return str.substr(first, (last - first + 1));
	}

	static void convertStringToLower(std::string& str)
	{
		std::transform(str.begin(), str.end(), str.begin(), ::tolower);


	}

	static std::string getTimeStampNow(const std::chrono::time_point<std::chrono::system_clock>& timePointNow, bool delimitWith_ = false);
	static std::string getTimeStampNow(bool delimitWith_ = false);

	
	static std::string strerror_r_cpp(int err);

	static bool executeCmdCrossPlatform(const std::string &cmd, std::string& result);

	static bool executeCmdCrossPlatform(const std::string& cmd);

	static bool isHexString(const std::string& str);

	static std::string hexPadded(int value, int width);

	static unsigned long getULongFromHex(const std::string& hexStr, bool has0xPrefix = false);

	static int appendDigit(int original, int digit);

	static int popDigit(int original, int defaultVal = -1);

private:
	static bool executeCmdCrossPlatform(const std::string& cmd, std::string& result, bool useResult);
};

// C utility functions

#ifdef __cplusplus
extern "C"
{
#endif
	static void strerror_r_improved(int err, char* str, size_t str_len);
#ifdef __linux__
	static int executeExternalLinuxProgram(char** params);	
#endif // __linux__
#ifdef __cplusplus
}
#endif
