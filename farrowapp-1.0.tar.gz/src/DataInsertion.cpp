#include "FarrowApp.h"
#include <string>
#include "DataInsertion.h"

using namespace std;

const int stepBackWaitMS = 0;
const int stepAheadWaitMS = 0;
const int phaseSteps = 11;
/// Will rturn true if entire session has completed and value references are updated - otherwise false
bool DataInsertionSession::update()
{
	//Handle transitions between sub states
	if (stepWaitTimer.getStopwatchRawTimeMS() < transitionUntil)
	{
		int phaseStep = phaseSteps - (transitionUntil - stepWaitTimer.getStopwatchRawTimeMS()) / transitionPhaseStepDuration;

		for (int i = 0; i < steps[transitionedFromIndex].messageLines.size(); i++)
		{
			//Make string long enough 
			string orig = steps[transitionedFromIndex].messageLines[i];
			while (orig.length() <= phaseSteps)
			{
				orig += " ";
			}

			string forwardString = orig.substr(phaseStep, phaseSteps - phaseStep);

			string backwardString = orig;
			for (int j = 0; j < phaseStep; j++)
			{
				backwardString = " " + backwardString;
			}
			backwardString = backwardString.substr(0, phaseSteps);
			app.ui->setDisplayLine(lastTransitionWasForward ? forwardString : backwardString, i + 1);
		}
		return false;
	}

	if (showingSummary)
	{
		if (app.ui->getPressedOK() || app.ui->getPressedStart() || app.ui->getPressedAssist())
		{
			for (auto st : steps)
			{
				st.editedValue = st.value;
			}
			return true;
		}
		else if(app.ui->getPressedBack())
		{
			transition(false);

			return false;
		}
		else if(!showedSummaryLastFrame)
		{
			for (int i = 0; i < steps.size(); i++)
			{
				string lineText = steps[i].summaryLine + ": " + to_string(steps[i].value);
				app.ui->setDisplayLine(lineText, i + 2);
			}
			showedSummaryLastFrame = true;
		}
		string line1Text = displayBlinkCycle.getValue() > 0 ? "CORRECT" : "CORRECT ?";
		app.ui->setDisplayLine(line1Text, 1);
	}
	else
	{
		showedSummaryLastFrame = false;

		DataInsertionStep& currentStep = steps[currentStepIndex];

		int pressedNr = app.ui->getNumberPressed();

		if (pressedNr != lastKeyPressed)
		{
			//printf("UI pressed nr: %i\n", pressedNr);
			lastKeyPressed = pressedNr;
		}

		if (app.ui->getPressedBack())
		{
			if (currentStep.value <= 0) //If 0 - step back to previous state if possible
			{
				if (currentStepIndex > 0) // is there a previous state
				{
					transition(false);
					return false;
				}
				else //Or flash cursor to signal no previous state
				{
					flashCursor();
				}
			}
			else
			{
				currentStep.value = Util::popDigit(currentStep.value);
			}
		}
		else if (app.ui->getPressedOK() || app.ui->getPressedStart() || app.ui->getPressedAssist())
		{
			if (currentStep.value >= 0)
			{
				//If last step - set value references to new values and return true to signal session complete
				if (currentStepIndex == steps.size() - 1)
				{

					transition(true);
					return false;
				}
				else
				{
					transition(true);
					return false;
				}
			}
			else //Flash if value is not 0 or above
			{
				flashCursor();
			}
		}

		else if (pressedNr >= 0)
		{
			currentStep.value = currentStep.value <= 0 ? pressedNr : Util::appendDigit(currentStep.value, pressedNr);
		}

		string newInputLine = getTypeinNrString(currentStep.value);

		//Only update UI if things have changed
		if (newInputLine != lastInputLine || lastStepIndex != currentStepIndex)
		{
			lastStepIndex = currentStepIndex;
			lastInputLine = newInputLine;
			for (int i = 0; i < currentStep.messageLines.size(); i++)
			{
				app.ui->setDisplayLine(currentStep.messageLines[i], i + 1);
			}
			app.ui->setDisplayLine(newInputLine, currentStep.messageLines.size() + 1);
		}
	}

	return false;
}

void DataInsertionSession::flashCursor()
{
	displayBlinkCycle.setFreqMultiplier(5, 1000);
}

void DataInsertionSession::transition(bool isForward)
{
	transitionedFromIndex = currentStepIndex;

	bool wasShowingSummary = showingSummary;
	showingSummary = currentStepIndex == steps.size() - 1 && isForward;

	if (!wasShowingSummary && !showingSummary && currentStepIndex <= steps.size() - 1)
	{
		currentStepIndex += isForward ? 1 : -1;
	}

	app.ui->setDisplayLine("", 1);
	app.ui->setDisplayLine("", 2);
	app.ui->setDisplayLine("", 3);
	app.ui->setDisplayLine("", 4);
	int durationMS = isForward ? stepAheadWaitMS : stepBackWaitMS;

	lastTransitionWasForward = isForward;
	transitionPhaseStepDuration = durationMS / phaseSteps;
	transitionUntil = stepWaitTimer.getStopwatchRawTimeMS() + durationMS;
}

string DataInsertionSession::getTypeinNrString(int nr)
{
	string result = "";

	bool blinkIsOn = displayBlinkCycle.getValue() > 0;


	if (nr < 0)
	{
		result = blinkIsOn ? "_" : "";
	}
	else if (nr == 0)
	{
		result = blinkIsOn ? "_" : "0";
	}
	else
	{
		result = to_string(nr) + (blinkIsOn ? "_" : "");
	}

	return result;
}
