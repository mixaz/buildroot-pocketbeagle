#include "FarrowAppState_Running.h"
#include "CrossPlatform.hpp"
#include "FarrowApp.h"
#include "LoraRequestBuilder.h"
#include "StackedTiffStorer.h"
#include "hashids.h"
#include "tinyxml2.h"
#include <ostream>
#include <string>

//Used for printing Lepton information upon Running State Start

#ifndef WIN32
#include <dirent.h>
#include <sys/time.h>
#include <stdlib.h>
#endif

#ifdef BEAGLE_BONE
#include "Lepton_I2C.h"
#endif


using namespace std;
////////////////////////////////////////////////
////////	R U N N I N G    ///////////////////
////////////////////////////////////////////////

void FarrowAppState_Running::setup()
{
	FarrowImageAnalyser* ana = app.getAnalyserPtr(true);
	FarrowAppState::setup();
	if (isNewLitter)
	{
		app.grabber->resetImageNumber();
	}

	int diskSpaceMBs = CrossPlatform::getAvailableDiskSpace() / 1024;
	AppLog::write("Free disk space: " + to_string(diskSpaceMBs) + " MB");

	if (diskSpaceMBs == -1)
	{
		AppLog::write("Error Retrieving available diskspace from system");
	}
	if (diskSpaceMBs < 5000)
	{
		AppLog::write("Warning: Low available disk space: " + to_string(diskSpaceMBs) + " MB");
	}
	if (app.constantsFromXML.saveImages && diskSpaceMBs < app.constantsFromXML.minDiskSpace)
	{
		AppLog::write("Aborting runmode during setup, due to insufficient disk space.");
		FarrowApp::errCode = ERROR_CODE::LOW_DISK_SPACE;
		app.setNewState(new FarrowAppState_Fault(app));
		return;
	}


	//app.ui->adaptToExpression(SIGNAL_STATE_RUNNING);
	/////////////////////////////////////////////////////////////////////////////////
	//Iterate through existing dir names and create a new on with a higher number.///
	/////////////////////////////////////////////////////////////////////////////////

	stateRecordsImages = app.grabber->allowSaving() && app.constantsFromXML.saveImages;

	framesPrStack = app.constantsFromXML.stackDurationMinutes * 60 * app.constantsFromXML.grabFrameRate;
	std::string dataFolder = app.getCurrentDataFolder();

	CrossPlatform::makeDirectory(dataFolder);

	if (app.constantsFromXML.analyseImages && isNewLitter)
	{
		ana->createLogsWithPath(dataFolder, app.appTimer);
		ana->getLitterLog()->write("Recording session using server graph name: " + app.getTensorFlowGraphName());
	}

	//AppLog::registerLog(runningModeLog);

	if (stateRecordsImages)
	{
		storer = new StackedTiffStorer(app, dataFolder);

		imagesAndMeta.assignBack(new ImageAndMetaData[framesPrStack]);
		imagesAndMeta.assignFront(new ImageAndMetaData[framesPrStack]);
	}

	countInImageStack = 0;

	//app.ui->addLEDCycle(StateCycle(500, CycleShape::SQUARE), LED_CODE_START);

	if (app.grabber != nullptr)
		app.grabber->startGrabbing();

	rePaint();

	app.ui->toggleLaser(TOGGLE_OFF);

	if (isNewLitter)
	{
		app.loraCom->enqueRequest(LoraRequestBuilder::getRecordingStartedEventRequest(ana->getPigletCount(), ana->getSowNr(), ana->getPenNr()));
	}
}

void FarrowAppState_Running::tearDown()
{	
	if (app.grabber != nullptr)
	{
		app.grabber->finishGrabThreadBeforeDestruction();
	}


	if (storer != nullptr)
	{
		imagesAndMeta.swap();

		outputReport();

		storer->storeImagesAsStackedTiff(imagesAndMeta.getFrontRef(), countInImageStack, true);

		//app.ui->clearDisplay(false);
		//app.ui->setDisplayLine("SAVING", 1);
		//
		//app.ui->setDisplayLine("IMAGES", 2);
		//app.ui->update(); // Manually update ui to reflect changes to display
		//while (storer->getIsWriting()) {};
		//app.ui->clearDisplay(false);
		//app.ui->update();  // Manually update ui to reflect changes to display
		//delete storer;

	}

	

	//AppLog::write("Running mode tear down over");
}

int FarrowAppState_Running::getMinutesSinceBirth()
{
	return app.getAnalyserPtr(true)->GetTimeSinceLastBirthSecs() / 60;
}

void FarrowAppState_Running::outputReport()
{
	stringstream reportStream;

	reportStream << "\n";
	reportStream << "////////////////////////////////////////////////////////////\n";
	reportStream << "////////// Q U A L I T Y   R E P O R T    //////////////////\n";
	reportStream << "////////////////////////////////////////////////////////////\n";

	auto fTimes = app.grabber->getFrameTimeEvents();
	reportStream << "////   ABNORMAL FRAME TIMES: " << fTimes.size() << "\n";

	for (auto& fTE : fTimes) {
		reportStream << fTE << "\n";
	}
	
	/*
	auto sRTimes = app.grabber->getSPITimeEvents();
	reportStream << "////   ABNORMAL SPI READ TIMES: " << sRTimes.size() << "\n";

	for (auto& sTE : sRTimes) {
		reportStream << sTE << "\n";
	}
	*/
	
	reportStream << "////////////////////////////////////////////////////////////\n";
	reportStream << "////////// Q U A L I T Y   R E P O R T   O V E R   /////////\n";
	reportStream << "////////////////////////////////////////////////////////////\n";

	app.grabber->resetTimers();
	AppLog::write(reportStream.str());
}


void FarrowAppState_Running::registerCamHardReset()
{
	imgCount = 0;
}



void FarrowAppState_Running::rePaint()
{
	bool isAlarmed = app.getAnalyserPtr(true)->getIsAlarmed();

	if (!app.grabber->isReady())
	{
		
		app.ui->clearDisplay(false);
		app.ui->setDisplayLine("CAM SETUP", 1);
		app.ui->setDisplayLine("PLEASE", 2);
		app.ui->setDisplayLine("WAIT", 3);
		app.ui->setDisplayLine(Util::padSomeStringsAtStart("-", " ", camProgress % 8), 4);
	}
	else if (isAlarmed)
	{
		app.ui->clearDisplay(false);
		app.ui->setDisplayLine("ASSISTANCE", 1);
		app.ui->setDisplayLine("REQUIRED", 2);
		app.ui->setDisplayLine(to_string(getMinutesSinceBirth()) + " MIN", 3);
	}
	else
	{
		app.ui->clearDisplay(false);
		app.ui->setDisplayLine("CA " + to_string(app.getAnalyserPtr(true)->getPigletCount()) + " PIGS", 1);
		app.ui->setDisplayLine(to_string(getMinutesSinceBirth()) + " MIN", 3);
	}
	drawBattery();
}

bool FarrowAppState_Running::update()
{
	//printf("Running mode update\n");
	FarrowAppState::update();
	
	app.loraCom->sendHeartbeat();
	
	bool isAlarmed = false;

	if (app.batteryCheckTimer.getStopwatchRawTimeMS() > 5 * 60 * 1000)
	{
		app.checkAndHandleBatteryState();
			
		//app.loraCom->enqueRequest(LoraRequestBuilder::getHeartbeatRequest(app.ui->getBatteryStatus(), app.ui->getBatteryVoltage(), app.getCurrentSessionId()));
	}

	unsigned long long timeNow = timer.getStopwatchRawTimeMS();

	unsigned long long  timeSInceLastFrame = timeNow - lastImageGrabMillis;

	//AppLog::write("Get Frame ID");

	FarrowImageAnalyser *fIA = app.getAnalyserPtr(true);
	fIA->update();
		
	if (timeSInceLastFrame > app.grabFrameIntervalMS)
	{
		ImageAndMetaData iAMD;

		if (app.grabber->getLastGrabbed(iAMD))
		{
			
			lastImageGrabMillis = timeNow;

			
			lastLedFlashState = !lastLedFlashState;
			
			app.ui->setLEDValue(LED_CODE__STATUS_G, lastLedFlashState);

			if (app.ui != nullptr)
			{
				app.ui->updateGrabberImages(iAMD);
			}
			if (stateRecordsImages)
			{
				app.incrementAccumImgCount();
				iAMD.metaData.imgNr = app.getAccumImgCount();
				imagesAndMeta.getBackRef()[countInImageStack].image = iAMD.image;
				imagesAndMeta.getBackRef()[countInImageStack].metaData = iAMD.metaData;
				countInImageStack++;
					
				//If stack is full swap the stack
				if (countInImageStack == framesPrStack)
				{
					int diskSpaceMBs = CrossPlatform::getAvailableDiskSpace() / 1024;
					AppLog::write("Free disk space: " + to_string(diskSpaceMBs) + " MB");
					if (diskSpaceMBs == -1)
					{
						AppLog::write("Error Retrieving available diskspace from system");
					}
					if (app.constantsFromXML.saveImages && diskSpaceMBs < 100)
					{
						AppLog::write("Aborting runmode, due to insufficient disk space.");
						FarrowApp::errCode = ERROR_CODE::LOW_DISK_SPACE;
						app.setNewState(new FarrowAppState_Fault(app));
						return true;
					}

					countInImageStack = 0;

					//Mat **justFinishedStack = activeImageStack;

					//activeImageStack = activeImageStack == imageStackA ? imageStackB : imageStackA;
					imagesAndMeta.swap();

					outputReport();
					//app.ui->addLEDCycle(StateCycle(100, CycleShape::SQUARE), LED_CODE_START);
					storer->storeImagesAsStackedTiff(imagesAndMeta.getFrontRef(), framesPrStack, true);
					//storer.storeImagesAsStackedTiff(justFinishedStack, currentImages.size(), timeStamps, framesPrStack);
				}

			}
				
			if (app.constantsFromXML.analyseImages)
			{
				if (fIA != nullptr)
				{
					fIA->EnqueueFOrAnalysis(iAMD, app.grabber->getGrabbedFileId(), !app.grabber->useAnalysisQueue());
						
					int secsSinceBirth = (int)fIA->GetTimeSinceLastBirthSecs();
						
					app.ui->setSecsSinceBirth(secsSinceBirth);
				}
				else
					AppLog::write("Analyser was null, which is wasn't supposed to be.");
			}
		}
		else if (app.grabber->grabbingEnded() && !signalledDoneGrabbingAnalysing && fIA->getQueueSize() == 0)
		{
			signalledDoneGrabbingAnalysing = true;
			AppLog::writef("\nDONE grabbing and analyzing %u images - closing down\n", fIA->getAnalysedCount());
			return false;
		}
			
		if (fIA != nullptr)
		{
			int secsSinceBirth = (int)fIA->GetTimeSinceLastBirthSecs();
			app.ui->setSecsSinceBirth(secsSinceBirth);
		}
	}

	///////////////////
	/// State Changes
	///////////////////

	FarrowImageAnalyser *ana = app.getAnalyserPtr(false);
	isAlarmed = ana != nullptr && ana->getIsAlarmed();

	if (app.ui->getPressedAssist())
	{
		app.setNewState(new FarrowAppState_AssistSow(app));
		return true;
	}

	else if (app.ui->getPressedStart())
	{
		app.setNewState(new FarrowAppState_RunningEnded(app, storer));
		return true;
	}
	
	if (getMinutesSinceBirth() != repaintBasedOnMinutesSinceBirth ||
		ana->getPigletCount() != repaintBasedOnPigletCount ||
		isAlarmed != repaintBasedOnAlarmState || app.grabber->isReady() != repaintBasedOnCamReady || camProgress != repaintBasedOnCampProgress)
	{
		if (isAlarmed)
		{
			showingTime = false;
		}
		repaintBasedOnCampProgress = camProgress;
		repaintBasedOnCamReady = app.grabber->isReady();
		repaintBasedOnAlarmState = isAlarmed;
		repaintBasedOnPigletCount = ana->getPigletCount();
		repaintBasedOnMinutesSinceBirth = getMinutesSinceBirth();
		rePaint();
	}
	
	return true;
}
