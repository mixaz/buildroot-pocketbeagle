#include <future>
#include <chrono>
#include <sstream>
#include <vector>
#include "LoRaCommunicator.h"
#include "LoraRequestBuilder.h"
#include "device_drivers/UART.h"

#include "FarrowLog.h"
#include "CrossPlatform.hpp"
#include "Exceptions.hpp"
#include "FarrowApp.h"
using namespace std;

#ifdef WIN32 //On windows use our custom class to init, close, write and read
#include "WindowsCOM.h"
WindowsCOM wCOM;
inline int init_serial() { return wCOM.init(); }
inline void close_serial() { wCOM.close(); }
inline int write_serial(const char* write_data, int byte_count) { return wCOM.write(write_data, byte_count); }
inline int read_serial(char* read_data, int byte_count) { return wCOM.read(read_data, byte_count); }
#else //On other platforms use the UART-driver
inline int init_serial() { return init_UART(); }
inline void close_serial() { close_UART(); }
inline int write_serial(const char* write_data, int byte_count) { return write_UART(write_data, byte_count); }
inline int read_serial(char* read_data, int byte_count) { return read_UART(read_data, byte_count); }
#endif

LoRaCommunicator::LoRaCommunicator(FarrowApp& app, std::queue<Request> stored) : app(app)
{
	uartConnected.store(false);
	loraConnected.store(false);
	lock_guard <recursive_mutex> guard(storedRequestLock);
	storedRequests = stored;

	loRaThread = std::thread(&LoRaCommunicator::handleQueueLoop, this);
}

LoRaCommunicator::LoRaCommunicator(FarrowApp& app) : app(app)
{
	uartConnected.store(false);
	loraConnected.store(false);

	loRaThread = std::thread(&LoRaCommunicator::handleQueueLoop, this);
}


LoRaCommunicator::~LoRaCommunicator()
{
	loraComRunning = false;

	AppLog::write("Destroying Lora Com");

	if(app.ui != nullptr)
		app.ui->deployWaitMsg(this, "Destroy Lora");

	if (loRaThread.joinable())
		loRaThread.join();

	endSession();
	close_serial();

	AppLog::write("Lora com destroyed");
}

bool LoRaCommunicator::connect()
{


	if (!uartConnected.load())
	{
		if (init_serial() < 0)
		{
			return false;
		}
		
		char c;
		std::string initialUARTData = "";
		
// 		Wait until first byte is read
// 		while (read_serial(&c, 1) == 0) {
// 		};
// 		initialUARTData += c;

		// Read to empty UART buffer from the beginning
		while (read_serial(&c, 1) != 0) {
			initialUARTData += c;
		};

		if (initialUARTData != "")
		{
			AppLog::writef("Connected UART Session but found old data upon successful connection: \n%s\n", initialUARTData.c_str());
		}
		uartConnected.store(true);
	}

	if (!restoreSession())
	{
		if (!newSession())
		{
			loraConnected.store(false);
			return false;
		}
	}
	loraConnected.store(true);

	return true;	
}

bool LoRaCommunicator::connected()
{
	return uartConnected.load() && loraConnected.load();
}

void LoRaCommunicator::enqueRequest(const Request& req)
{
	if (active)
	{
		//AppLog::writef("Enqueing request: %s", req.data.c_str());
		lock_guard<recursive_mutex> guard(requestLock);

		liveRequests.push(req);

		//printf("Enqued request: %s\n", req.data.c_str());
	}
}

void LoRaCommunicator::resume()
{
	if (!loraComRunning.load())
		loraComRunning.store(true);
}

void LoRaCommunicator::stop()
{
	loraComRunning.store(false);
}

void LoRaCommunicator::sendHeartbeat(bool onlyIfNeeded)
{
	//Send heartbeat if no other messages was successfully sent within last three minutes
	if (liveRequests.empty() && (sentHeartBeatWhenPossible || lastTransmissionTimer.getStopwatchRawTimeMS() > 3 * 60 * 1000))
	{
		sentHeartBeatWhenPossible = false;
		enqueRequest(LoraRequestBuilder::getHeartbeatRequest());
	}
}

std::unique_ptr<tinyxml2::XMLDocument> LoRaCommunicator::getQueuesAsXML()
{

	requestLock.lock();
	storedRequestLock.lock();
	std::vector<Request> reqs;
	std::queue<Request> lq = liveRequests;
	std::queue<Request> sq = storedRequests;
	requestLock.unlock();
	storedRequestLock.unlock();


	while (!lq.empty())
	{
		reqs.push_back(lq.front());
		lq.pop();
	}

	while (!sq.empty())
	{
		reqs.push_back(sq.front());
		sq.pop();
	}

	auto doc = std::make_unique<tinyxml2::XMLDocument>();
	tinyxml2::XMLNode* root = doc->NewElement("root");
	doc->InsertFirstChild(root);

	tinyxml2::XMLElement * loraElem = doc->NewElement("lorarequests");
	root->InsertEndChild(loraElem);

	for(Request& r : reqs)
	{
		Request::COMMAND_TYPE cmdT = r.getCommandType();
		if (cmdT == Request::COMMAND_TYPE::HEARTBEAT) // do no include heart beats.
		{
			continue;
		}
		tinyxml2::XMLElement* elem = doc->NewElement("Request");
		elem->SetAttribute("data", r.to_string().c_str());

		loraElem->InsertEndChild(elem);
	}

	return doc;
}

bool LoRaCommunicator::newSession()
{
	return true;
}

bool LoRaCommunicator::restoreSession()
{
	return false;
}

void LoRaCommunicator::endSession()
{
	loraConnected = false;
}


void LoRaCommunicator::handleQueueLoop()
{
	storedRequestLock.lock();

	int storedRequestCount = storedRequests.size();

	bool signalledDoneSendingStored = storedRequestCount == 0;

	storedRequestLock.unlock();
	try
	{
		loraComRunning.store(true);

		//Wait until active bool is set
		while (!activeIsSet)
		{
			CrossPlatform::threadSleep(5000);
		}
		if (!active)
		{
			return;
		}

		while (loraComRunning)
		{ 
			while (loraComRunning && (!uartConnected.load() || !loraConnected.load()))
			{
				//printf("Trying to connect LoraCOmmunicator\n");
				connect();
				CrossPlatform::threadSleep(1000);
			}

			if (!loraComRunning)
			{
				break;
			}

			requestLock.lock();
			if (!liveRequests.empty())
			{

				//printf("Processing live request A\n");
				Request req = liveRequests.front();
				requestLock.unlock();

				//printf("Processing live request B\n");
			
				if (sendRequest(req))
				{
					std::lock_guard<recursive_mutex> guard(requestLock);
					liveRequests.pop();
					string cmdTypeHex = "";
					if (req.getCommandTypeHex(cmdTypeHex))
					{
						printf("request of type: %s succeeded!\n", cmdTypeHex.c_str());
						if (cmdTypeHex == "FE")
						{
							AppLog::writef("Received Wrong-request-length from gateway in response to request: %s", req.data);
						}
					}
					else
					{
						AppLog::writef("Getting command type from Lora message: %s failed", req.data);
					}
				}
				else
				{
					//AppLog::write("Failed to send live request: " + req.to_string());
					while (!connect() && loraComRunning)
					{
						CrossPlatform::threadSleep(1000);
					}
				}
			}
			else
			{
				requestLock.unlock();

				storedRequestLock.lock();

				if (!storedRequests.empty())
				{
					Request req = storedRequests.front();
					storedRequestLock.unlock();
					if (sendRequest(req))
					{
						std::lock_guard<recursive_mutex> guard(storedRequestLock);
						storedRequests.pop();
						auto doc = getQueuesAsXML();
						tinyxml2::XMLError err = doc->SaveFile(FarrowApp::getLoraXMLPath().c_str());
						
						if (storedRequests.empty())
						{
							AppLog::writef("Done sending %i previuously stored LORA message(s)", storedRequestCount);
						}

						//AppLog::writef("Updating LoRa requests file: %s" , doc->ErrorName());
					}
					else
					{
						//AppLog::write("Failed to send stored request: " + req.to_string());
						while (!connect() && loraComRunning)
						{
							CrossPlatform::threadSleep(1000);
						}
					}
				}
				else
				{
					storedRequestLock.unlock();
				}
			}

			CrossPlatform::threadSleep(100);
		}

	}
	catch (std::exception& e)
	{
		printf("Caught exception in Lora handle ueue loop: %s\n", e.what());
	}
	catch (...)
	{
		printf("Catched other exception\n");
	}
}
//
//************************************
// Method:    sendRequest
// FullName:  LoRaCommunicator::sendRequest
// Access:    private 
// Returns:   bool indicating whether request got proper response according to protocol (id and command type matches).
// Qualifier:
// Parameter: Request req. Req.callback is called with payload as it's argument if req.callback exists
//************************************
bool LoRaCommunicator::sendRequest(Request req)
{
	req.data += "\n";
	/*
	auto ss = std::stringstream();
	ss << "Attempting to send: " << req.data << " via LORA";
	AppLog::write(ss.str());
	*/

	//Get device id and command type of requests send
	string deviceId, commandType;

	if (!req.getDeviceId(deviceId))
	{
		AppLog::writef("request sent has no valid device id. data: \n%s\n", req.data.c_str());
		return false;
	}

	if (!req.getCommandTypeHex(commandType))
	{
		AppLog::writef("request sent has no valid command type. data: \n%s\n", req.data.c_str());
		return false;
	}


	try
	{
		if (write_serial(req.data.c_str(), req.data.length()) < 0)
		{
			uartConnected.store(false);
			throw UARTException("Writing to UART failed");
		}

		auto tNow = std::chrono::steady_clock::now();
		auto t1 = tNow + std::chrono::seconds(30);

		string rawResponse = ""; // a full response from the gateway

		char c; // single char to read to
		bool timedOut = false;
		bool responseMatch = false;
		//Try to read (possibly multiple times) until response with correct device id and command type is received
		
		Response responseCandidate;
		do
		{
			rawResponse = "";
			// Read until receiving LF or timeout
			do
			{
				int res;
				if ((res = read_serial(&c, 1)) < 0)
				{
					uartConnected.store(false);
					throw UARTException("Reading single byte from UART failed ");
				}
				if (res > 0)
				{
					rawResponse += c;
				}
				tNow = std::chrono::steady_clock::now();
				timedOut = tNow >= t1 || loraComRunning.load() == false;
				CrossPlatform::threadSleep(10);

			} while (c != 0x0A && !timedOut);

			if (!timedOut)
			{
				//Remove spaces and newline characters
				rawResponse.erase(std::remove_if(rawResponse.begin(), rawResponse.end(),
					[](unsigned char c) {return c == ' ' || c == '\n' || c == '\r'; }), rawResponse.end());


				if (rawResponse == "" || rawResponse == "FF")
				{
					CrossPlatform::threadSleep(50);
				}
				else
				{
					//printf("Got raw response: %s\n", rawResponse.c_str());
					responseCandidate = Response(rawResponse);

					if (responseCandidate.isValid())
					{
						if (responseCandidate.getDeviceId() == deviceId)
						{
							if (responseCandidate.getCommandType() == "FE")
							{
								AppLog::write("Lora communicator received response type 'FE' which indicates a wrong string length was sent to the gateway");
								responseMatch = true; // Set response to matching, but warn, that it is due to the "FE" - response type.
							}
							else
							{
								responseMatch =  responseCandidate.getCommandType() == commandType;	
							}

						}
					}
				}
			}
		} while (!timedOut && !responseMatch);

		if (responseMatch)
		{
			uartConnected.store(true);
			loraConnected.store(true);
			
			if (req.callback != nullptr)
			{
				// if message has no device_id or command_type, the entire response is the payload.
				//std::string payload = req.hasDeviceIdAndType ? read.substr(8, read.length() - 8) : read;
				req.callback(rawResponse);
			}
			lastTransmissionTimer.reset();
			return true;
		}

		else if (timedOut)
		{
			AppLog::writef("LORA TImed out for request: %s\n", req.data.c_str());
			loraConnected.store(false);
		}
	}
	catch (UARTException* e)
	{
		AppLog::writef("Exception: %s in sendRequest: %s", std::string(e->what()), req.data.c_str());
	}
	return false;
}