#pragma once
#include <mutex>



class SystemWideVars
{
public:
	static std::recursive_mutex i2cLock;
};