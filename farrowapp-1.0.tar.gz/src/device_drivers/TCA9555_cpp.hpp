#pragma once
#include "TCA9555.h"
#include <mutex>

class TCA9555
{
public:
	TCA9555();
	~TCA9555();

	void init();
	void close();
	void configureAllInput();
	void configureAllOutput();
	void toggleOutputs();
	void setPin(unsigned char reg_addr, int pin_no);
	void clearPin(unsigned char reg_addr, int pin_no);
	void togglePin(unsigned char reg_addr, int pin_no);
	void changePin(unsigned char reg_addr, int pin_no, int value);
	int checkPin(unsigned char reg_addr, int pin_no);	
	void writeReg(unsigned char reg_addr, unsigned char wrt_data);
	unsigned char readReg(unsigned char reg_addr);
	unsigned short readInputs();

private:
	std::mutex tcaMtx;
};

