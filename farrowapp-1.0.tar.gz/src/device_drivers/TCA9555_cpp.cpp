#include "TCA9555_cpp.hpp"
#include <mutex>
#include <string>

TCA9555::TCA9555()
{
}


TCA9555::~TCA9555()
{
	close();
}

void TCA9555::init()
{
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	if (TCA9555_init() == -1)
	{
		throw std::runtime_error("TCA955: Failed to initialize TCA9555");
	}
#endif
}

void TCA9555::close()
{
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	if (TCA9555_close() == -1)
	{
		throw std::runtime_error("TCA955: Failed to close TCA9555");
	}
#endif
}

void TCA9555::configureAllInput()
{
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	if (TCA9555_configure_all_input() == -1)
	{
		throw std::runtime_error("TCA955: Failed to configure all pins as input");
	}
#endif
}

void TCA9555::configureAllOutput()
{
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	if (TCA9555_configure_all_output() == -1)
	{
		throw std::runtime_error("TCA955: Failed to configure all pins as output");
	}
#endif
}

void TCA9555::toggleOutputs()
{
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	if (TCA9555_toggle_outputs() == -1)
	{
		throw std::runtime_error("TCA955: Failed to toggle all outputs");
	}
#endif
}

void TCA9555::setPin(unsigned char reg_addr, int pin_no)
{
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	if (TCA9555_set_pin(reg_addr, pin_no) == -1)
	{
		throw std::runtime_error("TCA955: Failed to set pin " + std::to_string(pin_no));
	}
#endif
}

void TCA9555::clearPin(unsigned char reg_addr, int pin_no)
{
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	if (TCA9555_clear_pin(reg_addr, pin_no) == -1)
	{
		throw std::runtime_error("TCA955: Failed to clear pin " + std::to_string(pin_no));
	}
#endif
}

void TCA9555::togglePin(unsigned char reg_addr, int pin_no)
{
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	if (TCA9555_toggle_pin(reg_addr, pin_no) == -1)
	{
		throw std::runtime_error("TCA955: Failed to toggle pin " + std::to_string(pin_no));
	}
#endif
}

void TCA9555::changePin(unsigned char reg_addr, int pin_no, int value)
{
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	if (TCA9555_change_pin(reg_addr, pin_no, value) == -1)
	{
		throw std::runtime_error("TCA955: Failed to change value of pin " + std::to_string(pin_no) + " to " + std::to_string(value));
	}
#endif
}

int TCA9555::checkPin(unsigned char reg_addr, int pin_no)
{
	int ret;
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	
	if (TCA9555_check_pin(reg_addr, pin_no, &ret) == -1)
	{
		throw std::runtime_error("TCA955: Failed to check value pin " + std::to_string(pin_no));
	}	
#endif
	return ret;
}

void TCA9555::writeReg(unsigned char reg_addr, unsigned char wrt_data)
{
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	if (TCA9555_write_reg(reg_addr, wrt_data) == -1)
	{
		throw std::runtime_error("TCA955: Failed to write to register " + std::to_string(reg_addr));
	}
#endif
}

unsigned char TCA9555::readReg(unsigned char reg_addr)
{
	unsigned char ret;
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	
	if (TCA9555_read_reg(reg_addr, &ret) == -1)
	{
		throw std::runtime_error("TCA955: Failed to read from register " + std::to_string(reg_addr));
	}
#endif
	return ret;
}

unsigned short TCA9555::readInputs()
{
	unsigned char readLsb, readMsb;
#ifdef BEAGLE_BONE
	std::unique_lock<std::mutex> guard(tcaMtx);

	

	if (TCA9555_read_reg(TCA9555_INPUT0, &readLsb) == -1)
	{
		throw std::runtime_error("TCA9555: to read from TCA9555_INPUT0");
	}

	if (TCA9555_read_reg(TCA9555_INPUT1, &readMsb) == -1)
	{
		throw std::runtime_error("TCA9555: Failed to read from TCA9555_INPUT1");
	}
#endif
	// Concatenate bytes and return
	return (readMsb << 8) | readLsb;
}
