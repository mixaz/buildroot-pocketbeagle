#include <stdio.h>
#include "UART.h"

#ifdef BEAGLE_BONE

#include <dirent.h>
#include <fcntl.h> 
#include <string.h>
#include <termios.h>
#include <unistd.h>
#include <stdio.h>

static int UART;

int init_UART()
{
    // Flip GPIO57 to reset ATMega328 
    FILE *iodir, *ioval, *ioexp;
	DIR* expdir = opendir("/sys/class/gpio/gpio57");
	if(!expdir)
	{	
		ioexp = fopen("/sys/class/gpio/export", "w");

		if (ioexp == NULL)
		{
			perror("ERROR opening UART. Failed to export GPIO57 |");
			return -1;	
		}

		fseek(ioexp, 0, SEEK_SET);
		fprintf(ioexp, "57");
		fflush(ioexp);
		fclose(ioexp);
	}
	closedir(expdir);

	usleep(100000);
	
    iodir = fopen("/sys/class/gpio/gpio57/direction", "w");
	if (iodir == NULL)
	{
		perror("ERROR opening UART. Failed to set direction of GPIO57 |");
		return -1;
	}

    fseek(iodir,0,SEEK_SET);
    fprintf(iodir,"out");
    fflush(iodir);
	fclose(iodir);

    ioval = fopen("/sys/class/gpio/gpio57/value", "w");
	if (ioval == NULL)
	{
		perror("ERROR opening UART. Failed to set value of GPIO57 |");
		return -1;
	}
    fseek(ioval,0,SEEK_SET);
    
    fprintf(ioval,"%d",0);
    fflush(ioval);
    usleep(10000);
    fprintf(ioval,"%d", 1);
    fflush(ioval);
    
    fclose(ioval);
    
    // Wait for MEGA328 to reset
    usleep(2000000);
    
    // Init UART
    UART = open (UART_O4, O_RDWR | O_NOCTTY | O_SYNC);
    if (UART < 0)
    {
            perror("ERROR opening UART |");
            return -1;
    }
    
    set_interface_attribs(UART, B9600, 0); 
    set_blocking(UART, 0);                
    
    usleep(1000000);
	tcflush(UART, TCIOFLUSH);

    return 0;
}

void close_UART()
{
    close(UART);
}

int write_UART(const char* write_data, int byte_count)
{
    int count = 0;
    if((count = write(UART, write_data, byte_count)) < 0)
    {
        perror("Failed to write to the output\n");
        return -1;
    }
    if(count != byte_count)
    {
        printf("Failed to write all bytes to output: %d of %d written.", count, byte_count);
        return -1;
    }
    
    return 0;
    
}

int read_UART(char* read_data, int byte_count)
{
    int count = 0;
    if((count = read(UART, (void*)read_data, byte_count)) < 0)
    {
        perror("Failed to read from the input \n");
        return -1;
    }
    
    return count;
}

int set_interface_attribs (int fd, int speed, int parity)
{
        struct termios tty;
        memset (&tty, 0, sizeof tty);
        if (tcgetattr (fd, &tty) != 0)
        {
                printf("error %d from tcgetattr");
                return -1;
        }

        cfsetospeed (&tty, speed);
        cfsetispeed (&tty, speed);

        tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;     // 8-bit chars
        // disable IGNBRK for mismatched speed tests; otherwise receive break
        // as \000 chars
        tty.c_iflag &= ~IGNBRK;         // disable break processing
        tty.c_lflag = 0;                // no signaling chars, no echo,
                                        // no canonical processing
        tty.c_oflag = 0;                // no remapping, no delays
        tty.c_cc[VMIN]  = 0;            // read doesn't block
        tty.c_cc[VTIME] = 5;            // 0.5 seconds read timeout

        tty.c_iflag &= ~(IXON | IXOFF | IXANY); // shut off xon/xoff ctrl

        tty.c_cflag |= (CLOCAL  | CREAD);// ignore modem controls,
                                        // enable reading
        tty.c_cflag &= ~(PARENB | PARODD);      // shut off parity
        tty.c_cflag |= parity;
        tty.c_cflag &= ~CSTOPB;
        tty.c_cflag &= ~CRTSCTS;

        if (tcsetattr (fd, TCSANOW, &tty) != 0)
        {
                perror("error %d from tcsetattr\n");
                return -1;
        }
        return 0;
}

void set_blocking (int fd, int should_block)
{
        struct termios tty;
        memset (&tty, 0, sizeof tty);
        if (tcgetattr (fd, &tty) != 0)
        {
                perror("error %d from tggetattr\n");
                return;
        }

        tty.c_cc[VMIN]  = should_block ? 1 : 0;
        tty.c_cc[VTIME] = 5;            // 0.5 seconds read timeout

        if (tcsetattr (fd, TCSANOW, &tty) != 0)
                perror("error %d setting term attributes\n");
}

#endif

