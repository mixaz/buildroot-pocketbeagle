#ifndef UART_H_
#define UART_H_

#define UART_O4 "/dev/ttyO4"

#ifdef BEAGLE_BONE
	#ifdef __cplusplus
		extern "C"
		{
	#endif

	extern int init_UART();
	extern void close_UART();

	extern int write_UART(const char* write_data, int byte_count);
	extern int read_UART(char* read_data, int byte_count);

	extern int set_interface_attribs(int fd, int speed, int parity);
	extern void set_blocking(int fd, int should_block);
	
	#ifdef __cplusplus
		}
	#endif
#else
	extern inline int init_UART() { return -1; }
	extern inline void close_UART() { return; }

	extern inline int write_UART(const char* write_data, int byte_count) { return -1; }
	extern inline int read_UART(char* read_data, int byte_count) { return -1; }

#endif /* WIN32 */

#endif /* UART_H_ */
