
#ifdef WIN32
#else

#include <stdio.h>
#include "TCA9555.h"
#include "I2C.h"

static I2C_DeviceT TCA9555;

int TCA9555_init()
{
	if (TCA9555.fd_i2c == 0)
	{
		if (init_i2c_dev(0x20, I2C_BUS1_PATH, &TCA9555) == 0)
		{
			printf("i2c at %s: Bus Connected to TCA9555\n", I2C_BUS1_PATH);
		}
		else
		{
			printf("i2c-1: ERROR connecring bus to SSD1306\n");
			return -1;
		}
	}
    
    return 0;
}

int TCA9555_close()
{
	if (TCA9555.fd_i2c != 0)
	{
		if (Close_device(TCA9555.fd_i2c) == 0)
		{
			printf("i2c at %s: Bus closed, connection to TCA9555 terminated\n", TCA9555.i2c_dev_path);
		}
		else
		{
			printf("i2c at %s: ERROR closing bus for TCA9555\n", TCA9555.i2c_dev_path);
			return -1;
		}
	}

    return 0;
}

int TCA9555_configure_all_input()
{
    if(i2c_write_register(TCA9555.fd_i2c, TCA9555_CONFIG0, 0x00) != I2C_TWO_BYTES)
    {
		printf("ERROR could not write to TCA9555_CONFIG0\n");
		return -1;
    }
    
    if(i2c_write_register(TCA9555.fd_i2c, TCA9555_CONFIG1, 0x00) != I2C_TWO_BYTES)
    {
		printf("ERROR could not write to TCA9555_CONFIG1\n");
		return -1;
    }
    
    return 0;
}



int TCA9555_configure_all_output()
{
    if(i2c_write_register(TCA9555.fd_i2c, TCA9555_CONFIG0, 0x00) != I2C_TWO_BYTES)
    {
		printf("ERROR could not write to TCA9555_CONFIG0\n");
		return -1;
    }
    
    if(i2c_write_register(TCA9555.fd_i2c, TCA9555_CONFIG1, 0x00) != I2C_TWO_BYTES)
    {
		printf("ERROR could not write to TCA9555_CONFIG1\n");
		return -1;
    }
    
    return 0;
}

int TCA9555_toggle_outputs()
{
    unsigned char temp[2] = {0};
    
    // Toggle TCA9555_OUTPUT0
    
    if(i2c_read_register(TCA9555.fd_i2c, TCA9555_OUTPUT0, &temp[0]) != I2C_ONE_BYTE)
    {
		printf("ERROR could not read TCA9555_OUTPUT0\n");
		return -1;
    }
    
    if(i2c_write_register(TCA9555.fd_i2c, TCA9555_OUTPUT0, ~temp[0]) != I2C_TWO_BYTES)
    {
		printf("ERROR could not write to TCA9555_OUTPUT0\n");
		return -1;
    }
    
    // Toggle TCA9555_OUTPUT1
    
    if(i2c_read_register(TCA9555.fd_i2c, TCA9555_OUTPUT1, &temp[1]) != I2C_ONE_BYTE)
    {
		printf("ERROR could not read TCA9555_OUTPUT1\n");
		return -1;
    }
    
    if(i2c_write_register(TCA9555.fd_i2c, TCA9555_OUTPUT1, ~temp[0]) != I2C_TWO_BYTES)
    {
		printf("ERROR could not write to TCA9555_OUTPUT0\n");
		return -1;
    }
    
    return 0;
}

int TCA9555_set_pin(unsigned char reg_addr, int pin_no)
{
	if (!(pin_no >= 0 && pin_no <= 7))
	{
		printf("ERROR pin number must be between 0 and 7");
		return -1;
	}

	unsigned char temp[1] = { 0 };

	if (i2c_read_register(TCA9555.fd_i2c, reg_addr, &temp[0]) != I2C_ONE_BYTE)
	{
		printf("ERROR could not read register %X\n", reg_addr);
		return -1;
	}

	temp[0] |= 0x01 << pin_no;

	if (i2c_write_register(TCA9555.fd_i2c, reg_addr, temp[0]) != I2C_TWO_BYTES)
	{
		printf("ERROR could not write to register %X \n", reg_addr);
		return -1;;
	}

	return 0;
}
int TCA9555_clear_pin(unsigned char reg_addr, int pin_no)
{
	if (!(pin_no >= 0 && pin_no <= 7))
	{
		printf("ERROR pin number must be between 0 and 7");
		return -1;
	}

	unsigned char temp[1] = { 0 };

	if (i2c_read_register(TCA9555.fd_i2c, reg_addr, &temp[0]) != I2C_ONE_BYTE)
	{
		printf("ERROR could not read register %X\n", reg_addr);
		return -1;
	}

	temp[0] &= ~(0x01 << pin_no);

	if (i2c_write_register(TCA9555.fd_i2c, reg_addr, temp[0]) != I2C_TWO_BYTES)
	{
		printf("ERROR could not write to register %X \n", reg_addr);
		return -1;
	}

	return 0;
}

int TCA9555_toggle_pin(unsigned char reg_addr, int pin_no)
{
	if (!(pin_no >= 0 && pin_no <= 7))
	{
		printf("ERROR pin number must be between 0 and 7");
		return -1;
	}

	unsigned char temp[1] = { 0 };

	if (i2c_read_register(TCA9555.fd_i2c, reg_addr, &temp[0]) != I2C_ONE_BYTE)
	{
		printf("ERROR could not read register %X\n", reg_addr);
		return -1;
	}

	temp[0] ^= 0x01 << pin_no;

	if (i2c_write_register(TCA9555.fd_i2c, reg_addr, temp[0]) != I2C_TWO_BYTES)
	{
		printf("ERROR could not write to register %X \n", reg_addr);
		return -1;
	}

	return 0;
}

int TCA9555_change_pin(unsigned char reg_addr, int pin_no, int value)
{
	if (!(pin_no >= 0 && pin_no <= 7))
	{
		printf("ERROR pin number must be between 0 and 7");
		return -1;
	}

	if (!(value == 0 || value == 1))
	{
		printf("ERROR value must be 0 or 1");
		return -1;
	}

	unsigned char temp[1] = { 0 };

	if (i2c_read_register(TCA9555.fd_i2c, reg_addr, &temp[0]) != I2C_ONE_BYTE)
	{
		printf("ERROR could not read register %X\n", reg_addr);
		return -1;
	}

	temp[0] = (temp[0] & ~(0x01 << pin_no)) | (value << pin_no);

	if (i2c_write_register(TCA9555.fd_i2c, reg_addr, temp[0]) != I2C_TWO_BYTES)
	{
		printf("ERROR could not write to register %X \n", reg_addr);
		return -1;
	}

	return 0;
}

int TCA9555_check_pin(unsigned char reg_addr, int pin_no, int* result)
{
	if (!(pin_no >= 0 && pin_no <= 7))
	{
		printf("ERROR pin number must be between 0 and 7");
		return -1;
	}

	unsigned char temp[1] = { 0 };

	if (i2c_read_register(TCA9555.fd_i2c, reg_addr, &temp[0]) != I2C_ONE_BYTE)
	{
		printf("ERROR could not check register %X\n", reg_addr);
		return -1;
	}

	*result = (temp[0] >> pin_no) & 1;
}

int TCA9555_read_inputs(unsigned char* read_data)
{
    if(i2c_read_register(TCA9555.fd_i2c, TCA9555_INPUT0, &read_data[0] ) != I2C_ONE_BYTE)
    {
		printf("ERROR could not read TCA9555_INPUT0\n");
		return -1;
    }
    
    if(i2c_read_register(TCA9555.fd_i2c, TCA9555_INPUT1, &read_data[1] ) != I2C_ONE_BYTE)
    {
		printf("ERROR could not read TCA9555_INPUT1\n");
		return -1;
    }

	return 0;
}
    
int TCA9555_write_reg(unsigned char reg_addr, unsigned char wrt_data)
{
    if(i2c_write_register(TCA9555.fd_i2c, reg_addr, wrt_data) != I2C_TWO_BYTES)
    {
		printf("ERROR could not write to register %X \n", reg_addr);
		return -1;
    }
    
    return 0;
}

int TCA9555_read_reg(unsigned char reg_addr, unsigned char* read_data)
{
    if(i2c_read_register(TCA9555.fd_i2c, reg_addr, read_data) != I2C_ONE_BYTE)
    {
		printf("ERROR could not read register %X \n", reg_addr);
		return -1;
    }
	
	return 0;
}

#endif /* WIN32 */
