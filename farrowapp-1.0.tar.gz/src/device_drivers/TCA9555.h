
#ifndef TCA9555_H_
#define TCA9555_H_

#define TCA9555_ADDR                                                0x20

#define TCA9555_INPUT0                                              0x00
#define TCA9555_INPUT1                                              0x01
#define TCA9555_OUTPUT0                                             0x02
#define TCA9555_OUTPUT1                                             0x03
#define TCA9555_POL_INV0                                            0x04
#define TCA9555_POL_INV1                                            0x05
#define TCA9555_CONFIG0                                             0x06
#define TCA9555_CONFIG1                                             0x07

#ifdef __cplusplus
	extern "C"
	{
#endif

extern int TCA9555_init();
extern int TCA9555_close();
extern int TCA9555_configure_all_input();
extern int TCA9555_configure_all_output();
extern int TCA9555_toggle_outputs();
extern int TCA9555_set_pin(unsigned char reg_addr, int pin_no);
extern int TCA9555_clear_pin(unsigned char reg_addr, int pin_no);
extern int TCA9555_toggle_pin(unsigned char reg_addr, int pin_no);
extern int TCA9555_change_pin(unsigned char reg_addr, int pin_no, int value);
extern int TCA9555_check_pin(unsigned char reg_addr, int pin_no, int* result);
extern int TCA9555_read_inputs(unsigned char* read_data);
extern int TCA9555_write_reg(unsigned char reg_addr, unsigned char wrt_data);
extern int TCA9555_read_reg(unsigned char reg_addr, unsigned char* read_data);

#ifdef __cplusplus
	}
#endif

#endif /* TCA9555_H_ */