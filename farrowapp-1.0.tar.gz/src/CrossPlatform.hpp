#pragma once
#include <iostream>
#include <stdexcept>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <fstream>
#include <sstream>
#include "Util.h"
#include "string.h"
#ifdef WIN32
#include <windows.h>
const std::string crossPlatformFolderDelimiter = "\\";
const std::wstring crossPlatformFolderDelimiterW = L"\\";
#else
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
typedef wchar_t WCHAR;
const std::string crossPlatformFolderDelimiter = "/";
#endif // win32
#include <set>

// Should be removed when shared partition is working
const bool CrossPlatform_isBeagleBone =
#ifndef BEAGLE_BONE
true;
#else
false;
#endif



class CrossPlatform
{
public:

	static std::string getDeviceId()
	{
		const std::string noID = "000000";

		static bool idCalculated = false;

		static std::string derivedId = noID;

		if (!idCalculated)
		{
			derivedId = noID;

			idCalculated = true;
			std::string execPath = CrossPlatform::getExecDir();
			std::string cpuInfoPath = "";

			//First try to find cpu-info file in executable support
			cpuInfoPath = execPath + "ExecutableSupport" + CrossPlatform::getFolderDelimiter() + "cpuinfo";
			std::ifstream cpuFile(cpuInfoPath);

			if (!cpuFile.fail())
			{
				std::string line;

				while (std::getline(cpuFile, line))
				{
					std::istringstream iss(line);
					//Look for line with Serial
					Util::convertStringToLower(line);
					if (line.find("serial") != std::string::npos)
					{
						size_t colonIndex = line.find_last_of(':');

						if (colonIndex == std::string::npos)
							derivedId = noID;

						std::string fromColon = line.substr(colonIndex + 1, line.length() - colonIndex);

						std::string trimmed = Util::trim(fromColon, ' ');

						if (trimmed.length() != 6)
						{
							printf("returning cpu=000000 as serial length was not 6 (6hex digits / 3 bytes)");
							derivedId = noID;
						}
						else
						{
							derivedId = Util::trim(trimmed, '0');
						}
					}
				}
			}
			else //If no file is found in executableSupport - look for eeprom on linux
			{
#ifdef __linux__
				char buffer[100] = { 0 };
				std::ifstream file("/sys/bus/i2c/devices/0-0050/eeprom", std::ios::in);

				// EEPROM structure should be HEADER ID VERSION SERIAL (4 8 4 12)

				file.seekg(16, std::ios::beg);
				if (!file.read(buffer, 12))
				{
					return noID;
				}
				file.close();
				std::string eepromStr(buffer);

				derivedId = eepromStr.substr(eepromStr.length() - 6 - 1, 6);
#endif // __linux__
			}
			if (!Util::isHexString(derivedId))
			{
				printf("device id set to: %s as serial was a non hex value: %s\n", noID.c_str(), derivedId.c_str());
				derivedId = noID;
			}
			idCalculated = true;
		}

		return derivedId;
	}

	static void threadSleep(int milliSecs)
	{
#ifdef WIN32
		Sleep(milliSecs);
#else
		usleep(milliSecs * 1000); //Usleep on unix uses nanoseconds
#endif // win32
	}

	static std::string getExecDir()
	{
#ifdef WIN32
		//Get current executable dir
		HMODULE hModule = GetModuleHandleW(NULL);
		WCHAR path[MAX_PATH];
		GetModuleFileName(hModule, path, MAX_PATH);
		std::wstring pathWString = path;
		std::string pathString(pathWString.begin(), pathWString.end());
#else
		char buf[1024];
		memset(buf, 0, 1024);
		int length = readlink("/proc/self/exe", buf, 1024);
		std::string pathString(buf);
		
#endif
		//Remove the last part of the path (after the last delimiter)
		size_t dirSlashIndex = pathString.find_last_of(crossPlatformFolderDelimiter);
		
		std::string pathWithoutFile = pathString.substr(0, dirSlashIndex + 1);
		
		//printf("Found execPath: %s\n", pathWithoutFile.c_str());
		//CrossPlatform::threadSleep(1000);
 		return pathWithoutFile;
	}

	static bool makeDirectory(std::string path)
	{
#ifdef WIN32
		return CreateDirectoryA(path.c_str(), NULL) > 0;
#else
		int mode = 0777;
		int returnVal = mkdir(path.c_str(), mode);
		chmod(path.c_str(), mode);
		return returnVal >= 0;
#endif
	}
	static std::vector<std::string> getFiles(std::string pathToDir, std::string nameMustContain)
	{
		std::vector<std::string> matchingFiles;

#ifdef WIN32
		WIN32_FIND_DATA FindFileData;
		HANDLE hFind;
		//TCHAR *fileName = (TCHAR *)dirName.c_str();

		std::wstring pathToDirW(pathToDir.begin(), pathToDir.end());
		std::wstring nameMustContainW(nameMustContain.begin(), nameMustContain.end());

		//Add subfoldername and wildcard character
		std::wstring searchFileName = pathToDirW + crossPlatformFolderDelimiterW + L"*" + nameMustContainW;

		hFind = FindFirstFile(searchFileName.c_str(), &FindFileData);
		if (hFind != INVALID_HANDLE_VALUE)
		{
			do
			{
				std::wstring matchW = pathToDirW + crossPlatformFolderDelimiterW + FindFileData.cFileName;
				
				matchingFiles.push_back(std::string(matchW.begin(), matchW.end()));

			} while (FindNextFile(hFind, &FindFileData));

			FindClose(hFind);
		}


#else
		
		DIR *dir = opendir(pathToDir.c_str());
		if (dir != nullptr)
		{
			struct dirent *ep;

			while (ep = readdir(dir))
			{
				if (ep->d_type == DT_REG)
				{
					std::string nameStr(ep->d_name);

					if(nameStr.find(nameMustContain) != std::string::npos)
					{
						matchingFiles.push_back(pathToDir + crossPlatformFolderDelimiter + ep->d_name);
					}
				}
			}
			closedir(dir);

		}
		else
		{
			printf("Could not open dir stream: %s\n", pathToDir.c_str());
		}
		
#endif 
		return matchingFiles;

	}

	static std::vector<std::string> getDirs(std::string pathToDirs, std::string findDirName)
	{
		std::vector<std::string> matchingDirs;

#ifdef WIN32
		WIN32_FIND_DATA FindFileData;
		HANDLE hFind;
		//TCHAR *fileName = (TCHAR *)dirName.c_str();

		std::wstring pathToDirsW(pathToDirs.begin(), pathToDirs.end());
		std::wstring findDirNameW(findDirName.begin(), findDirName.end());
		
		//Add subfoldername and wildcard character
		std::wstring searchFolderName = pathToDirsW + crossPlatformFolderDelimiterW + findDirNameW + L"*";

		hFind = FindFirstFile(searchFolderName.c_str(), &FindFileData);
		if (hFind != INVALID_HANDLE_VALUE)
		{
			do 
			{
				if(!(FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
					continue;

				std::wstring matchW = searchFolderName + FindFileData.cFileName;
				matchingDirs.push_back(std::string(matchW.begin(), matchW.end()));

			} while (FindNextFile(hFind, &FindFileData));

			FindClose(hFind);
		}
			

#else
		DIR *dir = opendir(pathToDirs.c_str());
		if (dir != nullptr)
		{
			struct dirent *ep;
			
			while (ep = readdir(dir))
			{
				if(ep->d_type == DT_DIR)
				{
					std::string nameStr(ep->d_name);
					size_t compareLength = findDirName.length();
					if (nameStr.compare(0, compareLength, findDirName) == 0)
					{
						matchingDirs.push_back(ep->d_name);
						//printf("Found Matching folder: %s\n", ep->d_name);
					}
				}
			}
			closedir(dir);
				
		}
		else
		{
			printf("Could not open dir stream: %s\n", pathToDirs.c_str());
		}
#endif 
		return matchingDirs;

	}

	static void ensureDirExists(std::string dirName, std::string pathToParent)
	{
		std::vector<std::string> dirs = getDirs(pathToParent, dirName);

		bool doesImagesDirExist = dirs.size() > 0;

		if (!doesImagesDirExist)
		{
			//AppLog::write("Making '" + dirName + "' directory");

			if (!CrossPlatform::makeDirectory(pathToParent + dirName))
			{
				//AppLog::write("Could not create '" + dirName + "' directory");
			}
		}
	}

	static int getAvailableDiskSpace()
	{
		std::string commandResult;
#ifdef BEAGLE_BONE
		commandResult = getConsoleCommandOutput("df -k /mnt/mmcblk0p2 | tail -1 | awk '{print$4}'");
#else
		commandResult = "6000000";
		//commandResult = system("df -k /tmp | tail -1 | awk '{print$4}'");
#endif
		//Util::convertStringToLower(commandResult);

		//Remove "KB"
		//size_t k_offset = commandResult.find_first_of("k");
		//commandResult = commandResult.substr(0, k_offset);
		try
		{
			return stoi(commandResult);
		}
		catch (std::invalid_argument e)
		{
			return -1;
		}
	}
	
#ifndef WIN32

	static std::string getConsoleCommandOutput(std::string command)
	{
		FILE* pipe = popen(command.c_str(), "r");		//Send the command, popen exits immediately
		if (!pipe)
			return "ERROR";

		char buffer[128];
        std::string result = "";
		while (!feof(pipe))						//Wait for the output resulting from the command
		{
			if (fgets(buffer, 128, pipe) != NULL)
				result += buffer;
		}
		pclose(pipe);
		return result;
	}
#endif

	static std::string getFolderDelimiter()
	{
	#ifdef WIN32
		return "\\";
	#else
		return "/";
	#endif	
	}
	/*
	static void GoToOffMode()
	{
		printf("Closing down application due to user stop\n");
#ifdef WIN32
#else
#endif

		exit(0);
	}
	*/

	static std::string getFilenameFromPath(const std::string& path)
	{
		std::vector<std::string> result = splitpath(path);

		if (result.size() > 0)
			return result.back();
		else
			return std::string("_NOT_FOUND_");
	}

	static std::vector<std::string> splitpath(const std::string& str)
	{
#ifdef WIN32
		std::set<char> delims{ '\\' };
#else 
		std::set<char> delims{ '/' };
#endif
		std::vector<std::string> result;

		char const* pch = str.c_str();
		char const* start = pch;
		for (; *pch; ++pch)
		{
			if (delims.find(*pch) != delims.end())
			{
				if (start != pch)
				{
					std::string str(start, pch);
					result.push_back(str);
				}
				else
				{
					result.push_back("");
				}
				start = pch + 1;
			}
		}
		result.push_back(start);

		return result;
	}
};
