#include "Lepton3Grabber.h"
#include "FarrowLog.h"
#include "leptonpru.h"

#ifdef __linux__

#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>

#include <sys/types.h>
#include <sys/mman.h>
#include "SPI.h"
#include "Lepton_I2C.h"
#include "TemperatureSensor.h"

#else

float lepton_read_T_aux() { return 77; }
float lepton_read_T_fpa() { return 77; }
void getPathExtTempSensor(char* devPath) {}
float readExtTemperature(char* devPath) { return 77; }
void lepton_initialize(bool useShutter, bool useNoiseFilters, std::function<void()> progressFnc) {}
void lepton_stop(std::function<void()> progressFnc) {}

#endif // __linux__

using namespace cv;
using namespace std;

Lepton3Grabber::Lepton3Grabber(FarrowApp &app, int softResetDur, int hardResetDur, int hardResetNoImgDur, bool useNoiseFilters, bool debugForceNormalise) :
	FarrowImageGrabber(app)
{
	forceNormalise = debugForceNormalise;
	printf("Constructing Lepton3 grabber after %llu msecs\n", app.appTimer.getStopwatchRawTimeMS());
	//printf("Constructing lepton 3 grabber");
#ifdef BEAGLE_BONE 
	//Memeory-filecd
	fileDesc = open("/dev/leptonpru", O_RDWR | O_SYNC/* | O_NONBLOCK*/);

	printf("Leptonpru file descriptor opened after %llu msecs\n", app.appTimer.getStopwatchRawTimeMS());


	if (fileDesc < 0) {
		perror("open");
		assert(0);
	}

	if (LeptonPru_init(&pruContext, fileDesc) < 0) {
		perror("LeptonPru_init");
		assert(0);
	}
	printf("Leptonpru initiated after %llu msecs\n", app.appTimer.getStopwatchRawTimeMS());

	
	//printf("Mapping done\n");
#endif

}

Lepton3Grabber::~Lepton3Grabber()
{
#ifdef BEAGLE_BONE
	// release frame buffers
	if (LeptonPru_release(&pruContext) < 0) {
		perror("LeptonPru_release");
	}

	// release the driver
	close(fileDesc);
#endif // BEAGLE_BONE
}


void Lepton3Grabber::setMetaDataNow(FarrowImageMetaData& fM)
{
	if (tempReadTimer.getStopwatchRawTimeMS() > 10 * 1000)
	{
		FarrowTimer tempTimer;
		tempReadTimer.reset();
		lastFPATemp = lepton_read_T_fpa();
		char temp[6];
		sprintf(temp, "%.2f", lastFPATemp); // reduce T_fpa to 2 decimals
		stLastFPATemp = temp;

		//AppLog::write("Temp: " + to_string(tempTimer.getStopwatchRawTimeMS()) + " and is: " + stLastFPATemp);
		//if(tempReadTimer.getStopwatchRawTimeMS() > 10)
		//	AppLog::write("Reading fpa temperature. Took: " + to_string(tempTimer.getStopwatchRawTimeMS()) + " and is: " + stLastFPATemp);
	}

	FarrowImageGrabber::setMetaDataNow(fM); //Let base class set time
	fM.t_fpa = stLastFPATemp;
}

void Lepton3Grabber::setupCameraFNC(std::function<void()> progressCB)
{
	printf("Lepton 3 setting up\n");
	lepton_initialize(true, useNoiseFilters, progressCB);
	lastGrabTimeMillis = 0;
}

bool Lepton3Grabber::grabberLoopUpdate()
{
#ifdef BEAGLE_BONE
	// read next frame
	if (LeptonPru_next_frame(&pruContext) < 0) {

		printf("Got lepton pru_nextframe error\n");
		perror("LeptonPru_next_frame");
		return false;
	}
	// minimal&maximum values in the image, just in case
	//printf("frame:%d min: %i, max: %d",
	//	nn++, pruContext.curr_frame->min_val, pruContext.curr_frame->max_val);

	Mat curFrame = cv::Mat(120, 160, CV_16UC1);

	memcpy(curFrame.data, pruContext.curr_frame->image, bytesPrFrame);

	FarrowImageMetaData fMD;
	setMetaDataNow(fMD);

	ImageAndMetaData iAMD(curFrame, fMD);
	assignMatToDoubleBuffer(iAMD);
#endif
	unsigned long long timeNow = timer.getStopwatchRawTimeMS();
	if (lastGrabTimeMillis != 0 && (timeNow - lastGrabTimeMillis) > 1000)
	{
		abnormalGrabIntervals.push_back((timeNow - lastGrabTimeMillis) / 1000.0);
	}
	lastGrabTimeMillis = timeNow;
	return true;
}

void Lepton3Grabber::stopCameraFNC(std::function<void() > progressCB)
{
	printf("Lepton 3 Stopping\n");
	lastGrabTimeMillis = 0;
	lepton_stop(progressCB);
}
