#pragma once
#include <map>

inline bool digitalRead(int pin) { return false; };
inline void digitalWrite(int pin, int value) { };
inline void pinMode(int, int) {};
inline void pullUpDnControl(int, int) {};
const int OUTPUT = 1;
const int _INPUT = 0;	//"INPUT" is used for something else on windows machines
const int PUD_DOWN = 0;
const int PUD_UP = 0;

class PinManager
{
public:
	PinManager() {};
	~PinManager() {};
	static void setupAllPins();

	static bool digitalRead(int pin);
	static void digitalWrite(int pin, int value);
	static void pinMode(int pin, int mode);

	static const int CamReset = 20; ////(0=reset, 1=run) GPIO pin number 20, physical pin number p1_20 
	static const int SR_DATA = 23; //GPIO pin number 23, physical pin number p2_3
	static const int CamPower = 26; ////(0=off, 1=run) GPIO pin number 26, physical pin number p1_34
	static const int DISPLAY_BOARD_PWR = 27; //GPIO pin number 27, physical pin number p2_19
	static const int SR_OUTPUT = 45; //GPIO pin number 45, physical pin number p2_33
	static const int LED_laser = 46; //GPIO pin number 46, physical pin number p2_22
	static const int FLIR_PWR = 52; // PGIO pin number 52, physical pin number 
	static const int BOARD_PWR = 64; //GPIO pin number 64, physical pin number p2_64
	static const int IN_CHARGER = 65; //GPIO pin number 64, physical pin number p2_64

	
	/*

	static const int LED_STATUS_G = 1000; //switch register bit index 0 
	static const int LED_STATUS_R = 1001; //switch register bit index 1
	static const int LED_BATT_STAT_G = 1002; //switch register bit index 2 
	static const int LED_BATT_STAT_R = 1003; //switch register bit index 3 
	static const int LED_ALARM = 1004; //switch register bit index 4
	static const int LED_START = 999;
	static const int BUT_START = 65; //GPIO pin number 65, physical pin number p2_65
	static const int BUT_FCT = 86; //GPIO pin number 86, physical pin number p2_35
	
	
	static const int LED_BATT_STAT_G = 17; //GPIO pin number 17, physical pin number 11 
	static const int LED_BATT_STAT_R = 27; //GPIO pin number 27, physical pin number 13 
	static const int LED_STATUS_R = 6; //GPIO pin number 6, physical pin number 31 
	static const int LED_STATUS_G = 5; //GPIO pin number 5, physical pin number 29 
	static const int LED_ALARM = 22; //GPIO pin number 22, physical pin number 15
	static const int SR_SHIFT = 13; //GPIO pin number 13, physical pin number 33
	static const int SR_OUTPUT = 19; //GPIO pin number 19, physical pin number 35
	static const int SR_DATA = 16; //GPIO pin number 16, physical pin number 36
	static const int LED_laser = 7; //GPIO pin number 7, physical pin number 26
	static const int LED_START = 25; //GPIO pin number 25, physical pin number 22
	static const int BUT_START = 24; //GPIO pin number 24, physical pin number 18
	static const int BUT_FCT = 23; //GPIO pin number 23, physical pin number 16
	static const int ADC_0 = 26; //GPIO pin number 26, physical pin number 37
	static const int ADC_1 = 20; //GPIO pin number 20, physical pin number 38
	static const int ADC_2 = 21; //GPIO pin number 21, physical pin number 40
	static const int POWER_DOWN = 4; //GPIO pin number 4, physical pin number 7 
	static const int CamPower = 18; ////GPIO pin number 18, physical pin number 12
	static const int CamReset = 20; ////(0=reset, 1=run) GPIO pin number 20, physical pin number p1_20 
	static const int JMP_LOW_POWER = 12; //GPIO pin number 12, physical pin number 32
	*/

#ifdef USE_LIBSOC
	static gpio *getPinWithNr(int nr) { return pinsForNumbers[nr]; }
	static std::map<int, gpio*> pinsForNumbers;

#else
#endif
};

