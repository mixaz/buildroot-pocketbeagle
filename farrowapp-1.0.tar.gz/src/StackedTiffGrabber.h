#pragma once
#include "FarrowImageGrabber.h"
#include <string>
#include "tiffio.h"
#include "DoubleBuffer.hpp"

#include <condition_variable>

#ifdef WIN32
#include "../VSDeveloperDefines.h"
#endif // WIN32

class FarrowApp;

class StackedTiffGrabber :
	public FarrowImageGrabber
{
public:
	StackedTiffGrabber(std::string pathToFiles, bool loop, int minFrameInterval, FarrowApp& app);
	~StackedTiffGrabber(void);

	virtual bool getLastGrabbed(ImageAndMetaData& lastImg) override;


	virtual bool allowSaving() { return false; }

	virtual std::string getGrabbedFileId();
	
	virtual bool grabbingEnded() override { return signalledDone; }

#ifndef TIFF_GRABBER_USE_QUEUE //Use queue on development machines with macro defined
	virtual bool useAnalysisQueue() override { return false;} 
#endif

	virtual std::string getSpecialRunningLogPath() override;


private:
	static void handleTiffError(const char *module, const char *fmt, va_list ap);
	virtual std::string getName() override { return "Stacked Tiff"; }

	DoubleBuffer <std::vector<ImageAndMetaData>> fileGrabDoubleBuffer;

	DoubleBuffer <std::string> fileNameBuffer;

	std::vector<std::string> files;
	int fileCount;
	int readFilesCount = 0;
	std::vector<ImageAndMetaData> lastWriteBuffer;
	//std::vector<ImageAndMetaData> currentReadBuffer;
	bool frontDoneReading = false;
	//bool backDoneWriting = false;
	TIFF *readFile;
	std::string dirPath;
	int currentImageIndex;
	//int imagesInStack;
	bool loop;
	bool firstFileGrabStarted = false;
	std::string frontBufFileName = "";
	std::string tifffFolderPath = "";
	bool grabbingDone = false;
	bool signalledDone = false;
	//DoubleBuffer<
protected:
	virtual bool grabberLoopUpdate() override;


	virtual void setupCameraFNC(std::function<void() > progressCB) override;


	virtual void stopCameraFNC(std::function<void() > progressCB) override;

};
