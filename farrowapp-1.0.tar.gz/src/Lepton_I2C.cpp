#include <unistd.h>
#include "Lepton_I2C.h"

#include "../lib/LeptonSDKEmb32MBLM/LEPTON_SDK.h"
#include "../lib/LeptonSDKEmb32MBLM/LEPTON_SYS.h"
#include "../lib/LeptonSDKEmb32MBLM/LEPTON_Types.h"
#include "../lib/LeptonSDKEmb32MBLM/LEPTON_VID.h"
#include "../lib/LeptonSDKEmb32MBLM/LEPTON_AGC.h"
#include "../lib/LeptonSDKEmb32MBLM/LEPTON_OEM.h"
//#include "LeptonSDKEmb32MBLM/LEPTON_RAD.h"
#include "FarrowLog.h"
#include "PinManager.h"
#include <math.h>

#include "stdio.h" //needed for printf() and fscanf()
#include "SystemWideVars.h"
#include "CrossPlatform.hpp"

LEP_STATUS_T sysStatus;
LEP_SYSTEM_STATUS_STATES_E camStatus;
LEP_AGC_ENABLE_E agcEnableState;
LEP_SYS_FFC_SHUTTER_MODE_OBJ_T shutterModeObj;
LEP_SYS_FFC_SHUTTER_MODE_E shutterMode;
LEP_SYS_SHUTTER_TEMP_LOCKOUT_STATE_E tempLockoutState;
LEP_SYS_ENABLE_E videoFreezeDuringFFC;
LEP_SYS_ENABLE_E FFCDesired;
LEP_UINT32 elapsedTimeSinceLastFFC;
LEP_UINT32 desiredFFCPeriod;
LEP_BOOL explicitCmdToOpen;
LEP_UINT16 desiredFFCTempDelta;
LEP_UINT16 imminentDelay;
LEP_SYS_SHUTTER_POSITION_E shutterPosition;
LEP_SYS_AUX_TEMPERATURE_CELCIUS_T T_aux;
LEP_SYS_FPA_TEMPERATURE_CELCIUS_T T_fpa;
LEP_SYS_UPTIME_NUMBER_T uptime;
LEP_SYS_FLIR_SERIAL_NUMBER_T sysFlirSerialNumber;
LEP_SYS_STATUS_E status;
LEP_SYS_FRAME_AVERAGE_DIVISOR_E numFrameToAverage;
LEP_VID_SBNUC_ENABLE_E SBNUC_status;
LEP_OEM_COLUMN_NOISE_ESTIMATE_CONTROL_T ColumnNoiseEstimateControl;
LEP_OEM_STATE_E oemColumnNoiseEstimateEnable;
LEP_OEM_TEMPORAL_FILTER_CONTROL_T TemporalFilterControl;
LEP_OEM_STATE_E oemTemporalFilterEnable;
//LEP_RAD_ENABLE_E radEnableState;

bool autoFFC = false;

bool _connected;
LEP_RESULT LepRes;
int pwr; //added
struct timespec time_now;
unsigned long int t_now = 0; //ms
unsigned long int t_on = 0; //ms
unsigned long int t_connect = 0; //ms
unsigned long int t_interval = 0; //ms

LEP_CAMERA_PORT_DESC_T _port;

//wiringPiSetupGpio(); //uses the Broadcom GPIO pin numbers //added

//pinMode(CamPWR,OUTPUT);

int lepton_connect() {
	AppLog::write("Connecting lepton");
	
	SystemWideVars::i2cLock.lock();
	LepRes = LEP_OpenPort(1, LEP_CCI_TWI, 100, &_port); //added
	SystemWideVars::i2cLock.unlock();
	
	//LEP_OpenPort(1, LEP_CCI_TWI, 400, &_port);
	if(LepRes == LEP_OK){ //added
		_connected = true;
		AppLog::write("Lepton connected"); //added
		return 0;
	} //added
	else { //added
		_connected = false; //added
		AppLog::write("Failed to connect Lepton"); //added
		return(LEP_COMM_INVALID_PORT_ERROR); //added
	} //added
}


int lepton_disconnect() {
	SystemWideVars::i2cLock.lock();
	LEP_ClosePort(&_port);
	SystemWideVars::i2cLock.unlock();
	
	_connected = false;
	return 0;
}

void lepton_log_information() {
	if(!_connected) {
		lepton_connect();
	}

	//write AGC setting
	SystemWideVars::i2cLock.lock();
	LEP_GetAgcEnableState(&_port, &agcEnableState);
	SystemWideVars::i2cLock.unlock();
	
	AppLog::write("AGC status: " + std::to_string((int) (agcEnableState)));

	//write scene-based non-uniformity correction algorithm setting

	SystemWideVars::i2cLock.lock();
	LEP_GetVidSbNucEnableState(&_port, &SBNUC_status);
	SystemWideVars::i2cLock.unlock();
	
	AppLog::write("SBNUC status: " + std::to_string((int) (SBNUC_status)));

	//write column noise filter settings
	SystemWideVars::i2cLock.lock();
	LEP_GetOemColumnNoiseEstimateControl(&_port, &ColumnNoiseEstimateControl);
	SystemWideVars::i2cLock.unlock();
	
	AppLog::write("Column noise filter status: " + std::to_string((int) (ColumnNoiseEstimateControl.oemColumnNoiseEstimateEnable)));

	//write temporal filter settings
	SystemWideVars::i2cLock.lock();
	LEP_GetOemTemporalFilterControl(&_port, &TemporalFilterControl);
	SystemWideVars::i2cLock.unlock();
	
	AppLog::write("Temporal filter status: " + std::to_string((int) (TemporalFilterControl.oemTemporalFilterEnable)));

	//write shutter position and shutter mode
	SystemWideVars::i2cLock.lock();
	LEP_GetSysShutterPosition(&_port,&shutterPosition);
	SystemWideVars::i2cLock.unlock();
	
	AppLog::write("Shutter position: " + std::to_string((int) (shutterPosition)));
	
	SystemWideVars::i2cLock.lock();
	LEP_GetSysFfcShutterModeObj(&_port, &shutterModeObj);
	SystemWideVars::i2cLock.unlock();
	
	AppLog::write("FFC shutter mode: " + std::to_string((int) (shutterModeObj.shutterMode)));

	//write serial number of camera chip and camera uptime

	SystemWideVars::i2cLock.lock();
	LEP_GetSysFlirSerialNumber(&_port, &sysFlirSerialNumber);
	SystemWideVars::i2cLock.unlock(); 
	
	AppLog::write("FLIR serial number: " + std::to_string((unsigned long long int) (sysFlirSerialNumber)));

	SystemWideVars::i2cLock.lock();
	LEP_GetSysCameraUpTime(&_port, &uptime);
	SystemWideVars::i2cLock.unlock(); 
	
	AppLog::write("Camera uptime (hours): " + std::to_string((float) ((float)(uptime)/3600000)));

	//write temperatures
	//LEP_GetSysAuxTemperatureCelcius(&_port,&T_aux);
	//printf("Camera temperature (Celcius): %f\n", T_aux);
	//AppLog::write("Camera temperature (Celcius): " + std::to_string((float) (T_aux)));

	SystemWideVars::i2cLock.lock();
	LEP_GetSysFpaTemperatureCelcius(&_port, &T_fpa);
	SystemWideVars::i2cLock.unlock(); 
	
	//printf("Camera FPA temperature (Celcius): %f\n", T_fpa);
	AppLog::write("Camera FPA temperature (Celcius): " + std::to_string((float) (T_fpa)));
	float T_cpu = read_T_cpu();
	AppLog::write("CPU temperature (Celcius): " + std::to_string((float) (T_cpu)));
}


float read_T_cpu() {
	FILE *temperatureFile;
	float T_cpu;
	temperatureFile = fopen("/sys/class/thermal/thermal_zone0/temp","r");
	fscanf(temperatureFile,"%f",&T_cpu);
	T_cpu/=1000;
	fclose(temperatureFile);
	return T_cpu;
	//printf("CPU temperature (Celcius): %f\n", T_cpu);
}

float lepton_read_T_aux() {
	if(!_connected) {
		lepton_connect();
	}
	//LEP_GetSysAuxTemperatureCelcius(&_port,&T_aux);
	//return T_aux;
	return 0;
}

float lepton_read_T_fpa() {
	if(!_connected) {
		lepton_connect();
	}
	
	SystemWideVars::i2cLock.lock();
	LEP_GetSysFpaTemperatureCelcius(&_port,&T_fpa);
	SystemWideVars::i2cLock.unlock();
	
	return (float) (T_fpa);
}


void lepton_stop(std::function<void()> progressFnc)
{
	printf("will disconnect\n");
	lepton_disconnect();
	CrossPlatform::threadSleep(100);
	progressFnc();
	printf("will set reset cam to 0\n");
	PinManager::PinManager::digitalWrite(PinManager::CamReset, 0);
	progressFnc();
	printf("will will set cam power to 0\n");
	CrossPlatform::threadSleep(100);
	PinManager::PinManager::digitalWrite(PinManager::CamPower, 0);
	progressFnc();
	printf("will set flir power to 0\n");
	CrossPlatform::threadSleep(100);
	//FLIR_PWR commented out as it
	//PinManager::digitalWrite(PinManager::FLIR_PWR, 0); 
	progressFnc();
	printf("did power down flir\n");
	CrossPlatform::threadSleep(100);
	progressFnc();

	// TODO: check if camera is really stopped
}

void lepton_initialize(bool useShutter, bool useNoiseFilters, std::function<void()> progressFnc) {

#ifdef BEAGLE_BONE
	PinManager::digitalWrite(PinManager::FLIR_PWR, 1); //Set power on for the entire FLIR board
#endif

	CrossPlatform::threadSleep(100); // sleep 100ms to ensure board started

	AppLog::write("Initializing camera");
	//Set camera power to OFF
	pinMode(PinManager::CamPower, OUTPUT);
	PinManager::digitalWrite(PinManager::CamPower, 0);
	PinManager::digitalWrite(PinManager::CamReset, 0); // Active low - reset activates when set to 0. Pull high to exit reset state
	pwr = PinManager::digitalRead(PinManager::CamPower);
	progressFnc();
	usleep(500000);
	progressFnc();
	AppLog::write("Camera Power state: " + std::to_string((int) (pwr)));
	usleep(1000000);
	progressFnc();

	//setting shutter mode object
	//LEP_SYS_FFC_SHUTTER_MODE_OBJ_T shutterModeObj;
    //initFFCShutterMode(shutterModeObj);
    if(useShutter) {
        if(autoFFC) {
		AppLog::write("Running Lepton camera with automatic shutter");
		shutterModeObj.shutterMode = LEP_SYS_FFC_SHUTTER_MODE_AUTO; //default: Auto
	        shutterModeObj.tempLockoutState = LEP_SYS_SHUTTER_LOCKOUT_INACTIVE; //default: Inactive. If active, the state changes when the temperature is outside of the -10C to +65C operating range.
	        shutterModeObj.videoFreezeDuringFFC = LEP_SYS_ENABLE; //default: Enable
	        shutterModeObj.ffcDesired = LEP_SYS_DISABLE; //default: Disable
	        shutterModeObj.elapsedTimeSinceLastFfc =(LEP_UINT32)0x0; //default: 0 ms
	        shutterModeObj.desiredFfcPeriod = (LEP_UINT32)3600000; //default: 300000 ms
	        shutterModeObj.explicitCmdToOpen = (LEP_BOOL)false; //default: false
	        shutterModeObj.desiredFfcTempDelta = (LEP_UINT16)300; //default: 300 deciKelvin. When the temperature has increased by 3 degrees, FFC is desired.
	        shutterModeObj.imminentDelay = (LEP_UINT16)60; //default: 52 frames. Enters "imminent FFC state" 52 frames before an FFC is carried out.
	}
	else {
		AppLog::write("Running Lepton camera with manual shutter");
		shutterModeObj.shutterMode = LEP_SYS_FFC_SHUTTER_MODE_MANUAL;
		shutterModeObj.tempLockoutState = LEP_SYS_SHUTTER_LOCKOUT_INACTIVE;
		shutterModeObj.videoFreezeDuringFFC = LEP_SYS_ENABLE;
		shutterModeObj.ffcDesired = LEP_SYS_DISABLE;
		shutterModeObj.elapsedTimeSinceLastFfc = (LEP_UINT32)0x0;
		shutterModeObj.desiredFfcPeriod = (LEP_UINT32)0xFFFFFFFF;
		shutterModeObj.explicitCmdToOpen = (LEP_BOOL)false;
		shutterModeObj.desiredFfcTempDelta = (LEP_UINT16)0xFFFF;
		shutterModeObj.imminentDelay = (LEP_UINT16)0xFFFF;
	}
    }
    else {
	AppLog::write("Running Lepton camera without shutter");
        shutterModeObj.shutterMode = LEP_SYS_FFC_SHUTTER_MODE_EXTERNAL;
        shutterModeObj.tempLockoutState = LEP_SYS_SHUTTER_LOCKOUT_INACTIVE;
        shutterModeObj.videoFreezeDuringFFC = LEP_SYS_DISABLE;
        shutterModeObj.ffcDesired = LEP_SYS_DISABLE;
        shutterModeObj.elapsedTimeSinceLastFfc =(LEP_UINT32)0x0;
        shutterModeObj.desiredFfcPeriod = (LEP_UINT32)0xFFFFFFFF;
        shutterModeObj.explicitCmdToOpen = (LEP_BOOL)true;
        shutterModeObj.desiredFfcTempDelta = (LEP_UINT16)0xFFFF;
        shutterModeObj.imminentDelay = (LEP_UINT16)0xFFFF;
    }
	
	//Set camera power to ON
	PinManager::digitalWrite(PinManager::CamPower, 1);
	PinManager::PinManager::digitalWrite(PinManager::CamReset, 1);
	progressFnc();
	clock_gettime(CLOCK_MONOTONIC, &time_now);
	t_on = time_now.tv_sec*1000 + time_now.tv_nsec/1000000;
	usleep(100000);
	progressFnc();
	pwr = PinManager::digitalRead(PinManager::CamPower);
	AppLog::write("Camera Power state: " + std::to_string((int) (pwr)));

	SystemWideVars::i2cLock.lock(); //Aquire lock before wait
	clock_gettime(CLOCK_MONOTONIC, &time_now);
	t_connect = time_now.tv_sec*1000 + time_now.tv_nsec/1000000;
	//Setup I2C connection
	if (!_connected) {
		lepton_connect();
	}
	progressFnc();

	if (_connected) {
		clock_gettime(CLOCK_MONOTONIC, &time_now);
		t_now = time_now.tv_sec*1000 + time_now.tv_nsec/1000000;
		AppLog::write("Time to connect Lepton [ms]: " + std::to_string((int) (t_now-t_connect)));
	}
	
	auto timeSinceOn = time_now.tv_sec * 1000 + time_now.tv_nsec / 1000000 - t_on;
	CrossPlatform::threadSleep(1200 - timeSinceOn); // Sleep until an entire second past t_on

	progressFnc();
	while ((time_now.tv_sec*1000 + time_now.tv_nsec/1000000 - t_on ) < 1250) { // INcrement time slowly until 1250ms past t_on
		clock_gettime(CLOCK_MONOTONIC, &time_now);
	}

	//setting up camera
	if (_connected) {
		clock_gettime(CLOCK_MONOTONIC, &time_now);
		t_interval = time_now.tv_sec*1000 + time_now.tv_nsec/1000000-t_on;
		AppLog::write("Time from power up to initialization [ms]: " + std::to_string((int) (t_interval)));

		AppLog::write("locking to set shutter mode");
		LEP_SetSysFfcShutterModeObj(&_port, shutterModeObj);
		progressFnc();
		AppLog::write("Done setting shutter mode");
		SystemWideVars::i2cLock.unlock(); //Mutex was locked already in parent scope

		SystemWideVars::i2cLock.lock();
		AppLog::write("Getting sys cam up time");
		LEP_GetSysCameraUpTime(&_port, &uptime);
		progressFnc();
		AppLog::write("Done getting sys cam up time");
		SystemWideVars::i2cLock.unlock(); 
		
		AppLog::write("Camera uptime [ms]: " + std::to_string((int) ((int)(uptime))));

	//setting shutter position
		if (useShutter) {
			SystemWideVars::i2cLock.lock();
			LEP_SetSysShutterPosition(&_port, LEP_SYS_SHUTTER_POSITION_UNKNOWN); //default: Unknown
			progressFnc();
			SystemWideVars::i2cLock.unlock();
    	}
		else {
			SystemWideVars::i2cLock.lock();
			LEP_SetSysShutterPosition(&_port, LEP_SYS_SHUTTER_POSITION_OPEN);
			progressFnc();
			SystemWideVars::i2cLock.unlock();
		}
	
		SystemWideVars::i2cLock.lock();
		LEP_GetSysShutterPosition(&_port, &shutterPosition);
		progressFnc();
		SystemWideVars::i2cLock.unlock();
	
		//printf("Shutter position: %u\n", shutterPosition);
		AppLog::write("Shutter position: " + std::to_string((int) (shutterPosition)));

   		 //setting number of frames to average
		if (useShutter) {
			SystemWideVars::i2cLock.lock();
			LEP_SetSysFramesToAverage(&_port, LEP_SYS_FA_DIV_8); //default: LEP_SYS_FA_DIV_8
			SystemWideVars::i2cLock.unlock();

			progressFnc();
			SystemWideVars::i2cLock.lock();
			LEP_GetSysFramesToAverage(&_port, &numFrameToAverage);
			SystemWideVars::i2cLock.unlock(); 

			progressFnc();
			AppLog::write("FFC number of frames to average: " + std::to_string((int) pow(2,(int) (numFrameToAverage))));
	}
	
	SystemWideVars::i2cLock.unlock(); //If camera was not connected, this will unlock the lock set earlier

	//setting noise filters
	if (useNoiseFilters) {
		ColumnNoiseEstimateControl.oemColumnNoiseEstimateEnable = LEP_OEM_ENABLE;
		TemporalFilterControl.oemTemporalFilterEnable = LEP_OEM_ENABLE;
	}
	else {
		ColumnNoiseEstimateControl.oemColumnNoiseEstimateEnable = LEP_OEM_DISABLE;
		TemporalFilterControl.oemTemporalFilterEnable = LEP_OEM_DISABLE;
	}
	SystemWideVars::i2cLock.lock();
	LEP_SetOemColumnNoiseEstimateControl(&_port, ColumnNoiseEstimateControl);
	SystemWideVars::i2cLock.unlock();

	progressFnc();
	SystemWideVars::i2cLock.lock();
	LEP_GetOemColumnNoiseEstimateControl(&_port, &ColumnNoiseEstimateControl);
	SystemWideVars::i2cLock.unlock();

	progressFnc();
	AppLog::write("Column noise filter status: " + std::to_string((int) (ColumnNoiseEstimateControl.oemColumnNoiseEstimateEnable)));

	SystemWideVars::i2cLock.lock();
	LEP_SetOemTemporalFilterControl(&_port, TemporalFilterControl);
	SystemWideVars::i2cLock.unlock();

	progressFnc();
	SystemWideVars::i2cLock.lock();
	LEP_GetOemTemporalFilterControl(&_port, &TemporalFilterControl);
	SystemWideVars::i2cLock.unlock();

	progressFnc();
	AppLog::write("Temporal filter status " + std::to_string((int) (TemporalFilterControl.oemTemporalFilterEnable)));

	//disable AGC

	SystemWideVars::i2cLock.lock();
	LEP_SetAgcEnableState(&_port, LEP_AGC_DISABLE);
	SystemWideVars::i2cLock.unlock(); 

	progressFnc();
	SystemWideVars::i2cLock.lock();
	LEP_GetAgcEnableState(&_port, &agcEnableState);
	SystemWideVars::i2cLock.unlock(); 
	
	//printf("agcEnableState: %d\n", agcEnableState);
	AppLog::write("AGC status: " + std::to_string((int) (agcEnableState)));

	//enable or disable scene-based non-uniformity correction algorithm

	SystemWideVars::i2cLock.lock();
	LEP_SetVidSbNucEnableState(&_port, LEP_VID_SBNUC_DISABLE);
	SystemWideVars::i2cLock.unlock(); 

	progressFnc();
	SystemWideVars::i2cLock.lock();
	LEP_GetVidSbNucEnableState(&_port, &SBNUC_status);
	SystemWideVars::i2cLock.unlock(); 

	progressFnc();
	//printf("SBNUC status: %d\n", SBNUC_status);
	AppLog::write("SBNUC status: " + std::to_string((int) (SBNUC_status)));

	//enable or disable radiometry
	//LEP_SetRadEnableState(&_port, LEP_RAD_DISABLE);

	//get serial number of camera chip

	SystemWideVars::i2cLock.lock();
	LEP_GetSysFlirSerialNumber(&_port, &sysFlirSerialNumber);
	SystemWideVars::i2cLock.unlock(); 

	progressFnc();
	//printf("FLIR serial number: %llu\n", sysFlirSerialNumber);
	AppLog::write("FLIR serial number: " + std::to_string((unsigned long long int) (sysFlirSerialNumber)));
	//LEP_GetSysStatus(&_port, &sysStatus);
	//AppLog::write("Lepton status: " + std::to_string((int) (sysStatus.camStatus)));
	if(useShutter && !autoFFC) {
		usleep(150000);
		//LEP_GetSysStatus(&_port, &sysStatus);
		//AppLog::write("Lepton status: " + std::to_string((int) (sysStatus.camStatus)));
		AppLog::write("Performing FFC");
		if(!_connected) {
			lepton_connect();
			usleep(150000);
		}
		usleep(200000); // give enough time here!
		//LEP_RunRadFFC(&_port);

		SystemWideVars::i2cLock.lock();
		LEP_RunSysFFCNormalization(&_port); // FFC fails if initiated too shortly after connecting or after modifying settings
		SystemWideVars::i2cLock.unlock(); 
	}

	SystemWideVars::i2cLock.lock();
	LEP_GetSysStatus(&_port, &sysStatus);
	SystemWideVars::i2cLock.unlock(); 

	progressFnc();
	if(sysStatus.camStatus == LEP_SYSTEM_READY) {
		AppLog::write("Lepton ready");
	}
	AppLog::write("Camera initialized\n");
	}
	else {
		AppLog::write("Failed to initialize camera\n");
		PinManager::digitalWrite(PinManager::CamPower, 0);
	}
}
