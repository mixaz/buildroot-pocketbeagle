#include "StackedTiffGrabber.h"
#include "CrossPlatform.hpp"
#include "FarrowLog.h"
#include "FarrowApp.h"

using namespace std;
using namespace cv;

StackedTiffGrabber::StackedTiffGrabber(std::string pathToFiles, bool loop, int minFrameInterval, FarrowApp& app) :FarrowImageGrabber(app),
	loop(loop)
{
	currentImageCount = 0;
	currentImageIndex = 0;
	tifffFolderPath = pathToFiles;
	files = CrossPlatform::getFiles(pathToFiles, ".tif");

	sort(files.begin(), files.end());

	TIFFSetErrorHandler(&(StackedTiffGrabber::handleTiffError));

	fileCount = files.size();
}



StackedTiffGrabber::~StackedTiffGrabber(void)
{
	
}

bool StackedTiffGrabber::getLastGrabbed(ImageAndMetaData& lastImg)
{
	if (!isReady())
	{
		return false;
	}

	bool newImg = false;

	vector<ImageAndMetaData> frontStack = fileGrabDoubleBuffer.getFront();
	frontBufFileName = fileNameBuffer.getFront();

	if (currentImageIndex < frontStack.size())
	{
		ImageAndMetaData iAMD = frontStack[currentImageIndex++];

		iAMD.metaData.imgNr = currentImageCount++;

		lastImg = iAMD;
		newImg = true;
	}
	else
	{
		if (!frontDoneReading) {
			//AppLog::write("Front is done reading");
		}
		frontDoneReading = true;
		if (grabbingDone && !signalledDone)
		{
			signalledDone = true;
		}
	}
	return newImg;
}



std::string StackedTiffGrabber::getGrabbedFileId()
{
	return frontBufFileName.substr(frontBufFileName.find_last_of(CrossPlatform::getFolderDelimiter()) + 1);
}


std::string StackedTiffGrabber::getSpecialRunningLogPath()
{
	return tifffFolderPath + crossPlatformFolderDelimiter + "Analysis_" + Util::getTimeStampNow(true);
}


void StackedTiffGrabber::handleTiffError(const char *module, const char *fmt, va_list ap)
{
	char msg[1024];
	sprintf(msg, "LibTiffError:\n Module: %s,\nfmt: %s,\nap: %s\n\n", module, fmt, ap);
	AppLog::write(msg);
}

bool StackedTiffGrabber::grabberLoopUpdate()
{

	if (readFilesCount >= fileCount)
	{
		grabbingDone = true;
		return false;
	}
	else
	{
		//Check if it is either first time we write to buffer or whether the back buffer has changed
		if (!firstFileGrabStarted || lastWriteBuffer != fileGrabDoubleBuffer.getBack())
		{
			//Start by loading tiff frames and assigning them to the back of the doubleBuffer
			firstFileGrabStarted = true;
			int imagesInStack = 0;
			
			
			vector<ImageAndMetaData> imagesAndMeta;

			auto file = files[readFilesCount++];

			string fileString = string(file.begin(), file.end());

			AppLog::write("Reading tiff-images from file: " + fileString);

			readFile = TIFFOpen(fileString.c_str(), "r");

			int nextToRead = 0;
			while (TIFFLastDirectory(readFile) == 0 && grabLoopRunning)
			{
				Mat curFrame;

				FarrowImageMetaData fMD;

				uint32 w, h;

				ushort bits_per_sample = -1, samples_per_pixel = -1;

				TIFFGetField(readFile, TIFFTAG_IMAGEWIDTH, &w);
				TIFFGetField(readFile, TIFFTAG_IMAGELENGTH, &h);
				TIFFGetField(readFile, TIFFTAG_SAMPLESPERPIXEL, &samples_per_pixel);
				TIFFGetField(readFile, TIFFTAG_BITSPERSAMPLE, &bits_per_sample);

				curFrame = Mat(h, w, bits_per_sample == 16 ? CV_16UC1 : CV_8UC1);
				bool success = true;

				std::size_t stride = w * bits_per_sample / 8;

				for (int i = 0; i < h; i++)
				{
					int status = TIFFReadScanline(readFile, (void *)(curFrame.data + (i * stride)), i);
					if (status < 0)
					{
						success = false;
						break;
					}
				}

				if (success && curFrame.rows != 0 && curFrame.cols != 0)
				{
					char *comment;
					if (TIFFGetField(readFile, TIFFTAG_IMAGEDESCRIPTION, &comment) > 0)
					{

						fMD = FarrowImageMetaData(comment);

						fMD.imgNr = grabbedCount++;
						ImageAndMetaData iAMD(curFrame, fMD);
						try
						{
							imagesAndMeta.push_back(iAMD);
						}
						catch (Exception e)
						{
							AppLog::write("Got exception: " + to_string(e.code));
						}

						imagesInStack++;
					}
				}
				else
				{
					AppLog::write("Err while reading TIFF: " + to_string(nextToRead));
				}

				TIFFSetDirectory(readFile, nextToRead++);
			}
			//AppLog::write("Done reading " + to_string(nextToRead) + " TIFF files. image stack size: " + to_string(imagesAndMeta.size()) );
			TIFFClose(readFile);
			
			fileGrabDoubleBuffer.assignBack(imagesAndMeta);
			fileNameBuffer.assignBack(fileString.substr(fileString.find_last_of(CrossPlatform::getFolderDelimiter()))); // Strip actual filename from path
			
			lastWriteBuffer = fileGrabDoubleBuffer.getBack();
			
			//When all the tiff-files have been loaded and assigned to the back-buffer,
			//Wait for reading of the frontBuffer to complete and then swap.
			while (!frontDoneReading && grabLoopRunning)
			{
				CrossPlatform::threadSleep(100);
			}
			frontDoneReading = false;
			currentImageIndex = 0;
			fileGrabDoubleBuffer.swap();
			fileNameBuffer.swap();
		}
	}
	return true;
}

void StackedTiffGrabber::setupCameraFNC(std::function<void() > progressCB)
{
#ifdef TIFFGRABBER_SIMULATE_SETUP
	for (int i = 0; i < 15; i++)
	{
		CrossPlatform::threadSleep(50 + 100 * (i % 3));
		progressCB();
	}
#endif
}

void StackedTiffGrabber::stopCameraFNC(std::function<void() > progressCB)
{
#ifdef TIFFGRABBER_SIMULATE_SETUP
	for (int i = 0; i < 7; i++)
	{
		CrossPlatform::threadSleep(100 + 50 * (i % 4));
		progressCB();
	}
#endif
}

