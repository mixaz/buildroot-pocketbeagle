#include "PinManager.h"
#include <fstream>
#include <string>
#include <stdexcept>
#include "FarrowLog.h"

#ifdef WIN32
#else
#include <stdio.h>
#include <unistd.h>
#include <dirent.h>
#endif



void PinManager::setupAllPins()
{
#ifdef BEAGLE_BONE
	auto setPin = [=](int _pinNr, int _pinMode, int _level = 0) -> void
	{
		pinMode(_pinNr, _pinMode);

		if (_pinMode == OUTPUT)
		{			
			digitalWrite(_pinNr, _level);
		}
	};

	setPin(BOARD_PWR, OUTPUT, 1);
	setPin(FLIR_PWR, OUTPUT, 1);
	setPin(DISPLAY_BOARD_PWR, OUTPUT, 1);
	setPin(SR_OUTPUT, OUTPUT, 0);
	setPin(SR_DATA, OUTPUT, 0);
	setPin(LED_laser, OUTPUT, 0);	
	setPin(CamReset, OUTPUT, 0);
	setPin(CamPower, OUTPUT, 0);

#else
	//Lambda setting pin settings in one go
	auto setPin = [=](int _pinNr, int _pinMode, int _upDown) -> void {
		pinMode(_pinNr, _pinMode);
		if (_pinMode == _INPUT)
			pullUpDnControl(_pinNr, _upDown);
		else if (_pinMode == OUTPUT)
			digitalWrite(_pinNr, _upDown);
	};

	//setPin(POWER_DOWN, _INPUT, PUD_UP);
	//setPin(LED_BATT_STAT_G, OUTPUT, 0);
	//setPin(LED_BATT_STAT_R, OUTPUT, 0);
	//setPin(LED_STATUS_R, OUTPUT, 1);
	//setPin(LED_STATUS_G, OUTPUT, 1);
	//setPin(LED_ALARM, OUTPUT, 0);
	//setPin(SR_SHIFT, OUTPUT, 0);
	//setPin(SR_OUTPUT, OUTPUT, 0);
	//setPin(SR_DATA, OUTPUT, 0);
	//setPin(ADC_0, _INPUT, PUD_DOWN);
	//setPin(ADC_1, _INPUT, PUD_DOWN);
	//setPin(ADC_2, _INPUT, PUD_DOWN);

	//setPin(JMP_LOW_POWER, _INPUT, PUD_UP);
	//setPin(LED_laser, OUTPUT, 0);
	//setPin(LED_START, OUTPUT, 0);
	//setPin(CamPWR, OUTPUT, 0);
#endif

}

bool PinManager::digitalRead(int pin)
{
#ifdef WIN32
#else
	std::fstream fs;
	std::string path = "/sys/class/gpio/gpio" + std::to_string(pin) + "/value";
	fs.open(path, std::fstream::in);

	// if good() == true GPIO is exported and ready to use
	if (!fs.good())
	{
		fs.close();
		throw std::runtime_error("Could open GPIO " + std::to_string(pin) + " for reading");
	}

	int val;
	fs >> val;

	fs.close();

	return val == 0 ? false : true;
#endif

	return false;
}

void PinManager::digitalWrite(int pin, int value)
{
#ifdef WIN32
#else
	std::fstream fs;
	std::string path = "/sys/class/gpio/gpio" + std::to_string(pin) + "/value";
	fs.open(path, std::fstream::out);

	// if good() == true GPIO is exported and ready to use
	if (!fs.good())
	{
		fs.close();
		throw std::runtime_error("Could not open GPIO " + std::to_string(pin) + " for writing");
	}

	fs << value;
	fs.close();
#endif
}

void PinManager::pinMode(int pin, int mode)
{
#ifdef WIN32
#else
	std::fstream fs;
	std::string path = "/sys/class/gpio/gpio" + std::to_string(pin);

	DIR* expdir = opendir(path.c_str());

	if (!expdir)
	{
		fs.open("/sys/class/gpio/export", std::fstream::out);
		fs << pin;
		fs.close();
		usleep(100000);
	}
	closedir(expdir);

	try
	{
		fs.open(path + "/direction", std::fstream::out);

		// if good() == true GPIO is exported and ready to use
		if (!fs.good())
		{
			fs.close();
			throw std::runtime_error("Could not open GPIO " + std::to_string(pin) + " to set direction");
		}

		if (mode == 1)
		{
			fs << "out";
		}
		else if (mode == 0)
		{
			fs << "in";
		}
		else
		{
			fs.close();
			throw std::logic_error("variable 'mode' of PinMode() must be 0 or 1, was " + std::to_string(mode));
		}
	}
	catch (std::fstream::failure& e)
	{
		AppLog::write("Exception while setting mode of GPIO" + std::to_string(pin) + ": " + std::string(e.what()));
	}

	fs.close();
#endif
}

