#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include "FarrowTimer.h"
#include <set>
#include <mutex>
#include <chrono>
#include "DoubleBuffer.hpp"
#include <iosfwd>
#include <stdarg.h>

class FarrowLog
{
public:
	FarrowLog(std::string filePath, FarrowTimer& timer, bool subscribeToGlobalLog);
	~FarrowLog();
	void writeToFile(bool aquireMutexLock = true);
	void write(std::string message, bool addTimestamp = true, bool flushNow = true);

private:
	std::string filePath;
	std::mutex doubleBufferMutex;
	DoubleBuffer<std::string> doubleBufferStream;
	std::ofstream *fileStream;
	FarrowTimer& timer;
	std::chrono::system_clock worldClock;
	bool hasUnwrittenData = true;
	
};

class AppLog
{
public:

	static void registerLog(FarrowLog *fL, bool subscribeToGlobalMessages)
	{
		instance()->logSetMutex.lock();
		
		instance()->registeredLogs.insert(fL);
		if (subscribeToGlobalMessages)
		{
			instance()->subscribingLogs.insert(fL);
		}
		
		instance()->logSetMutex.unlock();
	}

	static void deregisterLog(FarrowLog *fL)
	{
		instance()->logSetMutex.lock();
		instance()->registeredLogs.erase(fL);
		instance()->subscribingLogs.erase(fL);
		instance()->logSetMutex.unlock();
	}


	static void writef(char *fmt, ...)
	{
		std::lock_guard<std::mutex> lock(vsprintfMutex);
		va_list args;
		va_start(args, fmt);
		vsprintf(sprintfBuffer, fmt, args);
		va_end(args);
		
		std::string result(sprintfBuffer);

		AppLog::write(result);
	}
	static void write(std::string message, std::string origin = "",
		bool addTimestamp = true, bool flushNow = true, bool printToConsole = true)
	{

		instance()->logSetMutex.lock();
		
		std::string prefix = origin == "" ? "" : origin + "_";

		if (printToConsole)
			std::cout << prefix << message + "\n";
		
		for (auto fL : instance()->subscribingLogs)
		{
			if(fL == nullptr)
				continue;

			fL->write(prefix + message, addTimestamp, flushNow);
		}
		
		instance()->logSetMutex.unlock();
	}

	static void stopFileWriteLoop();

	static void fileWriteLoop();

	static AppLog *instance();

private:
	std::mutex logSetMutex;
	std::set<FarrowLog *> subscribingLogs;

	std::set<FarrowLog *> registeredLogs;
	
	static char sprintfBuffer[];
	static std::mutex vsprintfMutex;
};