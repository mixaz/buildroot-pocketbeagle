#pragma once
#include <atomic>
#include <condition_variable>
class DockerTfUtils
{
public:

	static const int containerStateSuccessCode = 0;

	static int getDockerContainerState(bool allowUseCached);


	static void signalConatinerNotRunning()
	{
		containerState_cached.store(-1);
	}
	static void startOrRestartTensorflowContainer();

	static void restartTensorFlowContainer();

	static std::atomic_int containerState_cached;

	static void notifyConditionVariables();
private:

	static bool isDockerServiceRunning();
	static std::condition_variable startedConfirmCondVar;
	static std::mutex startedConfirmCondMutex;
};

