#pragma once
#include "FarrowUI.h"

class FarrowApp;

class HeadlessUI :
	public FarrowUI
{
public:
	HeadlessUI(FarrowApp& fA);
	virtual ~HeadlessUI();

	virtual bool update() override;


	virtual std::string getName() override;



private:
	bool uiRunning = true;
	FarrowApp& app;
	static bool hasStartedRunningState;
	FarrowTimer UITimer;
	uint32_t secForLastPrint = 0;
	uint32_t imgCountForLastPrint = 0;
	uint32_t analysisCountForLastPrint = 0;
	uint32_t secsForLastImg;
	uint32_t secsForLastAnalysis;
#ifdef WIN32
	bool readyForNewInput = true;
#endif
};

