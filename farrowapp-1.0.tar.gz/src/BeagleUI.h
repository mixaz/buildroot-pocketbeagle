#pragma once
#include "BeagleDisplay.h"
#include "BeagleHardwareButton.h"
#include "BeagleKeypad.h"
#include "device_drivers/TCA9555_cpp.hpp"
#include "FarrowUI.h"
#include <queue>

#define ADC_PATH "/sys/bus/iio/devices/iio:device0/in_voltage"
#define ADC_V_CONV_RATE 22118.4 //(2 ^ 12)*1.8 * 3 = 22118.4

class FarrowApp;
	
class BeagleUI :
	public FarrowUI
{
public:

	enum Buttons
	{
		BTN_1,
		BTN_2,
		BTN_3,
		BTN_4,
		BTN_5,
		BTN_6,
		BTN_7,
		BTN_8,
		BTN_9,
		BTN_DEL,
		BTN_0,
		BTN_OK,
		BTN_START,
		BTN_ASSIST = 14
	};

	BeagleUI(FarrowApp& fA);
	virtual ~BeagleUI();

	virtual bool getPressedStart() override { return startBtn.getIsShortPress(); }
	virtual bool getPressedAssist() override { return assistBtn.getIsShortPress(); }
	virtual bool getPressedTime() override { return timeBtn.getIsShortPress(); }
	virtual bool getPressedLaser() override { return laserBtn.getIsShortPress(); }
	virtual bool getPressedLoraTest() override { return loraTestBtn.getIsShortPress(); }
	virtual bool getPressedSoftPowerDown() override { return startBtn.getIsVeryLongPress(); }
	virtual bool getPressedSleep() override { return startBtn.getIsLongPress(); }

	virtual bool update() override;

	virtual std::string getName() override { return "Beagle UI"; };
	virtual void setLEDValue(UIOutputType ledKey, float value) override;
	virtual unsigned char getBatteryLevelPercent() override;
	virtual double getBatteryVoltage() override;
	virtual void setSecsSinceBirth(int secs) override;
	virtual void toggleLaser(ToggleType togTyp = ToggleType::TOGGLE_TOGGLE) override;
	

	virtual void drawTextCentered(std::string txt) override;


	virtual void drawBattery(int percent) override {
		display.drawBattery(108, 32, percent);
		updateDisplay = true;
	};


	virtual void clearBattery() override {
		display.clearBattery();
		updateDisplay = true;
	};


	virtual void clearDisplay(bool forceNow) override;


	virtual int getNumberPressed() override { return nrDownThisFrame; };


	virtual bool getPressedBack() override { return backPressed_short; };


	virtual bool getPressedOK() override { return okPRessed_short; };


	virtual void setDisplayLine(std::string txt, int line) override;


	virtual void setDisplayOnOff(bool on) override;




	virtual bool getIsInCharger() override;

private:
	bool laserOn = false;
	TCA9555 tca;
	BeagleKeypad keypad;
	FarrowApp& app;
	BeagleHardwareButton startBtn;
	BeagleHardwareButton laserBtn;
	BeagleHardwareButton timeBtn;
	BeagleHardwareButton loraTestBtn;
	BeagleHardwareButton assistBtn;

	// For logging purposes
	int oldButton = -1;
	BeagleKeypad::ButtonStatus oldStatus = BeagleKeypad::ButtonStatus::UP;

	BeagleDisplay display;
	bool updateDisplay = false;

	int nrDownThisFrame = false;
	bool okPRessed_short = false;
	bool backPressed_short = false;

	int getPinForLED_Code(UIOutputType LEDCode);
	int readAnalog(int number);

	int currentState = -1;
	BeagleKeypad::ButtonStatus oldKeypadStatus = BeagleKeypad::NONE;
	int oldKeypadButton = -1;


	int bL1 = 0;
	int bL2 = 0;
	int bL3 = 0;
	double batteryVoltage = -1;

	StateCycle blinkCycle;
	float blinkValue = 0;
	float oldBlinkValue = 0;

	bool pollForSowNr = true;
	bool pollForPenNr = true;
	int startCount = 0;

	bool isAlarmed = false;
	bool watchMode = false;
	bool loraTestPassed = false;

	int tmpPigletCount = 0;
	int tmpLivecount = 0;
	int tmpDeadCount = 0;
};

