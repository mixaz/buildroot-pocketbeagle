#include "GraphicUI.h"
#include <string>
#include "opencv2/highgui/highgui.hpp"
#include <ctime>
#include <map>
#include "FarrowLog.h"
#include "FarrowApp.h"
using namespace std;
using namespace cv;

string UIControlWindowName = "FarrowApp Control";

string UIMonitorWindowName0 = "Monitor 0";

string UIPanelName = "Control Panel";
const int uiHeight = 500;
const int uiWidth = 292;
const Point2i displayOffset(50, 50);

const Point2i ledsOffset(50, 200);
const int uiLineHeight = 32;
const int uiLineWidth = 180	;
const int uiLineCount = 4;
const int uiBatteryWidth = 16;
const int uiBatteryHeight = 64;

Rect queueSizeRect(0, 64, 64, 32);


GraphicUI::GraphicUI(FarrowApp& app, bool doNormalise) : app(app)
{

	normaliseOutput = doNormalise;
	namedWindow(UIMonitorWindowName0, CV_WINDOW_NORMAL);
	namedWindow(UIPanelName, CV_WINDOW_NORMAL);

	resizeWindow(UIMonitorWindowName0, 400, 300);

	moveWindow(UIMonitorWindowName0, 340, 290);

	moveWindow(UIPanelName, 700, 640);

	resizeWindow(UIPanelName, uiWidth, uiHeight);
	
	outputTypeToNamesMap[LED_CODE_START] = "Start";
	outputTypeToNamesMap[LASER] = "Laser";
	outputTypeToNamesMap[THREE_DIGIT_DISPLAY] = "Three Digit Display";
	outputTypeToNamesMap[TWO_DIGIT_DISPLAY] = "Two Digit Display";
	outputTypeToNamesMap[LED_CODE_BATT_STAT_G] = "Battery status LED Green";
	outputTypeToNamesMap[LED_CODE_BATT_STAT_R] = "Battery status LED Red";
	outputTypeToNamesMap[LED_CODE__STATUS_R] = "LED Status RED";
	outputTypeToNamesMap[LED_CODE__STATUS_G] = "LED Status GREEN";
	initUIPanel();
}


GraphicUI::~GraphicUI()
{
}

void GraphicUI::initUIPanel()
{

	uiPanelMat = Mat::zeros(uiHeight, uiWidth, CV_8UC3);
	ledArea = Mat(uiPanelMat, Rect(ledsOffset.x, ledsOffset.y, uiLineWidth, uiLineHeight * 3));
	uiPanelMat.setTo(Color::grey);
	Rect displayRect(displayOffset.x, displayOffset.y, uiLineWidth, uiLineHeight * uiLineCount);
	
	//Make display line ROIs
	for (int i = 0; i < uiLineCount; i++)
	{
		Rect lineRect(displayOffset.x, displayOffset.y + i * uiLineHeight, uiLineWidth, uiLineHeight);
		Mat lineROI = Mat(uiPanelMat, lineRect);
		lineROI.setTo(Color::black);
		displayLineROIs.push_back(lineROI);
	}

	Rect batteryExternalRect = Rect(displayOffset.x + uiLineWidth - uiBatteryWidth, displayOffset.y + uiLineHeight * uiLineCount - uiBatteryHeight, uiBatteryWidth, uiBatteryHeight);

	batteryInternalRect = Rect(batteryExternalRect.x + 2, batteryExternalRect.y + 2, batteryExternalRect.width - 4, batteryExternalRect.height - 4);

	batteryInternalArea = Mat(uiPanelMat, batteryInternalRect);

	batteryWithBorderArea = Mat(uiPanelMat, batteryExternalRect);

	Rect centreRect = Rect(displayOffset.x, displayOffset.y + uiLineHeight * (uiLineCount * 0.5 - 0.5) , uiLineWidth, uiLineHeight);
	displayCentreLine = Mat(uiPanelMat, centreRect);

	ledLaser = GraphicUILED(ledArea, 0, "LASER", Color::darkRed);
	
	ledRG = GraphicUILED(ledArea, 1, "status", Color::white);
	ledAlarm = GraphicUILED(ledArea, 2, "Alarm", Color::white);

	
}

bool GraphicUI::update()
{

	lastKeyPress = waitKey(1);
	
	try
	{
		imshow(UIPanelName, uiPanelMat);
	}
	catch (cv::Exception* e)
	{
		AppLog::write("Got cv exception from imshow: " + e->err);
	}

	if (lastKeyPress == ',')
	{
		app.setBatteryLife(app.getBatteryLife() - 5);
		printf("Setting battery to: %i\n", app.getBatteryLife());
	}


	if (lastKeyPress == '.')
	{
		app.setBatteryLife(app.getBatteryLife() + 5);
		printf("Setting battery to: %i\n", app.getBatteryLife());
	}

	return true;
}

void GraphicUI::setHardwarePowerDown()
{
	AppLog::write("UI setting power down on hardware (Nothing happens here on pc)");
}

void GraphicUI::setLEDValue(UIOutputType ledKey, float value)
{
	if (ledKey == LED_CODE_ALARM)
	{
		ledAlarm.setValue(value);
	}
	else if (ledKey == LED_CODE__STATUS_G || ledKey == LED_CODE__STATUS_R)
	{
		if (ledKey == LED_CODE__STATUS_G)
			ledRGIsGreen = value;
		else
			ledRGIsRed = value;

		Scalar resultColor = ledRGIsGreen ?
			ledRGIsRed ? Color::yellow : Color::green :
			ledRGIsRed ? Color::red : Color::black;

		ledRG.setColor(resultColor);
		ledRG.setValue(1);
	}
	//Laser is not handled yet
}

void GraphicUI::updateGrabberImages(ImageAndMetaData& newImg)
{
	const string& monwWindowName = UIMonitorWindowName0;
		
	if(!newImg.image.empty())
	{
		if (imageNormalised.empty())
		{
			imageNormalised = newImg.image.clone();
		}
		if (normaliseOutput)
		{
			int max = 0;
			if (newImg.image.depth() == CV_16U)
				max = USHRT_MAX;
			else if (newImg.image.depth() == CV_8U)
				max = UCHAR_MAX;

			normalize(newImg.image, imageNormalised, 0, max, cv::NormTypes::NORM_MINMAX);
			imshow(monwWindowName, imageNormalised);
		}
		else
			imshow(monwWindowName, newImg.image);
	}
}


void GraphicUI::toggleLaser(ToggleType togTyp /*= ToggleType::TOGGLE_TOGGLE*/)
{
	laserOn = togTyp == ToggleType::TOGGLE_TOGGLE ? !laserOn : togTyp == ToggleType::TOGGLE_ON;
	ledLaser.setValue(laserOn);
}


void GraphicUI::setDisplayLine(std::string txt, int line)
{
	if (line < 1 || line > displayLineROIs.size())
	{
		throw std::logic_error("Number of lines in Graphic UI out of range");
	}
	Mat lineROI = displayLineROIs[line - 1];
	lineROI.setTo(Color::black);
	putText(lineROI, txt, Point(0, uiLineHeight * 0.7), FONT_HERSHEY_SIMPLEX, .9, Scalar(displayContrast, displayContrast, displayContrast), 1);
}


void GraphicUI::drawTextCentered(std::string txt)
{
	setDisplayLine("", 1);
	setDisplayLine("", 2);
	setDisplayLine("", 3);
	setDisplayLine("", 4);

	int stringLength = txt.length();

	int padding = (10 - stringLength) / 2;
	for (int i = 0; i < padding; i++)
	{
		txt = " " + txt + " ";
	}
	putText(displayCentreLine, txt, Point(0, uiLineHeight * 0.7), FONT_HERSHEY_SIMPLEX, .9, Scalar(displayContrast, displayContrast, displayContrast), 1);
}

void GraphicUI::drawBattery(int percent)
{
	Rect newBatteryInternalRect = batteryInternalRect;
	newBatteryInternalRect.height *= (float) percent / 100.0;
	newBatteryInternalRect.y += batteryInternalRect.height - newBatteryInternalRect.height;
	Mat newBatInternalMat(uiPanelMat, newBatteryInternalRect);
	batteryWithBorderArea.setTo(Color::red);
	newBatInternalMat.setTo(Color::green);
}

void GraphicUI::clearBattery()
{
	batteryWithBorderArea.setTo(Color::black);
}

void GraphicUI::clearDisplay(bool forceNow)
{
	for (auto roi : displayLineROIs)
	{
		roi.setTo(Color::black);
	}

	if (forceNow)
	{
		update();
	}
}

void GraphicUI::setDisplayOnOff(bool on)
{
	displayContrast = on ? 255 : 0;
	if (!on)
	{
		clearDisplay(true);
	}
}