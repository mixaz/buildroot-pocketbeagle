#pragma once

#include <ctime>
#include <thread>
#include <queue>
#include <mutex>
#include <atomic>
#include "tinyxml2.h"
#include "Request.hpp"
class FarrowApp;

class LoRaCommunicator
{
public:
	LoRaCommunicator(FarrowApp& app, std::queue<Request> stored);
	LoRaCommunicator(FarrowApp& app);
	~LoRaCommunicator();
	LoRaCommunicator(LoRaCommunicator&&) = delete;
	LoRaCommunicator(const LoRaCommunicator& ) = delete;

	bool connect();
	bool connected();

	void enqueRequest(const Request& req);

	void resume();
	void stop();
	void sendHeartbeat(bool onlyIfNeeded = true);
	void setActive(bool act) { active = act; activeIsSet = true; }
	std::unique_ptr<tinyxml2::XMLDocument> getQueuesAsXML();
private:
	bool newSession();
	bool restoreSession();
	void endSession();
	void handleQueueLoop();
	bool sendRequest(Request req);
	std::string sendMessage(const std::string& message);
	
	FarrowApp& app;
	std::thread loRaThread;
	std::queue<Request> liveRequests;
	std::queue<Request> storedRequests;
	std::recursive_mutex requestLock;
	std::recursive_mutex storedRequestLock;

	std::atomic_bool loraComRunning{ false };

	std::atomic_bool uartConnected;
	std::atomic_bool loraConnected; 
	FarrowTimer lastTransmissionTimer;
	unsigned long long lastTransmission_MS;
	bool sentHeartBeatWhenPossible = true;
	bool active = false;
	bool activeIsSet = false;
	std::atomic_bool hasReceivedTime{ false };
};

