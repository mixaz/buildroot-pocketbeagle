#include "PRU_test.h"

#include <stdlib.h>
#include <cstdio>
#include <cstring>

using namespace std;

#ifdef __linux__
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>

#include <sys/types.h>
#include <sys/mman.h>
#endif // __linux__
#include <string>
//static 

#ifdef __linux
int main(int argc, char* argv[])
{
	PRUTest pT;
	////////////////////////////////////////////////////////////
	////////	A P P     M A I N    L O O P            ////////
	////////////////////////////////////////////////////////////
	for (int i = 0; i < 1000; i++)
	{
		try
		{
			pT.update();
		}
		catch (int e)
		{
			printf("Got exception %i", e);

		}
		usleep(1000 *10);
		
	}

	return 0;
}
#endif // __linux__
