#include "PRU_test.h"

#include <stdlib.h>
#include <cstdio>
#include <cstring>

using namespace std;

#ifdef __linux__
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>

#include <sys/types.h>
#include <sys/mman.h>
#endif // __linux__
#include <string>

PRUTest::PRUTest()
{
#ifdef __linux__

	//Static sizes
	size_t psize = sysconf(_SC_PAGESIZE);
	int frame_size = sizeof(leptonpru_mmap);

	//Memeory-file
	fileDesc = open("/dev/leptonpru", O_RDWR | O_SYNC/* | O_NONBLOCK*/);


	if (fileDesc < 0) {
		perror("open");
		assert(0);
	}
	printf("fileDesc = %d, FRAME_SIZE=%d, page_size: %d\n", fileDesc, frame_size, psize);

	for (int i = 0; i < FRAMES_NUMBER; i++) {
		int off = ((i*frame_size + psize - 1) / psize) * psize; //offset for each memory map into file descriptor
		frame_buffers[i] = (leptonpru_mmap *)mmap(NULL, frame_size, PROT_READ, MAP_SHARED, fileDesc, off);
		if (frame_buffers[i] == MAP_FAILED) {
			perror("memory mapping failed in lepton3 grabber via PRU\n");
			assert(0);
		}
		printf("%d: %x\n", i, frame_buffers[i]);
	}
	printf("Mapping done\n");
#endif // __linux__
}

PRUTest::~PRUTest()
{
#ifdef __linux__
	int frame_size = sizeof(leptonpru_mmap);

	for (int i = 0; i < FRAMES_NUMBER; i++) {
		printf("unmap buffer:%d\n", i);

		if (munmap(frame_buffers[i], frame_size)) {
			perror("munmap");
			assert(0);
		}
	}

	close(fileDesc);
#endif // __linux__
}

void PRUTest::update()
{
#ifdef __linux__
	printf("Read PRU from PRU Test class.\n");

	int err;
	unsigned int nextFrameIndex = 0;

	err = read(fileDesc, &nextFrameIndex, 1);
	printf("read: nextIndex=%d err=%d\n", nextFrameIndex, err);
	if (err < 0) {
		printf("err < 0: %u\n", err);
		return;
	}
	if (nextFrameIndex >= FRAMES_NUMBER) {

		printf("Next frame was: %d\n", nextFrameIndex);
		return;
	}

	printf("min: %d, max: %d - pixel0: %u\n",
		frame_buffers[nextFrameIndex]->min_val,
		frame_buffers[nextFrameIndex]->max_val,
		frame_buffers[nextFrameIndex]->image[0]);
	int driverReturnSignal = 1;
	err = write(fileDesc, &driverReturnSignal, 1);
	printf("write: err=%d cc=%d\n", err, driverReturnSignal);
#endif // __linux__
}

