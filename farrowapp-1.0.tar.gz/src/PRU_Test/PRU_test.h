#include <stdint.h>

#include "../leptonpru.h"

class PRUTest
{
public:
	PRUTest();
	~PRUTest();
	void update();

	volatile int fileDesc;
	leptonpru_mmap *frame_buffers[FRAMES_NUMBER];//Local target memory
};
