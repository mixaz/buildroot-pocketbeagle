#pragma once
#include <string>
#include <functional>
#include "json.hpp"
#include "Util.h"
#include "FarrowLog.h"
#include <sstream>

inline bool getDeviceIdFromHex(const std::string& inpuet, std::string& idStrOrErr)
{
	if (inpuet.length() < 6)
	{
		idStrOrErr = std::string("\"") + inpuet + "\" - Data not long enough to represet 3-byte device id.";
		return false;
	}
	std::string idString = inpuet.substr(0, 6);
	if (!Util::isHexString(idString))
	{
		idStrOrErr = std::string("\"") + inpuet + "\" -id-substring is not a hex value";
		return false;
	}
	idStrOrErr = idString;
	return true;
}


inline bool getCommandTypeHexFromHex(const std::string& inpuet, std::string& cmdTypeOrErr)
{
	if (inpuet.length() < 8)
	{
		cmdTypeOrErr = std::string("\"") + inpuet + "\" - Data not long enough to represent 3-byte device id and 1-byte command type.";
		return false;
	}
	std::string cmdString = inpuet.substr(6, 2);
	if (!Util::isHexString(cmdString))
	{
		cmdTypeOrErr = std::string("\"") + inpuet + "\" - command type-substring is not a hex value";
		return false;
	}
	cmdTypeOrErr = cmdString;
	return true;
}
class Response;

class Request
{
public:

	enum COMMAND_TYPE { UNKNOWN = 0x00, HEARTBEAT = 0x01, BIRTH = 0x02, PLACENTA_BIRTH = 0x03, ALARM_START = 0x04, ASSIST_STARTED = 0x05, ASSIST_ENDED = 0x06, FAULT_SITUATION = 0x07, RECORDING_STARTED = 0x08, RECORDING_ENDED = 0x09, GET_TIME = 0x10};
	
	typedef std::function<void(Response)> cb_t;

	Request(const std::string& dat, const Request::cb_t& cb = nullptr)
	{
		data = dat;
		callback = cb;
	}

	Request(const Request& r)
	{
		data = r.data;
		callback = r.callback;
	}


	void operator=(const Request& r)
	{
		data = r.data;
		callback = r.callback;
	}

	std::string to_string()
	{
		return data;
	}

	bool getDeviceId(std::string& idStrOrErr) const
	{
		return getDeviceIdFromHex(data, idStrOrErr);
	}

	bool getCommandTypeHex(std::string& cmdTypeOrErr) const
	{
		return getCommandTypeHexFromHex(data, cmdTypeOrErr);
	}

	Request::COMMAND_TYPE getCommandType() const
	{
		std::string typeHex;

		if (getCommandTypeHex(typeHex))
		{
			int ty = std::stoi("0x" + typeHex, NULL, 16);
			return (COMMAND_TYPE) ty;
		}
		return COMMAND_TYPE::UNKNOWN;
	}

	
	std::string data = "";
	cb_t callback;
	bool hasDeviceIdAndType = true;

};

class Response
{
public:
	Response() {};
	Response(const std::string& hexStr)
	{
		if (hexStr == "FF")
		{
			valid = false;
			AppLog::write("Got FF as response");
		}
		if (valid)
		{
			valid = Util::isHexString(hexStr);
			if (!valid)
				AppLog::writef("LORA Reponse has non hex content: '%s'", hexStr.c_str());
		}
		if (valid)
		{
			valid = getDeviceIdFromHex(hexStr, deviceId);
			if(!valid)
				AppLog::writef("LORA Reponse has device id error: '%s'", deviceId.c_str());
		}
		if (valid)
		{
			valid = getCommandTypeHexFromHex(hexStr, cmdType);
			if(!valid)
				AppLog::writef("LORA Reponse has command type error: '%s'", cmdType.c_str());
		}

		if (valid)
		{
			payload = hexStr.substr(8, hexStr.length() - 8);

			//Only set unix time if command type is 0x0a
			if (Util::getULongFromHex(cmdType) == Request::COMMAND_TYPE::GET_TIME)
			{
#ifndef ALLOW_INCOMPLETE_LORA_TIME
				valid = payload.length() == 8;
#endif
				if (!valid)
				{
					AppLog::writef("LORA GET TIME Response did not have an 8 character payload as expected. Payload: '%s', msg: '%s'", payload.c_str(), hexStr.c_str());
				}
				else
					unixTime = Util::getULongFromHex(payload.length() == 0 ? "1C8EF74" : payload); // standard value is 1970 12/13 14:15:16
			}
			if (Util::getULongFromHex(cmdType) == Request::COMMAND_TYPE::HEARTBEAT)
			{
#ifndef ALLOW_INCOMPLETE_LORA_TIME
				valid = payload.length() == 4;
#endif
				if (!valid)
				{
					AppLog::writef("LORA Heartbeat Response did not have a 4 character payload as expected. Payload: '%s', msg: '%s'", payload.c_str(), hexStr.c_str());
				}
				else
				{
					std::string hexPrefixedPayload = "0x" + payload;
					if (payload.length() == 0)
					{
						hexPrefixedPayload += "0";
					}
					try
					{
						std::stringstream ss(hexPrefixedPayload);
						ss >> std::hex >> signalStrength;
						signalStrength -= 0xFFFF;
					}
					catch (...)
					{
						AppLog::writef("LORA Heartbeat payload could not be parsed to int. Payload: '%s', msg: '%s'", payload.c_str(), hexStr.c_str());
						valid = false;
					}
				}
			}
		}
		
	}

	std::string getDeviceId() { return deviceId; }
	std::string getCommandType() { return cmdType; }
	unsigned long getUnixTime() { return valid ? unixTime : 0; }
	std::string getPayload() { return payload; }
	int getSignalStrength() { return signalStrength; }
	bool isValid() { return valid; }

private:
	std::string payload;
	std::string deviceId;
	std::string cmdType;
	unsigned long unixTime = 100000;
	int signalStrength;
	bool valid = true;
};

/*
#else
class Request
{
public:

	Request(const nlohmann::json& dat = nullptr, const Request::cb_t& cb = nullptr)
	{
		data = dat;
		callback = cb;
	}

	Request(const Request& r)
	{
		data = r.data;
		callback = r.callback;
	}

	Request(Request&& other) : data(other.data), callback(other.callback)
	{
		other.data = nullptr;
		other.callback = nullptr;
	}

	void operator=(const Request& r)
	{
		data = r.data;
		callback = r.callback;
	}

	std::string to_string()
	{
		return data.dump();
	}

	nlohmann::json data;
	cb_t callback;
};
#endif
*/