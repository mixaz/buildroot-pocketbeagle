#pragma once
#include <vector>
#include "FarrowImageGrabber.h"
#include <map>
#include <set>
#include "StateCycle.h"

enum ToggleType {
	TOGGLE_ON,
	TOGGLE_OFF,
	TOGGLE_TOGGLE,
};
enum UIOutputType {
	LED_CODE_START,
	LASER,
	THREE_DIGIT_DISPLAY,
	TWO_DIGIT_DISPLAY,
	LED_CODE_BATT_STAT_G,
	LED_CODE_BATT_STAT_R,
	LED_CODE__STATUS_R,
	LED_CODE__STATUS_G,
	LED_CODE_ALARM
};

enum UIOutputExpression {
	SIGNAL_WAIT_CAMERA,
	SIGNAL_STATE_STANDBY,
	SIGNAL_STATE_RUNNING,
	SIGNAL_STATE_SETUP_WITH_LASER,
	SIGNAL_STATE_UPDATE_PIGLET_COUNT,
	SIGNAL_STATE_STATE_FAULT,
	SIGNAL_STATE_SOFT_POWER_DOWN,
	SIGNAL_SOME_STATE_ENDED,
	SIGNAL_IMAGE_GRABBED,
	SIGNAL_ARLARMED,
	SIGNAL_NOT_ALARMED,
	SIGNAL_LORA_TEST,
	SIGNAL_SAVING_IMAGES,
	SIGNAL_STATE_NONE,
};
class FarrowUI
{
public:
	virtual ~FarrowUI() {};
	virtual void updateGrabberImages(ImageAndMetaData& newImg){};
	virtual bool update() = 0;

	virtual std::string getName() = 0;
	
	virtual int getNumberPressed() { return -1; }
	virtual bool getPressedBack() { return false; }

	virtual bool getPressedOK() { return false; }
	virtual bool getPressedStart() { return false; }
	virtual bool getPressedAssist() { return false; }
	virtual bool getPressedLoraTest() { return false; }
	virtual bool getPressedLaser() { return false; }
	virtual bool getPressedTime() { return false; }

	virtual bool getPressedSleep() { return false; }
	virtual bool getPressedSoftPowerDown() { return false; }
	virtual bool getIsInCharger() { return false; }
	virtual bool anyBtnPressed();
	virtual void resetBtnStates() {};
	virtual void setSecsSinceBirth(int secs) { minsSinceBirth = secs; };
	void clearLEDCycleStates();
	virtual void toggleLaser(ToggleType togTyp = ToggleType::TOGGLE_TOGGLE) {};
	virtual void setHardwarePowerDown() {};
	
	virtual bool isJMP_LOPOW() { return false; };
	virtual unsigned char getBatteryLevelPercent() { return 46; };
	virtual double getBatteryVoltage() { return 4; }
	virtual void setDisplayOnOff(bool on) {};

	void addLEDCycle(StateCycle cycle, UIOutputType key);

	
	//void updateOutput();


	virtual void setDisplayLine(std::string txt, int line) {};
	virtual void drawTextCentered(std::string txt) {};
	virtual void drawBattery(int percent) {};
	virtual void clearBattery() {};

	virtual void clearDisplay(bool forceNow) {};
	virtual void setLEDValue(UIOutputType, float value) {};

	//bool isAnalysisPaused = false;
	//bool analysisPausedChanged = false;
	
	//bool allowedToprogress = false;

	void deployWaitMsg(void* keyObj, std::string msg);
	void revokeWaitMsg(void* keyObj);
	bool getWaitMessage(std::string& line1, std::string& line2);
	bool hasWaitMessages() { return waitMessages.size() > 0; }

protected:
	std::string adaptStringToDigits(std::string orig, int digits);
	bool drawWaitMessages();
	//int currentPigletCount = -1;
	int minsSinceBirth = -1;
	//int currentLiveCount = 0;
	//int currentDeadCount = 0;
	//std::string sowNr = "";
	//std::string penNr = "";
	void printWaitMessages();
private:
	std::map<UIOutputType, StateCycle> activeLEDCycles;
	std::map<int, float> lastOutputValue;
	std::map<void*, std::string> waitMessages;
	int msgCounts = 0;
};