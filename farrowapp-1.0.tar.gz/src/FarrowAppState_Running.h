#pragma once
#include "FarrowAppState.h"

class FarrowApp;


////////////////////////////////////////////////
////////	R U N N I N G    ///////////////////
////////////////////////////////////////////////

class FarrowAppState_Running : public FarrowAppState
{
public:
	FarrowAppState_Running(FarrowApp& fA, bool newLitter) : FarrowAppState(fA), isNewLitter(newLitter) {}

	virtual ~FarrowAppState_Running() {};

	virtual bool update() override;

	virtual std::string name() override { return "Running"; };

	virtual void setup() override;

	virtual void tearDown() override;
	virtual void registerCamHardReset() override;


	virtual bool hasTimeMode() override { return true; }

	StackedTiffStorer *storer = nullptr;
	DoubleBuffer<ImageAndMetaData *> imagesAndMeta;
	int countInImageStack;
	bool stateRecordsImages;
	FarrowTimer timer;
	unsigned long long lastImageGrabMillis = 0;
	//FarrowLog *runningModeLog = nullptr;

	virtual void rePaint() override;

private:
	bool isNewLitter;
	int repaintBasedOnMinutesSinceBirth = -1;
	int repaintBasedOnPigletCount = -1;
	bool repaintBasedOnAlarmState = false;

	bool repaintBasedOnCamReady = true;

	int repaintBasedOnCampProgress = false;
	int framesPrStack;
	unsigned long imgCount = 0;

	const int skipFirstImgsCount = 10;

	AnalysisResult lastResult = NORMAL_RESULT;

	int getMinutesSinceBirth();
	void outputReport();

	bool lastLedFlashState = false;

	bool signalledDoneGrabbingAnalysing = false;
	//int startCount = 0;
};

