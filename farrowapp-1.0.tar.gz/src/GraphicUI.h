#pragma once
#include "FarrowUI.h"
#include <string>
#include <map>
#include "GraphicUILED.h"

class FarrowApp;

class GraphicUI :
	public FarrowUI
{
public:
	GraphicUI(FarrowApp& app, bool doNormalise);
	virtual ~GraphicUI(void);

	virtual void updateGrabberImages(ImageAndMetaData& newImg);

	virtual void toggleLaser(ToggleType togTyp = ToggleType::TOGGLE_TOGGLE) override;


	virtual void setDisplayLine(std::string txt, int line) override;


	virtual int getNumberPressed() override {
		//Ascii "0" is 48
		if (lastKeyPress < 48 || lastKeyPress > 57)
			return -1;

		return lastKeyPress - 48;
	}


	virtual bool getPressedBack() override {return lastKeyPress == 8; };


	virtual bool getPressedOK() override { return lastKeyPress == 13; };

	virtual bool getPressedLaser() override { return lastKeyPress == 'l'; };

	virtual bool getPressedTime() override { return lastKeyPress == 't'; }
	virtual void drawTextCentered(std::string txt) override;


	virtual void drawBattery(int percent) override;


	virtual void clearBattery() override;


	virtual void clearDisplay(bool forceNow) override;


	virtual void setDisplayOnOff(bool on) override;


	virtual bool getPressedSleep() override { return lastKeyPress == 'z'; };


	virtual bool getIsInCharger() override { return lastKeyPress == 'c'; }

private:
	FarrowApp& app;
	bool laserOn = false;
	cv::Mat imageNormalised;
	cv::Mat uiPanelMat;
	cv::Mat ledArea;
	cv::Rect batteryInternalRect;
	cv::Mat batteryInternalArea;
	cv::Mat batteryWithBorderArea;

	std::vector<cv::Mat> displayLineROIs;
	cv::Mat displayCentreLine;
	//GraphicUILED greenLed;
	//GraphicUILED redLed;
	//GraphicUILED blueLed;
	
	unsigned char displayContrast = 128;

	bool lowPowerJmpOn = false;

	void initUIPanel();
	virtual bool getPressedStart() override { return lastKeyPress=='s'; };

	virtual bool getPressedAssist() override { return lastKeyPress == 'f'; };

	virtual bool getPressedSoftPowerDown() override { return lastKeyPress == 'p'; };

	virtual bool isJMP_LOPOW() override { return lowPowerJmpOn; };

	virtual bool update() override;


	bool normaliseOutput;

	virtual std::string getName() override { return "Graphic"; }

	virtual void resetBtnStates() override { lastKeyPress = -1; };

	virtual void setHardwarePowerDown() override;

	//virtual void setDoubleDigitDisplpay(std::string) override;

	//virtual void setTrippleDigitDisplpay(std::string) override;


	void setLEDValue(UIOutputType ledKey, float value) override;
	std::map<int, std::string> outputTypeToNamesMap;
	//std::map<int, GraphicUILED> outputTypeToUILEDMap;
	bool ledRGIsGreen = false;
	bool ledRGIsRed = false;

	GraphicUILED ledRG;
	GraphicUILED ledLaser;
	GraphicUILED ledAlarm;
	int lastKeyPress = -1;

};

