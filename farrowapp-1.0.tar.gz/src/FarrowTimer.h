#pragma once
#include <time.h>
#include <chrono>
#include <string>

/*
struct FarrowTimeStamp
{
	long days;
	long hours;
	long minutes;
	long seconds;
	long mSeconds;
	long rawTime;
};
*/

class FarrowTimer
{
public:
	FarrowTimer(void);
	~FarrowTimer(void);
	void reset();
	unsigned long long getStopwatchRawTimeMS();

	unsigned long long getStopwatchRawTimeUSec();
	//FarrowTimeStamp getTimeStamp(bool truncateValues = true);
	static std::string convertMSToString(long long ellapsedMillis, bool truncateValues, bool includeMillis);

private:
	 std::chrono::time_point<std::chrono::steady_clock> startTime;
	 std::chrono::milliseconds startMs;
	 std::chrono::microseconds startUSec;
};

