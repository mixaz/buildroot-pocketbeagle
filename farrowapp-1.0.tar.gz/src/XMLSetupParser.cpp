#include "XMLSetupParser.h"

#include "StackedTiffGrabber.h"
#include "FarrowLog.h"
#include "HeadlessUI.h"
#include "FarrowApp.h"

#ifdef BEAGLE_BONE
#include "Lepton3Grabber.h"
#include "BeagleUI.h"
#elif WIN32
#include "GraphicUI.h"
#endif

using namespace std;

XMLSetupParser::XMLSetupParser(void)
{
}


XMLSetupParser::~XMLSetupParser(void)
{
}

std::unique_ptr<tinyxml2::XMLDocument> XMLSetupParser::loadXMLfromFile(std::string path, int retries)
{
	std::unique_ptr<tinyxml2::XMLDocument> doc( new tinyxml2::XMLDocument());
	tinyxml2::XMLError err;

	for (int i = 0; i <= retries; i++)
	{
		if ((err = doc->LoadFile(path.c_str())) == tinyxml2::XMLError::XML_SUCCESS)
			return doc;
		else
			AppLog::write("Failed to load XML file from " + path);
	}
	
	return doc;
}



char *grabberTag = "grabber";
char *grabberTypeTag = "grabberType";
char *widthTag = "width";
char *activeTag = "active";
char *forceGrayTag = "forceGray";
char *grabberNumberTag = "grabberNumber";
char *folderTag = "folder";
char *loopTag = "loop";
char *minIntervalTag = "minIntervalMS";
char *debug_force16Bit = "debug_force16Bit";
char *debug_forceNormalise = "debug_forceNormalise";
char *softResetMS = "softResetMS";
char *hardResetMS = "hardResetMS";
char *hardResetNoImgMS = "hardResetNoImgMS";
//char *leptonShutter = "leptonShutter";
char *leptonNoiseFilters = "leptonNoiseFilters";

char *uiTag = "ui";
char *uiTypeTag = "uiType";
char *uiNormaliseTag = "normaliseImageOutput";

//char *webcomTag = "webcom";
//char *webcomUsernameTag = "username";
//char *webcomPasswordTag = "password";
//char *webcomContextIdTag = "contextId";

char *globalsTag = "globals";
char *saveImagesTag = "saveImages";
char *analyseImagesTag = "analyseImages";
//char *outputAnalysisDetailsTag = "outputNetworkDetails";
//char *replaceTrackingLogTag = "replaceTrackingLog";
char *useGlobalAppLogTag = "useGlobalAppLog";
char *lowBatShutdownTag = "lowBatShutdown";
char *frameRateTag = "frameRate";
char *minsPrDumpTag = "minutesPrDump";
//char *useSecondsTag = "useSecondsInTifName";
char *tiffReadFolderTag = "tiffReadFolder";
char *alarmIntervalsTag = "alarmIntervals";
char* minDiskSpaceTag = "minDiskSpaceMB";
char* useLoraTag = "useLora";
char* requireGatewayTimeTag = "requireGatewayTime";

FarrowImageGrabber * XMLSetupParser::parseToGrabber(tinyxml2::XMLElement *grabberElement, FarrowApp& app)
{
	int width = grabberElement->IntAttribute(widthTag);

	int grabberNumber = grabberElement->IntAttribute(grabberNumberTag);

	bool forceGrayScale = grabberElement->BoolAttribute(forceGrayTag);

	std::string grabberType = grabberElement->Attribute(grabberTypeTag);

	bool force16Bit = grabberElement->BoolAttribute(debug_force16Bit);

	bool forceNormalise = grabberElement->BoolAttribute(debug_forceNormalise);


	if (grabberType == "tiff")
	{
		const char *folderPath = grabberElement->Attribute(folderTag);
		AppLog::write("Trying to create Tiff Grabber with folder Path: " + string(folderPath));
		string usedPath = folderPath;

		//If app has a subFolderOverride - append it to tiff folder path
		if (app.getSubFolderOverride() != "")
		{
			usedPath = app.getSubFolderOverride();
		}

		AppLog::write("Trying to create Tiff Grabber with folder Path: " + string(usedPath));

		bool loop = grabberElement->BoolAttribute(loopTag);

		int minInterval = grabberElement->IntAttribute(minIntervalTag);

		if (usedPath != "")
		{
			StackedTiffGrabber *g =new StackedTiffGrabber(usedPath, loop, minInterval, app);
			
			return g;
		}
	}
	
#ifdef BEAGLE_BONE
	else if (grabberType == "lepton3")
	{
		printf("Start getting attributes for lepton3 grabber after %llu msecs\n", app.appTimer.getStopwatchRawTimeMS());

		int softResetDur = grabberElement->IntAttribute(softResetMS);

		if (softResetDur == 0)
			softResetDur = 1500;

		int hardResetDur = grabberElement->IntAttribute(hardResetMS);
		if (hardResetDur == 0)
			hardResetDur = 5000;

		int hardResetDurNoImg = grabberElement->IntAttribute(hardResetNoImgMS);
		if (hardResetDurNoImg == 0)
			hardResetDurNoImg = 10000;

		bool useNoiseFilter = grabberElement->BoolAttribute(leptonNoiseFilters);

		printf("Done Setting attributes for lepton3 grabber after %llu msecs\n", app.appTimer.getStopwatchRawTimeMS());

		return new Lepton3Grabber(app, softResetDur, hardResetDur, hardResetDurNoImg, useNoiseFilter);
	}
#endif

	return nullptr;
}

std::vector<FarrowImageGrabber *> XMLSetupParser::parseToGrabbers(tinyxml2::XMLElement *rootNode, FarrowApp& app)
{
	std::vector<FarrowImageGrabber *> grabbers;
	std::vector<tinyxml2::XMLElement *> grabberElements = getElementsWidthActiveBoolAttribute(rootNode, grabberTag);

	for(tinyxml2::XMLElement *e : grabberElements)
	{
		AppLog::write("Trying to create grabber");
		FarrowImageGrabber * resultingGrabber = parseToGrabber(e, app);

		if(resultingGrabber != nullptr)
			grabbers.push_back(resultingGrabber);
	}
	return grabbers;
}


void XMLSetupParser::parseToConstants(tinyxml2::XMLElement *rootNode, ConstantsFromXML& constantsStruct)
{
	std::vector<tinyxml2::XMLElement *> globalElements = getElementsWidthActiveBoolAttribute(rootNode, globalsTag);

	for(tinyxml2::XMLElement *e : globalElements)
	{
		int frameRateRead = max(e->IntAttribute(frameRateTag), 1);
		int minutesPrDumpRead = max(e->IntAttribute(minsPrDumpTag), 1);
		
		constantsStruct.lowBatShutdown = e->BoolAttribute(lowBatShutdownTag);
		constantsStruct.useGlobalAppLog = e->BoolAttribute(useGlobalAppLogTag);
		constantsStruct.saveImages = e->BoolAttribute(saveImagesTag);
		constantsStruct.analyseImages = e->BoolAttribute(analyseImagesTag);
		const char *aIP = e->Attribute(tiffReadFolderTag);
		constantsStruct.minDiskSpace = e->IntAttribute(minDiskSpaceTag);
		constantsStruct.useLoraCom = e->BoolAttribute(useLoraTag);
		constantsStruct.requireGatewayTime = e->BoolAttribute(requireGatewayTimeTag);
		const char *alarmIntsConst = e->Attribute(alarmIntervalsTag);
		
		if (alarmIntsConst != NULL)
		{
			char alarmIntervals[100];

			strcpy(alarmIntervals, alarmIntsConst);

			char *alarmInterval = strtok(alarmIntervals, ",");
			while (true)
			{
				if (alarmInterval == NULL)
					break;

				constantsStruct.alarmIntervals.push_back(std::stoi(alarmInterval));
				
				alarmInterval = strtok(NULL, ",");
			}
		}
		
		if(frameRateRead != 0)
			constantsStruct.grabFrameRate = frameRateRead;

		if(minutesPrDumpRead != 0)
			constantsStruct.stackDurationMinutes = minutesPrDumpRead;
	}
}

FarrowUI * XMLSetupParser::parseToUI(tinyxml2::XMLElement *uiElement, FarrowApp& app)
{
	std::string uiType = uiElement->Attribute(uiTypeTag);

	bool normalise = uiElement->IntAttribute(uiNormaliseTag) == 1;

	if (uiType == "headless")
		return new HeadlessUI(app);
#ifdef BEAGLE_BONE
	else if (uiType == "beagle")
		return new BeagleUI(app);
#elif WIN32
	else if (uiType == "graphic")
		return new GraphicUI(app, true);
#endif

	else
		return nullptr;
}

std::vector<FarrowUI *> XMLSetupParser::parseToUIs(tinyxml2::XMLElement *rootNode, FarrowApp& app)
{
	std::vector<FarrowUI *> uis;
	std::vector<tinyxml2::XMLElement *> uiElements = getElementsWidthActiveBoolAttribute(rootNode, uiTag);

	printf("Found %i active uis\n", uiElements.size());

	for(tinyxml2::XMLElement *e : uiElements)
	{
		FarrowUI * resultingUI = parseToUI(e, app);

		printf("UI was null: %s\n", resultingUI == nullptr ? "YES" : "NO");
		if(resultingUI != nullptr)
			uis.push_back(resultingUI);
	}
	return uis;
}


//Generic XML function to get xml elements with a certain name, that also has a bool attribut "active" not being 0
std::vector<tinyxml2::XMLElement *> XMLSetupParser::getElementsWidthActiveBoolAttribute(tinyxml2::XMLElement *rootNode, char *elementTag)
{
	std::vector<tinyxml2::XMLElement *> elems;

	tinyxml2::XMLElement *elemCandidate = rootNode->FirstChildElement(elementTag);

	while (elemCandidate != nullptr)
	{
		//printf("Evaluating element of type: %s\n", elementTag);
		if (elemCandidate->IntAttribute(activeTag) == 1)
		{
			//printf("Is active and is added to the program\n");
			elems.push_back(elemCandidate);
		}

		elemCandidate = elemCandidate->NextSiblingElement(elementTag);
	}
	return elems;
}

std::unique_ptr<std::queue<Request>> XMLToLoraRequests(tinyxml2::XMLElement* rootElem)
{
	std::unique_ptr<std::queue<Request>> temp(new std::queue<Request>());
	tinyxml2::XMLElement* loraElem;

	if ((loraElem = rootElem->FirstChildElement("lorarequests")) != nullptr)
	{
		tinyxml2::XMLElement* requestElem = loraElem->FirstChildElement();
		while (requestElem != nullptr)
		{
			Request r = Request(requestElem->Attribute("data"));
			temp->push(r);
			requestElem = requestElem->NextSiblingElement();
		}
	}

	return temp;
}

std::unique_ptr<tinyxml2::XMLDocument> XMLSetupParser::LoraRequestsToXML(std::queue<Request> reqs)
{

	std::unique_ptr<tinyxml2::XMLDocument> doc(new tinyxml2::XMLDocument());
	tinyxml2::XMLNode* root = doc->NewElement("root");
	doc->InsertFirstChild(root);

	tinyxml2::XMLElement * loraElem = doc->NewElement("lorarequests");
	root->InsertEndChild(loraElem);

	while (!reqs.empty())
	{
		tinyxml2::XMLElement* elem = doc->NewElement("Request");
		elem->SetAttribute("data", reqs.front().data.c_str());

		loraElem->InsertEndChild(elem);

		reqs.pop();
	}

	return doc;
}




