#include "DockerTfUtils.h"
#include "Util.h"
#include "CrossPlatform.hpp"
#include "FarrowLog.h"


using namespace std;

recursive_mutex dockerInteractionMutex;

std::atomic_int DockerTfUtils::containerState_cached(-1);

void DockerTfUtils::notifyConditionVariables()
{
	startedConfirmCondVar.notify_all();
}


const string stateNames[]{ "Running", "Stopped", "Non-existent", "Cmd error" };


volatile bool hasMadeRealContainerRunningCheck = false;

// Check whether container runs(0), is stopped(1), is non-existent (2) or cmd errors (3)
int DockerTfUtils::getDockerContainerState(bool allowUseCached)
{
	int returnState = -1;
	if (allowUseCached && hasMadeRealContainerRunningCheck)
	{
		int returnState_cached = containerState_cached.load();
		return returnState_cached;
	}
	lock_guard<std::recursive_mutex> lock(dockerInteractionMutex);
	
#ifdef WIN32
	string inspectCMD = "docker inspect tf_FarrowApp";
#elif BEAGLE_BONE
    string inspectCMD = "/usr/bin/docker container inspect tf_FarrowApp";
#else
	string inspectCMD = "docker container inspect tf_FarrowApp";
#endif
	string cmdOutput;
	if (Util::executeCmdCrossPlatform(inspectCMD, cmdOutput))
	{
		bool expectedResponse = cmdOutput[0] == '[';
		if (!expectedResponse)
		{
			returnState = 3;
		}
		else
		{
			bool containerExists = cmdOutput.substr(0, 2).compare("[]") != 0;
			returnState = containerExists ? 1 : 2;
			if (containerExists && cmdOutput.find("\"Running\": true") != string::npos)
			{
				returnState = 0;
			}
		}
	}
	else
	{
		AppLog::write("failed inspecting docker container");
		returnState = 3;
	}

	AppLog::write(string("Container has state after hard check: ") + (returnState < 0 ? "unset" : stateNames[returnState]));

	hasMadeRealContainerRunningCheck = true;
	//If container is not running - check whether service is running at all
	if (!returnState < 0 || returnState > 2)
	{
		bool serviceRunning = isDockerServiceRunning();
		
		if (!serviceRunning)
		{
			// TODO: Do something to restart service (not container) 
		}
	}
	containerState_cached.store(returnState);
	return returnState;
}

bool DockerTfUtils::isDockerServiceRunning()
{
	lock_guard<std::recursive_mutex> lock(dockerInteractionMutex);

	AppLog::write("\nChecking Docker service running\n");
#ifdef WIN32
	// NOTE: On windows, just assume that the service is running
	return true;
#elif BEAGLE_BONE
	//The following part is a check on linux for whether docker (not the container) is running
	// The OS creates this file when the docker service is started
	std::ifstream ifs("/run/docker.pid");

	if (ifs.good())
	{
		ifs.close();
		return true;
	}

	ifs.close();
	return false;
#else
    // NOTE: On desktop linux, just assume that the service is running
	return true;
#endif // WIN32
}

std::condition_variable DockerTfUtils::startedConfirmCondVar;

std::mutex DockerTfUtils::startedConfirmCondMutex;

void DockerTfUtils::startOrRestartTensorflowContainer()
{
	lock_guard<std::recursive_mutex> lock(dockerInteractionMutex);
	containerState_cached.store(-1);
	AppLog::write("Starting or restarting tensorflow container");
	
	int returned = getDockerContainerState(false);

	if (returned == 0 || returned == 1) // Container already exists (possibly runs), try restarting it
	{
		AppLog::write("Restarting already running TF container");
		restartTensorFlowContainer();
	}
	
	else if (returned == 2) // Container doesn't exist, create and run it
	{
		string modelPath = CrossPlatform::getExecDir() + "ExecutableSupport" + CrossPlatform::getFolderDelimiter() + "servegraph";
		//printf("exectuable dir: %s\nModel path: %s\n", CrossPlatform::getExecDir().c_str(), modelPath.c_str());
		AppLog::write("Starting new container beacause process tf_FarrowApp does not run");
#ifdef WIN32
		string startCMD = "docker run --name=tf_FarrowApp -p 8501:8501 -d --rm --mount type=bind,source=\"" + modelPath + "\",target=/models/saved_model -e MODEL_NAME=saved_model -t tensorflow/serving";
#elif BEAGLE_BONE
		string startCMD = "/usr/bin/docker run -p 8501:8501 -d --rm --mount type=bind,source=\"" + modelPath + "\",target=/models/saved_model -e MODEL_NAME=saved_model -t --name tf_FarrowApp emacski/tensorflow-serving:latest-arm32v7_vfpv3";
#else
		string startCMD = "docker run -p 8501:8501 -d --rm --mount type=bind,source=\"" + modelPath + "\",target=/models/saved_model -e MODEL_NAME=saved_model -t --name tf_FarrowApp tensorflow/serving";
#endif
	
		bool ret = Util::executeCmdCrossPlatform(startCMD);

		if (!ret)
		{
			// TODO: After switching to crossplatform, we will not get the any error message here.
			// errno 125 "operation cancelled" likely means another instance of the docker image is already running on the port under another name
			throw "Failed cmd to run fresh docker container | " + Util::strerror_r_cpp(returned);
		}

	}
	else
	{
		throw "Failed to start docker container | " + Util::strerror_r_cpp(returned);
	}

	FarrowTimer startTimer;
	

	AppLog::write("Docker attempted started/restarted - waiting for started comfirmation");
	std::unique_lock<std::mutex> confirmLock(startedConfirmCondMutex);
	bool startRestartSuccess = !startedConfirmCondVar.wait_for(confirmLock, std::chrono::seconds(30), [=] {return getDockerContainerState(false) == containerStateSuccessCode; });

	AppLog::writef("Start/restart of docker container success: %i - took %llu mSecs.\n", startRestartSuccess ? 1 : 0, startTimer.getStopwatchRawTimeMS());
}

void DockerTfUtils::restartTensorFlowContainer()
{
	lock_guard<std::recursive_mutex> lock(dockerInteractionMutex);
	containerState_cached.store(-1);

	bool returned = Util::executeCmdCrossPlatform("docker restart tf_FarrowApp");

	if (!returned)
	{
		throw "Failed to restart docker container | " + Util::strerror_r_cpp(returned);
	}
}

