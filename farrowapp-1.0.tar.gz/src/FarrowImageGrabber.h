#pragma once
//OpenCV stuff
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "CrossPlatform.hpp"
#include <mutex>
#include "DoubleBuffer.hpp"
#include "FarrowImageMetaData.h"
#include "FarrowTimer.h"
#include <thread>
#include <condition_variable>

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Super class with double buffering that represents an image grabber complying to the FarrowTeh specific requirements ///////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

class FarrowApp;

class FarrowImageGrabber
{
public:
	FarrowImageGrabber(FarrowApp& app);
	virtual ~FarrowImageGrabber(void);

	void startGrabbing();

	virtual std::string getName() = 0;
	virtual bool getLastGrabbed(ImageAndMetaData& lastImg);
	virtual bool allowSaving() { return true; }
	virtual std::vector<float> getFrameTimeEvents() { return abnormalGrabIntervals; };
	//virtual std::vector<float> getSPITimeEvents() { return std::vector<float>(); };
	virtual void resetTimers() {};
	void finishGrabThreadBeforeDestruction();
	FarrowTimer& getTimer() { return timer; }

	virtual std::string getGrabbedFileId() { return "No File"; }
	virtual bool grabbingEnded() { return false; }
	uint32_t getGrabbedCount() { return grabbedCount; }

	virtual bool useAnalysisQueue() { return true; }
	virtual std::string getSpecialRunningLogPath() { return ""; }
	bool isReady() { return isSetup.load(); }
	bool isDuringCloseDown() { return duringCloseDown.load(); }
	void closeDown();
	void resetImageNumber() { imageNr = 1; }
protected:
	std::vector<float> abnormalGrabIntervals;

	virtual bool grabberLoopUpdate() { return true; } //Must return false if grabber loop should stop
	uint32_t grabbedCount = 0;
	//std::mutex grabLoopRunningBoolMutex;
	volatile bool grabLoopRunning = false;

	void assignMatToDoubleBuffer(ImageAndMetaData& m);

	virtual void setMetaDataNow(FarrowImageMetaData& fM);

	//Double buffer - writing to back - reading from front
	DoubleBuffer<ImageAndMetaData> matDoubleBuffer;
	std::mutex doubleBufferMutex;

	virtual void internalGrabberLoop();

	virtual void setupCameraFNC(std::function<void()> progressCB) {};
	virtual void stopCameraFNC(std::function<void()> progressCB) {};

	unsigned long currentImageCount;

	FarrowApp& app;
	FarrowTimer timer;
private:

	void setupCamera();
	std::thread cameraSetupThread;
	std::mutex cameraSetupMutex;
	std::condition_variable cv_cameraSetup;
	std::atomic_bool isSetup{ false };
	std::atomic_bool duringCloseDown{ false };

	std::thread grabberThread;

	static int imageNr;


};

