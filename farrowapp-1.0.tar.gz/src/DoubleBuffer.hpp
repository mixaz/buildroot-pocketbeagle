#pragma once
template<class T>
class DoubleBuffer
{
public:
	DoubleBuffer(void)
	{
		oneIsFront = false;
	}
	~DoubleBuffer(void)
	{

	}

	void swap()
	{
		oneIsFront = !oneIsFront;
	}

	T& getFrontRef()
	{
		return oneIsFront ? bufferObject1 : bufferObject2;
	}

	T& getBackRef()
	{
		return oneIsFront ? bufferObject2 : bufferObject1;
	}

	void assignFrontRef(T& m)
	{
		getFrontRef() = m;
	}

	void assignBackRef(T& m)
	{
		getBackRef() = m;
	}

	T getFront()
	{
		return oneIsFront ? bufferObject1 : bufferObject2;
	}

	T getBack()
	{
		return oneIsFront ? bufferObject2 : bufferObject1;
	}

	void assignFront(T m)
	{
		getFrontRef() = m;
	}

	void assignBack(T m)
	{
		getBackRef() = m;
	}
private:
	T bufferObject1;
	T bufferObject2;
	bool oneIsFront;
};

