#include "BeagleKeypad.h"
#include "device_drivers/TCA9555_cpp.hpp"
#include <mutex>


BeagleKeypad::BeagleKeypad(TCA9555& tca9555) : tca(tca9555)
{
}


BeagleKeypad::~BeagleKeypad()
{
}

void BeagleKeypad::init()
{
	tca.init();

	unsigned char conf1 = tca.readReg(TCA9555_CONFIG1);

	// Keep unused bits, set the rest
	conf1 |= inputMask1;
	tca.writeReg(TCA9555_CONFIG1, conf1);

	// No need to read config0 first since we use the whole register
	tca.writeReg(TCA9555_CONFIG0, inputMask0);

	unsigned char pol1 = tca.readReg(TCA9555_POL_INV1);

	// Keep unused bits, set the rest
	pol1 |= inputMask1;
	tca.writeReg(TCA9555_POL_INV1, pol1);
	tca.writeReg(TCA9555_POL_INV0, inputMask0);
}

void BeagleKeypad::update()
{	
	// Read and set bits not used by keypad to 0
	currentReadValue = tca.readInputs() & ((inputMask1 << 8) | inputMask0);

	// Use "is power of 2" algorithm to check if only one bit is set meaning only 1 button is down
	if (!(currentReadValue && !(currentReadValue & (currentReadValue - 1))) && currentReadValue != 0x00)
	{
		return;
	}

	std::unique_lock<std::mutex> guard(keypadMtx);

#ifdef WIN32
	int newButton = -1;
#else
	// Use a gcc builtin to do fastest possible "find first set" (-1 for 0-based index)
	int newButton = __builtin_ffs(currentReadValue) - 1;
#endif
	if (!btnDownLastFrame)
	{
		buttonQuarantined = false;
	}
	
	// Don't bother figuring out status if nothing has been pressed for a few frames
	if (newButton == -1 && !btnDownLastFrame)
	{
		btnDownLastFrame = false;
		btnDownThisFrame = false;
		btnStatus = UP;
		currentButton = newButton;
		return; 
	}

	btnDownThisFrame = (/*newButton == currentButton && */newButton != -1);

	//printf("new button: %i downThis: %i, downLast: %i, quaranteened: %i\n", newButton, btnDownThisFrame, btnDownLastFrame, buttonQuarantined);

	if (btnDownThisFrame && !btnDownLastFrame)
	{
		btnDownTimer.reset();
	}

	// Set button status
	if (!buttonQuarantined && !btnDownThisFrame && btnDownLastFrame && btnDownTimer.getStopwatchRawTimeMS() > 80)
	{
		btnStatus = SHORT_PRESS;
	}
	else if (!buttonQuarantined && btnDownThisFrame && btnDownTimer.getStopwatchRawTimeMS() > 2500)
	{
		buttonQuarantined = true;
		btnStatus = LONG_PRESS;
	}
	else if (!buttonQuarantined && (btnDownThisFrame || btnDownLastFrame))
	{
		btnStatus = DOWN;
	}  
	else if (buttonQuarantined)
	{
		btnStatus = QUARANTINED;
	}
	else
	{
		btnStatus = UP;
	}

	currentButton = (btnStatus == SHORT_PRESS || btnStatus == LONG_PRESS) ? currentButton : newButton;

	btnDownLastFrame = btnDownThisFrame;
	return;
}

int BeagleKeypad::getCurrentButton()
{
	std::unique_lock<std::mutex> guard(keypadMtx);
	return currentButton;
}

BeagleKeypad::ButtonStatus BeagleKeypad::getCurrentButtonStatus()
{
	std::unique_lock<std::mutex> guard(keypadMtx);
	return btnStatus;
}

