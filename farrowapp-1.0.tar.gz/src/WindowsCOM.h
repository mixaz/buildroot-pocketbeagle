
#include <windows.h>


/*
	extern int init_UART();
	extern void close_UART();

	extern int write_UART(const char* write_data, int byte_count);
	extern int read_UART(char* read_data, int byte_count);

*/

class WindowsCOM
{
public:
	WindowsCOM();
	int init();
	void close();
	int write(const char* write_data, int byte_count);
	int read(char* read_data, int byte_count);

private:
	HANDLE hSerial;
	bool opened = false;
};