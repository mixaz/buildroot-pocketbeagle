#include "WindowsCOM.h"
#include <iostream>
#include "windows.h"
#include <string>
#include "CrossPlatform.hpp"

using namespace std;

const LPCWSTR comFile = L"\\\\.\\COM13";

WindowsCOM::WindowsCOM()
{

}

int WindowsCOM::init()
{
	opened = false;
	hSerial = CreateFile(comFile, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

	if (hSerial == INVALID_HANDLE_VALUE) {
		if (GetLastError() == ERROR_FILE_NOT_FOUND) {
			printf("Error com not opened\n");
			return -1;
			//serial port does not exist. Inform user.
		}
		//some other error occurred. Inform user.
	}


	DCB dcbSerialParams = { 0 };

	dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
	if (!GetCommState(hSerial, &dcbSerialParams)) {

		printf("Error getting state\n");
		close();
		return -1;
	}
	dcbSerialParams.BaudRate = CBR_9600;
	dcbSerialParams.ByteSize = 8;
	dcbSerialParams.StopBits = ONESTOPBIT;
	dcbSerialParams.Parity = NOPARITY;
	if (!SetCommState(hSerial, &dcbSerialParams)) {

		printf("Error Setting State\n");
		close();
		return -1;
	}

	COMMTIMEOUTS timeouts = { 0 };
	timeouts.ReadIntervalTimeout = 50;
	timeouts.ReadTotalTimeoutConstant = 50;
	timeouts.ReadTotalTimeoutMultiplier = 10;

	timeouts.WriteTotalTimeoutConstant = 50;
	timeouts.WriteTotalTimeoutMultiplier = 10;
	if (!SetCommTimeouts(hSerial, &timeouts)) {
		printf("Error Setting Timeouts\n");
		close();
		return -1;
	}
	
	CrossPlatform::threadSleep(2000);
	opened = true;
	return 0;
}

void WindowsCOM::close()
{
	CloseHandle(hSerial);
	opened = false;
}

int WindowsCOM::write(const char* write_data, int byte_count)
{
	DWORD bytesWritten;
	
	DWORD bytesWrittenTotal = 0;
	do
	{
		if (!WriteFile(hSerial, write_data + bytesWrittenTotal, byte_count, &bytesWritten, NULL))
		{
			printf("Got write file error: %i\n", GetLastError());
			return -1;
		}

		printf("written: %s of size: %i bytes to com with offset %i\n", write_data, bytesWritten, bytesWrittenTotal);
		bytesWrittenTotal += bytesWritten;
	} while (bytesWritten > 0 && bytesWrittenTotal < byte_count);

	return 0;
}

int WindowsCOM::read(char* read_data, int byte_count)
{
	DWORD bytesRead;

	if (!ReadFile(hSerial, read_data, byte_count, &bytesRead, NULL))
		return -1;

	return bytesRead;
}
