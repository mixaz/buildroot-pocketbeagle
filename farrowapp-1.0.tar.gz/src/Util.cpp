#include "Util.h"
#include <chrono>
#include <fstream>
#include <sstream>
#include <memory>
#include <vector>
#include <string>
#include <iterator>
#include <errno.h>
#include <mutex>
#include <cstdarg>
#include "CrossPlatform.hpp"
#include <array>
#include <stdexcept>
#include <iostream>
#ifdef WIN32
#include <windows.h>
#else
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#endif
#include "FarrowLog.h"


using namespace std;
using namespace std::chrono;

// initialize static member mutex


Util::Util()
{
}


Util::~Util()
{
}
// varying function names between linux and windows
#ifdef WIN32
#define pclose _pclose
#define popen _popen
#endif

//Method copied from: https://stackoverflow.com/questions/478898/how-do-i-execute-a-command-and-get-output-of-command-within-c-using-posix
//This method does not capture whether command exists or not
bool Util::executeCmdCrossPlatform(const string& cmd, string& result, bool useResult) {
	std::array<char, 128> buffer;

	AppLog::write("Executing command '" + cmd + "'\n");
	FILE* fileOpened = popen(cmd.c_str(), "r");

	try
	{
		if (fileOpened == NULL)
			throw std::runtime_error("popen() failed!");

		std::unique_ptr<FILE, decltype(&pclose)> pipe(fileOpened, pclose);

		if (pipe == NULL) {
			throw std::runtime_error("pipe failed!");
		}
		if (true || useResult) //Somehow some commands execute differently when not reading their output, so do it every time. For example "docker run" commands would stop container, if no output was read.
		{

			while (fgets(buffer.data(), buffer.size(), pipe.get()) != nullptr) {
				string recStr(buffer.data(), buffer.size());
				result += recStr;
			}
		}
	}

	catch (int e)
	{
		result = "Got error: " + to_string(e);
		return false;
	}

	return true;
}

bool Util::executeCmdCrossPlatform(const string& cmd) {
	string empty;
	return executeCmdCrossPlatform(cmd, empty, false);
}


bool Util::executeCmdCrossPlatform(const string &cmd, string& result) {
	return executeCmdCrossPlatform(cmd, result, true);
}

bool Util::isHexString(const std::string& str)
{
	for (const char& c: str)
	{
		bool isNumber = c >= 48 && c <= 57;
		bool isAThruF = c >= 97 && c <= 102 || c >= 65 && c <= 70;

		if (!isNumber && !isAThruF) //Return false if character is not nubmer or "a" thru "f"
		{
			printf("%i is not hex digit\n", c);
			return false;
		}
	}
	return true;
}

std::string Util::hexPadded(int value, int width)
{
	std::string returnStr = "";
	std::stringstream valueStrStr;
	valueStrStr << std::hex << value;
	std::string valueStr = valueStrStr.str();
	for (int i = 0; i < width - valueStr.length(); i++)
	{
		returnStr += "0";
	}
	returnStr += valueStr;
	return returnStr;
}

unsigned long Util::getULongFromHex(const std::string& hexStr, bool has0xPrefix)
{
	std::string stringWithPrefix = has0xPrefix ? "0x" + hexStr : hexStr;
	return stoul(stringWithPrefix, nullptr, 16);
}

int Util::appendDigit(int original, int digit)
{
	printf("Appending %i and %i\n", original + digit);
	int result = stoi(to_string(original) + to_string(digit));
	printf("append result: %i\n", result);
	return result;
}

int Util::popDigit(int original, int defaultVal /*= -1*/)
{
	if (original <= 9)
	{
		return defaultVal;
	}
	
	string origStr = to_string(original);
	
	return stoi(origStr.substr(0, origStr.length() - 1));
}

std::string Util::getTimeStampNow(const time_point<system_clock>& timePointNow, bool delimitWith_)
{
	time_t now = system_clock::to_time_t(timePointNow);
	tm *time = localtime(&now);

	return Util::padSomeZerosAtStart(to_string(time->tm_year + 1900), 4) + "_" +
		Util::padSomeZerosAtStart(to_string(time->tm_mon + 1)) + (delimitWith_ ? "_" : "/") +
		Util::padSomeZerosAtStart(to_string(time->tm_mday)) + "_" +
		Util::padSomeZerosAtStart(to_string(time->tm_hour)) + (delimitWith_ ? "_" : ":") +
		Util::padSomeZerosAtStart(to_string(time->tm_min)) + (delimitWith_ ? "_" : ":") +
		Util::padSomeZerosAtStart(to_string(time->tm_sec));
}

std::string Util::getTimeStampNow(bool delimitWith_)
{
	time_point<system_clock> timePointNow = system_clock::now();
	time_t now = system_clock::to_time_t(timePointNow);
	tm *time = localtime(&now);

	
	return Util::padSomeZerosAtStart(to_string(time->tm_year + 1900), 4) + "_" +
		Util::padSomeZerosAtStart(to_string(time->tm_mon + 1)) + (delimitWith_ ? "_" : "/") +
		Util::padSomeZerosAtStart(to_string(time->tm_mday)) + "_" +
		Util::padSomeZerosAtStart(to_string(time->tm_hour)) + (delimitWith_ ? "_" : ":") +
		Util::padSomeZerosAtStart(to_string(time->tm_min)) + (delimitWith_ ? "_" : ":") +
		Util::padSomeZerosAtStart(to_string(time->tm_sec));
	
	
}


// This is a cpp wrapper of strerror_r_improved( )
std::string Util::strerror_r_cpp(int err)
{
#ifdef WIN32
	return "";
#else
	char buff[256];
	strerror_r_improved(err, buff, sizeof(buff));
	std::string ret = std::string(buff);

	return ret;
#endif
}


// C function. The POSIX and GNU versions of strerror_r( ) differ. This is an alternative way of getting the error string from an errno
void strerror_r_improved(int err, char * str, size_t str_len)
{
#ifdef WIN32
#else
	if (err < sys_nerr)
		snprintf(str, str_len, "%s", sys_errlist[err]);
	else
		snprintf(str, str_len, "Unknown error %d", err);

#endif
}


#ifdef __linux__
// C function. Blocking call to safely run an external command in a forked process. Returns the status code of the external command
int executeExternalLinuxProgram(char** params)
{
	int status, returned;
	pid_t childpid;

	childpid = fork();

	if (childpid == 0)
	{		
		char* const envParams[2] = { "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin", NULL };

		execve(params[0], params, envParams);

		// execv is not supposed to actually return, something went wrong if we get here
		exit(errno);
	}
	else if (childpid < 0)
	{
		perror("Failed to execute system command, could not create child process | ");
	}
	else
	{
		if (waitpid(childpid, &status, 0) != -1)
		{
			if (WIFEXITED(status))
			{
				returned = WEXITSTATUS(status);
				printf("Exited normally with status %d\n", returned);
				return returned;
			}
			else if (WIFSIGNALED(status))
			{
				int signum = WTERMSIG(status);
				printf("Exited due to receiving signal %d\n", signum);
				return signum;
			}
			else if (WIFSTOPPED(status))
			{
				int signum = WSTOPSIG(status);
				printf("Stopped due to receiving signal %d\n", signum);
				return signum;
			}
			else
			{
				printf("Something strange just happened.\n");
			}
		}
		else
		{
			perror("waitpid() failed");
		}
	}

	return -1;
}
#endif // __linux__
