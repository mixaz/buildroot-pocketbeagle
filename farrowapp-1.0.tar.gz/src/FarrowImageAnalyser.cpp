#include "FarrowImageAnalyser.h"
#include "FarrowLog.h"
#include "FarrowApp.h"

#include "LoraRequestBuilder.h"
#include "Util.h"
#include <condition_variable>
#include <mutex>
#include "DockerTfUtils.h"

//#include "Alexandra.cpp"

using namespace std;

FarrowImageAnalyser *instantiatedAnalyser = nullptr;


/*
string lastTimeStamp = "";
void receiveAnalysisResult(unsigned long timeStamp, event ev)
{
	AppLog::write("Received birth event at image: " + to_string(timeStamp) + " and time: " + lastTimeStamp);

	if (instantiatedAnalyser != nullptr)
	{
		instantiatedAnalyser->transmitResult(BIRTH_RESULT);
	}
}
*/

/**/

bool pigletSettingsInitialised = false;

EventTracker simpleTracker;

EventPlot pigletPlot;


FarrowImageAnalyser::FarrowImageAnalyser(void(*receiveResultCallback)(AnalysisResult result),
	FarrowApp &app, vector<int> birthAlarmIntervals)
	: app(app), birthAlarmIntervals(birthAlarmIntervals)
{
	instantiatedAnalyser = this;
	receiveResult = receiveResultCallback;

	imagesEnqueued.store(0);


	AppLog::write("Creating new analyser with folder: " + app.getCurrentDataFolder());

	if (trackingVarsLogLog != nullptr)
	{
		delete trackingVarsLogLog;
	}

	if (replacedTrackingLog != nullptr)
	{
		delete replacedTrackingLog;
	}

	if(!pigletSettingsInitialised)
	pigletSettings.init();
	
	//setup Alexandra stuff  //Constructor with callback not yet implemented by Katrine
	simpleTracker = EventTracker(pigletSettings, FarrowImageAnalyser::receiveAnalysisEvent,
		FarrowImageAnalyser::printIntermediateTrackingVars, FarrowImageAnalyser::printToReplacedTrackingLog,
		FarrowImageAnalyser::handleTrackerError);

	//simpleTracker = EventTracker(pigletSettings);

	//Image filter used by Alexandra code
	imMatFilter = cv::imread("ExecutableSupport/T40_imProfileRelInv.png", CV_LOAD_IMAGE_ANYDEPTH);
	if (!imMatFilter.data)
	{
		AppLog::write("Error loading image filter");
	}
	else
	{
		AppLog::write("Successfully loaded image filter");
	}
	imMatFilter.convertTo(imMatFilter, CV_16U); // Convert to frame image type

	analysisThread = thread(&FarrowImageAnalyser::analysisLoop, this);


	app.ui->setLEDValue(LED_CODE_ALARM, isAlarmed);
}

FarrowImageAnalyser::~FarrowImageAnalyser()
{
	finishAnalysisThreadBeforeDestruction();
	if (instantiatedAnalyser->trackingVarsLogLog != nullptr)
	{
		//instantiatedAnalyser->netowkAnalysisLog->writeToFile();
		delete instantiatedAnalyser->trackingVarsLogLog;
	}

	if (instantiatedAnalyser->replacedTrackingLog != nullptr)
	{
		//instantiatedAnalyser->replacedTrackingLog->writeToFile();
		delete instantiatedAnalyser->replacedTrackingLog;
	}

	//End Analysis loop and clear queue
	queue<tuple<ImageAndMetaData, string>> newQueue;
	analysisQueue.swap(newQueue);
	instantiatedAnalyser = nullptr;

	printf("Analyser destroyed\n");
}
uint32_t frameNr = 0;

void FarrowImageAnalyser::update()
{
	//Only notify dockerTF condition variables every 10th frame, as those processes are slow. We need to call it from update (main thread) as the analysis thread possibly waits for the condition variable
	if (frameNr++ % 10 == 0)
	{
		DockerTfUtils::notifyConditionVariables();
	}
}

void FarrowImageAnalyser::EnqueueFOrAnalysis(ImageAndMetaData& iAMD, std::string origin, bool forceAnalyseNow)
{	
	imagesEnqueued += 1;
	//printf("\rImage raw time: %lld last iamge raw time: %lld and %i/%i", iAMD.metaData.rawTime, lastImageRawTime, iAMD.metaData.rawTime, lastImageRawTime);
	
	//Only analyse now, if queue is disabled or empty and docker is running
	if (forceAnalyseNow && analysisQueue.size() == 0 && DockerTfUtils::getDockerContainerState(true) == DockerTfUtils::containerStateSuccessCode)
	{
		AnalyseImageAndMetadata(tuple<ImageAndMetaData&, string>(iAMD, origin));
	}
	else if (analysisQueue.size() < queueMax)
	{
		analysisMutexLock.lock();
		analysisQueue.push(tuple<ImageAndMetaData&, string>(iAMD, origin));
		analysisQueueSize = analysisQueue.size();
		analysisMutexLock.unlock();

		//analysisLoop();
		//AppLog::write("analysis queue size: " + analysisQueue.size());
	}
	else
	{
		AppLog::write("Image and metadat skipping analysis, as queue is full");
	}

}


void FarrowImageAnalyser::AnalyseImageAndMetadata(tuple<ImageAndMetaData, string> iAMDAndOrigin)
{
	ImageAndMetaData& iAMD = std::get<0>(iAMDAndOrigin);
	string origin = std::get<1>(iAMDAndOrigin);

	imagesAnalysed += 1;
	//AppLog::write("analysing image. - Left in queue: " + to_string(analysisQueue.size()));

	if (iAMD.image.depth() != CV_16U || // 2 == CV_16U, unsigned integer (ushort)
		iAMD.image.channels() != 1)  // Must have channels() = 1
	{
		AppLog::write("Image has malformed format - it is thus not analyzed");
		return;
	}

	lastAnalysedMetaData = iAMD.metaData;


	simpleTracker.track(pigletSettings, &iAMD.image,
		//test_imagesReceived,
		iAMD.metaData.rawTime, iAMD.metaData.imgNr, origin, &imMatFilter);

	//Check if it is the first image analysed - if so set the birth time to this
	if (lastBirthRawTime == 0)
	{
		lastBirthRawTime = iAMD.metaData.rawTime;
	}
	else
	{
		int allowedInterval = getAllowedIntervalForCurrentBirth();

		//AppLog::write("Allowed interval: " + to_string(allowedInterval) + " and pigl count: " + to_string(accumulatedPigletCount));

		int minutesSinceBirth = floor(GetTimeSinceLastBirthSecs() / 60);

		if (!isAlarmed && allowedInterval != -1 && minutesSinceBirth >= allowedInterval)
		{
			setAlarm();
		}
	}
}

float FarrowImageAnalyser::GetTimeSinceLastBirthSecs()
{
	int timeSinceLastBirth = lastBirthRawTime == 0 || lastAnalysedMetaData.rawTime == 0 ? -1 : (lastAnalysedMetaData.rawTime - lastBirthRawTime) * 0.001;
	
	return timeSinceLastBirth;

}

void FarrowImageAnalyser::transmitResult(AnalysisResult result)
{
	receiveResult(result);
}

void FarrowImageAnalyser::ProduceReport()
{
	AppLog::write("Producing analysis result in folder: " + app.getCurrentDataFolder());

	std::string filePath = app.getCurrentDataFolder() + "report.txt";

	ofstream *fileStream = new ofstream(filePath, ios_base::trunc);

	if (!fileStream)
	{
		AppLog::write("Analyser could not make file at: : " + filePath);
		return;
	}

	char analysisHeader[128];
	sprintf(analysisHeader, "Analysis analyzed/enqueued %i / %lld images and found %i births at times:\n", imagesAnalysed, imagesEnqueued.load(), birthMetaData.size());

	std::string analysisContent = analysisHeader;
	for (auto tS : birthMetaData)
	{
		analysisContent += tS.stringTime + "\t" + to_string(tS.imgNr) + "\n";
	}
	*fileStream << analysisContent.c_str();
	fileStream->flush();
	fileStream->close();
	delete fileStream;
}

void FarrowImageAnalyser::setPigletCount(int newCount)
{
	accumulatedPigletCount = newCount;
	lastBirthRawTime = 0;
}



void FarrowImageAnalyser::setAlarm()
{
	app.loraCom->enqueRequest(LoraRequestBuilder::getAlarmStartedEventRequest(getPigletCount()));
	AppLog::write("Setting alarm after birth interval (sec): " + to_string(GetTimeSinceLastBirthSecs()));
	//app.loraCom->enqueRequest(LoraRequestBuilder::getAlarmStartedEventRequest(app.getCurrentSessionId())); // TODO: remove line
	isAlarmed = true;
	app.ui->setLEDValue(LED_CODE_ALARM, isAlarmed);
}

void FarrowImageAnalyser::resetAlarm(bool updateLastBirthTime)
{
	if (updateLastBirthTime)
	{
		resetLastBirthTime();
	}

	isAlarmed = false;
	app.ui->setLEDValue(LED_CODE_ALARM, isAlarmed);
}

void FarrowImageAnalyser::createLogsWithPath(std::string path, FarrowTimer timer)
{
	litterLog = new FarrowLog(path + "recordLog.txt", timer, true);
	trackingVarsLogLog = new FarrowLog(path + "trackingVars.txt", timer, false);

	replacedTrackingLog = new FarrowLog(path + "networkLog.txt", timer, false);
}

void FarrowImageAnalyser::deleteLitterLog()
{
	if (litterLog != nullptr)
	{
		delete litterLog;
		litterLog = nullptr;
	}
}

void FarrowImageAnalyser::setBirthMetaData(FarrowImageMetaData fIM)
{
	resetAlarm(true);
	birthMetaData.push_back(fIM);
	lastBirthRawTime = fIM.rawTime;
}

int FarrowImageAnalyser::getAllowedIntervalForCurrentBirth()
{
	int intervalCount = birthAlarmIntervals.size();

	if (intervalCount == 0 || accumulatedPigletCount == 0)
		return -1;

	if (accumulatedPigletCount <= intervalCount)
	{
		return birthAlarmIntervals[accumulatedPigletCount - 1];
	}
	else
	{
		return birthAlarmIntervals.back();
	}
}

void FarrowImageAnalyser::receiveAnalysisEvent(event e)
{
	AppLog::write("Received event in callback from analysis: " + e);

	if (instantiatedAnalyser != nullptr)
	{
		AnalysisResult result = AnalysisResult::OTHER_RESULT;

		switch (e)
		{
			/*
			case none:
				break;
			case birth:
				break;
				*/
		case birth_piglet:
			instantiatedAnalyser->setBirthMetaData(instantiatedAnalyser->lastAnalysedMetaData);
			instantiatedAnalyser->accumulatedPigletCount += 1;
			result = AnalysisResult::BIRTH_RESULT;
			break;
			/*
			case birth_placenta:
				// Probably shouldn't be called in analyser
				instantiatedAnalyser->app.loraCom->enqueRequest(LoraRequestBuilder::getPlacentaDetectedEventRequest(instantiatedAnalyser->app.getCurrentSessionId()));
				break;
			case piglet_dead:
				break;
			case pig_moving:
				break;
			case pig_standing:
				break;

			default:

				break;
			*/
		}
		instantiatedAnalyser->transmitResult(result);
	}
}

void FarrowImageAnalyser::printIntermediateTrackingVars(TrackingVars tV)
{
	//AppLog::write(trackingVarsDescription.str());


	if (instantiatedAnalyser != nullptr && instantiatedAnalyser->trackingVarsLogLog != nullptr)
	{
		/*
		std::ostringstream trackingVarsDescription;
		trackingVarsDescription << "\nTracking vars:\n";
		trackingVarsDescription << "iNrOfOutliersMAD:\t" << tV.iNrOfOutliersMAD << "\n";

		trackingVarsDescription << "dIntMaxValModZScore:\t" << tV.dIntMaxValModZScore << "\n";

		trackingVarsDescription << "iIntensityLimPixelCount:\t" << tV.iIntensityLimPixelCount << "\n";

		trackingVarsDescription << "iIntensityThreshold:\t" << tV.iIntensityThreshold << "\n";

		trackingVarsDescription << "bRunNN:\t" << tV.bRunNN << "\n";
		*/
		char analysisArray[256];

		sprintf(analysisArray, "%i,%f,%4.0f,%i,%i,%i,%4.1f,%1.2f,%4.2f,%i" , tV.iNrOfOutliersMAD, tV.dIntMaxValModZScore, tV.dImMax, tV.iIntensityLimPixelCount, tV.iIntensityThreshold, tV.bRunNN ? 1 : 0, tV.dImageMean, tV.dMeanDiff, tV.dDistributionMean, tV.numberOfTrackedObjects);

		instantiatedAnalyser->trackingVarsLogLog->write(analysisArray, false, true);
	}
}


void FarrowImageAnalyser::printToReplacedTrackingLog(std::string msg)
{
	if (instantiatedAnalyser != nullptr && instantiatedAnalyser->replacedTrackingLog != nullptr)
	{
		instantiatedAnalyser->replacedTrackingLog->write(msg);
	}
}

void FarrowImageAnalyser::handleTrackerError(std::string errorMsg) 
{
	AppLog::writef("Got error from eventTracker: %s ", errorMsg);

	DockerTfUtils::signalConatinerNotRunning();
	instantiatedAnalyser->forceStartRestartDockerContainer.store(true);
	
}

void FarrowImageAnalyser::finishAnalysisThreadBeforeDestruction()
{
	analysisLoopIsRunning = false;
	
	if (analysisThread.joinable()) //Joinable is a way to check if the thread is initialized at all
		analysisThread.join(); //Join thread to make main thread wait for grab thread to finish

	printf("Analysis thread joined\n");
}
uint32_t analysisFrameNr = 0;

void FarrowImageAnalyser::analysisLoop()
{
	analysisLoopIsRunning = true;
	AppLog::write("Start analysis loop");
	try
	{
		if (DockerTfUtils::getDockerContainerState(false) != DockerTfUtils::containerStateSuccessCode)
		{
			AppLog::write("Analysis loop trying to start/restart docker container during start phase");
			DockerTfUtils::startOrRestartTensorflowContainer();
		}
	}
	catch (const std::exception & e)
	{
		AppLog::write(std::string(e.what()));
	}

	try
	{
		while (analysisLoopIsRunning)
		{
			FarrowTimer fT;

			if (analysisQueue.size() > 0)
			{
				int iter = 0;
				//Boolean analysisLoopIsRunning included twice, as it can have changed during the getDockerContainerState
				while (analysisLoopIsRunning && DockerTfUtils::getDockerContainerState(iter++ % 100 != 1) != DockerTfUtils::containerStateSuccessCode && analysisLoopIsRunning)
				{
					if (forceStartRestartDockerContainer.load() || fT.getStopwatchRawTimeMS() > 30000)
					{
						forceStartRestartDockerContainer.store(false);
						try
						{

							AppLog::write("Analysis loop trying to start/restart docker container during loop");
							DockerTfUtils::startOrRestartTensorflowContainer();
						}
						catch (const std::exception& e)
						{
							AppLog::write(std::string(e.what()));
						}
						break;
					}
					CrossPlatform::threadSleep(1000);
				}

			
				if (analysisLoopIsRunning && DockerTfUtils::getDockerContainerState(true) == DockerTfUtils::containerStateSuccessCode && analysisLoopIsRunning)
				{
					analysisMutexLock.lock();
					tuple<ImageAndMetaData, string> iAMDAndOrigin = analysisQueue.front();
					analysisQueue.pop();
					analysisQueueSize = analysisQueue.size();
					analysisMutexLock.unlock();

					AnalyseImageAndMetadata(iAMDAndOrigin);
				}
			}
			CrossPlatform::threadSleep(1);
		}
		AppLog::write("Analysis loop ended");
	}
	catch (...)
	{
		printf("Caught exception in analysis loop\n");
	}
}

