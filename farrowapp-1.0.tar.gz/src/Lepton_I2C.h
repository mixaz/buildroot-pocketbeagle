#ifndef LEPTON_I2C
#define LEPTON_I2C
#include <functional>

void initFFCShutterMode();

void lepton_perform_ffc();

void lepton_log_information();

float read_T_cpu();

float lepton_read_T_aux();

float lepton_read_T_fpa();

void lepton_stop(std::function<void()> progressFnc);

void lepton_initialize(bool useShutter, bool useNoiseFilters, std::function<void()> progressFnc);

#endif
