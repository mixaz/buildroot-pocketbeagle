#pragma once
#include "FarrowImageGrabber.h"
#include "FarrowApp.h"
#include <ctime>
#include <stdint.h>

#include <opencv2/core/core.hpp> 

#ifdef BEAGLE_BONE
#include "LeptonPruLib.h"

#endif // BEAGLE_BONE


class Lepton3Grabber :
	public FarrowImageGrabber
{
public:
	Lepton3Grabber(FarrowApp &app, int softResetDur, int hardResetDur, int hardResetNoImgDur, bool useNoiseFilters, bool debugForceNormalise = false);
	virtual ~Lepton3Grabber();

	virtual std::string getName() override { return "Lepton 3"; }

	virtual cv::Mat getMatFromSPI() { return cv::Mat(); };

	virtual bool highRes() { return true; };
	

protected:


	virtual void setMetaDataNow(FarrowImageMetaData& fM) override;


	virtual void setupCameraFNC(std::function<void()> progressCB) override;


	virtual bool grabberLoopUpdate() override;


	virtual void stopCameraFNC(std::function<void() > progressCB) override;

private:
	bool useNoiseFilters;
	std::string stLastFPATemp;

	FarrowTimer tempReadTimer;
	FarrowTimer frameTimer;
	volatile unsigned long long lastGrabTimeMillis = 0;
	float lastFPATemp = 99;

	bool forceNormalise = false;
#ifdef BEAGLE_BONE
	LeptonPruContext pruContext;
	volatile int fileDesc;
	size_t bytesPrFrame = sizeof(uint16_t) * IMAGE_WIDTH * IMAGE_HEIGHT;
	
#endif //BEAGLE_BONE
	

};