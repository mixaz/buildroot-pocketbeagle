#include "FarrowUI.h"
#include <string>
#include "FarrowLog.h"
#include <iostream>
using namespace std;



bool FarrowUI::anyBtnPressed()
{
	return getPressedAssist() || getPressedStart() || getNumberPressed() >= 0 || getPressedOK() || getPressedBack();
}

void FarrowUI::clearLEDCycleStates()
{
	//AppLog::write("Clearing LED Cycles");
	for (auto kVP : activeLEDCycles)
	{
		setLEDValue(kVP.first, 0);
	}

	activeLEDCycles.clear();
	lastOutputValue.clear();
}

void FarrowUI::addLEDCycle(StateCycle cycle, UIOutputType key)
{
	//AppLog::write("Adding LED Cycle with periodMS: " + to_string(cycle.periodMS) + " with key: " + to_string(key));
	activeLEDCycles[key] = cycle;
}
/*
void FarrowUI::updateOutput()
{
	for (auto kVP : activeLEDCycles)
	{
		float value = kVP.second.getValue();
		if (!lastOutputValue.count(kVP.first) || lastOutputValue[kVP.first] != value)
		{
			//AppLog::write("Setting LED: " + to_string(kVP.first) + " to: " + to_string(value));
			lastOutputValue[kVP.first] = value;
			setLEDValue(kVP.first, value);
		}
	}
	if (hasWaitMessages())
	{
		printWaitMessages();
	}
}
*/



void FarrowUI::deployWaitMsg(void* keyObj, std::string msg)
{
	waitMessages[keyObj] = msg;
	//printf("Deploying wait msg: %s. in dict: %s\n", msg.c_str(), waitMessages[keyObj].c_str());
	msgCounts = msgCounts++ % 8;
	printWaitMessages();

}

void FarrowUI::revokeWaitMsg(void* keyObj)
{
	auto iter = waitMessages.find(keyObj);
	if (iter != waitMessages.end())
	{
		waitMessages.erase(iter);
	}

	printWaitMessages();
}

bool FarrowUI::getWaitMessage(std::string& line1, std::string& line2)
{
	if (waitMessages.size() > 0)
	{
		std::string msg = "";
		for (const auto kvp : waitMessages)
		{
			msg += kvp.second;
			msg += ", ";
		}
		line1 = msg.substr(0, msg.length() - 2);
		line2 = Util::padSomeStringsAtStart("-", " ", msgCounts);
		return true;
	}
	else
	{
		return false;
	}
}

std::string FarrowUI::adaptStringToDigits(std::string orig, int digits)
{
	int strLen = orig.length();
	string newStr = orig;

	if (strLen > digits)
	{
		AppLog::write("Tried to adapt string to " + to_string(digits) + " with string longer than that - length: " + to_string(strLen));
		return string(digits, '_');
	}
	else if (strLen < digits)
	{
		newStr = std::string(digits - strLen, '_').append(orig);
	}
	
	return newStr;
}

bool FarrowUI::drawWaitMessages()
{
	string waitStr = "",waitStrDots = "";
	if (getWaitMessage(waitStr, waitStrDots))
	{
		clearDisplay(false);
		setDisplayLine("Waiting for: ", 2);
		setDisplayLine(waitStr, 3);
		setDisplayLine(waitStrDots, 4);
		return true;
	}
	return false;
}

void FarrowUI::printWaitMessages()
{
	string waitStr = "", waitStrDots = "";
	if (getWaitMessage(waitStr, waitStrDots))
	{
		printf("Waiting for: %s %s\n", waitStr.c_str(), waitStrDots.c_str());
	}
	else
	{
		//printf("No longer waiting for anything\n");
	}
}
