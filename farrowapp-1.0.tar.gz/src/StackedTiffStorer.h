#pragma once
#include "opencv2/imgproc/imgproc.hpp"
#include <thread>
#include "FarrowTimer.h"
#include <map>
#include "FarrowImageMetaData.h"
#include "FarrowLog.h"
class FarrowApp;

class StackedTiffStorer
{
public:
	StackedTiffStorer(FarrowApp& app, std::string dirPath);
	~StackedTiffStorer(void);
	bool getIsWriting();
	void storeImagesAsStackedTiff(ImageAndMetaData *mats, int stackSize, bool useSecondsInFileName);

private:
	FarrowApp& app;
	static void writeTiff(ImageAndMetaData *mats, int stackSize, bool useSecondsInFileName, std::string dirPath);
	static void handleTiffError(const char *module, const char *fmt, va_list ap);
	static std::map<int, std::string> lettersForInts;
	std::thread *writeThread = nullptr;
	std::string dirPath;
};

