#include "BeagleDisplay.h"
#include "FarrowLog.h"
#include "device_drivers/SSD1306_OLED.h"

BeagleDisplay::BeagleDisplay()
{

#ifdef WIN32
#else
	std::unique_lock<std::mutex> guard(displayMtx);

	// Initialize display and clear screen buffer
	display_Init_seq();
	clearDisplay();

	// Rotate screen upside down (90 == 180 for some reason)
	setRotation(90);

	// Set the color and reset cursor
	setTextColor(WHITE);
	setTextSize(2);
	setCursor(0, 0);

	Display();
#endif
}


BeagleDisplay::~BeagleDisplay()
{
#ifdef WIN32
#else
	std::unique_lock<std::mutex> guard(displayMtx);
	display_close();
#endif
}

void BeagleDisplay::clear()
{
#ifdef WIN32
#else
	std::unique_lock<std::mutex> guard(displayMtx);
	clearDisplay();
#endif
}

void BeagleDisplay::update()
{
#ifdef WIN32
#else
	std::unique_lock<std::mutex> guard(displayMtx);
	Display();
#endif
}
/*
void BeagleDisplay::drawPigletCount(std::string s)
{

#ifdef WIN32
#else
	std::unique_lock<std::mutex> guard(displayMtx);

	clearLine(1);
	clearLine(2);

	setCursor(0, 0);
	print_str("CA ");

	setCursor((_CHAR_WIDTH*5 -s.length()*_CHAR_WIDTH - 6),0);
	print_str(s.c_str());

	setCursor(36+2*_CHAR_WIDTH,0);
	print_strln("PIGS");

#endif
}

void BeagleDisplay::drawTimeSinceBirth(std::string s)
{
#ifdef WIN32
#else
	std::unique_lock<std::mutex> guard(displayMtx);

	fillRect(0, CHAR_HEIGHT*2, _CHAR_WIDTH*6, CHAR_HEIGHT*2, BLACK);
	setCursor((_CHAR_WIDTH * 5 - s.length()*_CHAR_WIDTH -6), CHAR_HEIGHT*2);
	print_str(s.c_str());
	setCursor(36 + 2*_CHAR_WIDTH,CHAR_HEIGHT*2);
	print_str("MIN");

#endif
}
*/

void BeagleDisplay::drawBattery(int startX, int startY, int percent)
{
	batteryX = startX;
	batteryY = startY;
#ifdef WIN32
#else
	std::unique_lock<std::mutex> guard(displayMtx);

	if (percent < 0 || percent > 100 || startX < 0 || startY < 0)
	{
		return;
	}
	int bat = ((16 * percent) / 100);

	// Clear area
	fillRect(batteryX, batteryY, 16, 24, BLACK);

	// draw battery container
	drawRect(startX, startY + 2, 14, 22, WHITE);
	drawRect(startX + 1, startY + 3, 12, 20, WHITE);
	fillRect(startX + 3, startY, 8, 2, WHITE);

	// draw battery fill
	fillRect(startX + 3, (startY + 5 + 16 - bat), 8, bat, WHITE);

#endif
}

void BeagleDisplay::writeLine(std::string text, int line , int alignment, bool clear)
{
	if (line < 1 || line > 4)
	{
		throw std::logic_error("Line number out of range");
	}
#ifdef WIN32
#else
	std::unique_lock<std::mutex> guard(displayMtx);

	int startX = 0;
	int startY = (line * CHAR_HEIGHT) - CHAR_HEIGHT;

	if (clear)
	{
		clearLine(line * 2);
		clearLine((line * 2) - 1);
	}

	if (text.length() >= 10)
	{
		setCursor(startX, startY);
		print_str(text.substr(0, 10).c_str());
	}
	else
	{
		switch (alignment)
		{
		case 0:
			// Right alignment
			fillRect(startX, startY, text.length() * _CHAR_WIDTH, CHAR_HEIGHT, BLACK);
			setCursor(0, (line * CHAR_HEIGHT) - CHAR_HEIGHT);
			break;

		case 1:
			// Center alignment
			startX = SSD1306_LCDWIDTH/2 - (((float)text.length()/ 2) * _CHAR_WIDTH);
			fillRect(startX, startY, _CHAR_WIDTH * text.length(), CHAR_HEIGHT, BLACK );
			setCursor(startX, startY);
			break;
		case 2:
			//Right alignment
			startX = SSD1306_LCDWIDTH - (text.length()* _CHAR_WIDTH);
			fillRect(startX, startY, _CHAR_WIDTH * text.length(), CHAR_HEIGHT, BLACK);
			setCursor(startX, startY);
		}
		print_str(text.c_str());
	}
#endif
}

void BeagleDisplay::writeCenteredText(std::deque<std::string> lines)
{
	std::unique_lock<std::mutex> guard(displayMtx);

	if (lines.size() > 8)
	{
		throw std::logic_error("Number of lines out of range");
	}
#ifdef WIN32
#else
	else if(!lines.empty())
	{
		clearDisplay();

		int width = lines.size() > 4 ? _CHAR_WIDTH/2 : _CHAR_WIDTH;
		int height = lines.size() > 4 ? CHAR_HEIGHT / 2 : CHAR_HEIGHT;
		int size = lines.size() > 4 ? 1 : 2;
		
		if(lines.front().length() > 10)
		{
			lines[0] = lines.front().substr(0, 10);
		}
		
		int x = SSD1306_LCDWIDTH/2 - (((float)lines.front().length()/ 2) * width);
		int y = SSD1306_LCDHEIGHT/2 - (((float) lines.size() / 2) * height);
		setTextSize(size);

		setCursor(x,y);

		while (!lines.empty())
		{ 
			
			print_str(lines.front().c_str());
			lines.pop_front();
			
			if(!lines.empty())
			{
				if(lines.front().length() > 10)
				{
					lines[0] = lines.front().substr(0, 10);
				}
				
				x = SSD1306_LCDWIDTH/2 - (((float)lines.front().length()/ 2) * width);
				y += height;

				setCursor(x, y);
			}
		}
	}
	setTextSize(2);
#endif
}

void BeagleDisplay::clearBattery()
{
#ifdef WIN32
#else
	std::unique_lock<std::mutex> guard(displayMtx);

	fillRect(batteryX, batteryY, 16, 24, BLACK);
#endif
}

void BeagleDisplay::setOnOff(bool on)
{
#ifdef WIN32
#else
	setDisplayOnOff(on);
#endif
}
