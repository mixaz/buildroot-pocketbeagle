#pragma once
#include "Request.hpp"
#include <sstream>

class LoraRequestBuilder
{
public:
	
	LoraRequestBuilder();
	~LoraRequestBuilder();

	static Request getHeartbeatRequest(const Request::cb_t& cb = nullptr);
	static Request getGetTimeRequest(const Request::cb_t& cb = nullptr);

	static Request getBirthDetectedEventRequest(unsigned char numberInLitter);
	static Request getPlacentaDetectedEventRequest(unsigned char pigletsBornSoFar);

	static Request getAssistanceStartedEventRequest(unsigned char pigletsBornSoFar);
	static Request getAssistanceEndedEventRequest(unsigned char liveCount, unsigned char deadCount, unsigned char pigletsBornSoFar);

	static Request getAlarmStartedEventRequest(unsigned char pigletsBornSoFar);

	static Request getRecordingStartedEventRequest(unsigned char pigletsBornSoFar, unsigned short sowNr, unsigned short penNr);
	static Request getRecordingEndedEventRequest(unsigned char totalLiveCount, unsigned char totalDeadCount);

	static Request getFaultEventRequest(unsigned char errCode);

	static Request getSignalTestRequest(const Request::cb_t& cb);

	static void setOldFlag(Request& req);
	static void setBattteryLevel(unsigned char level) { batteryLevel = level; }
	static void calculateAndSetSessionId();
	
private:
	static std::string getSessionId();
	static unsigned char batteryLevel;
	static unsigned short sessionId;
	static std::stringstream getStreamWithHeader(Request::COMMAND_TYPE ty);
};
