#include "LoraRequestBuilder.h"
#include "FarrowLog.h"
#include "CrossPlatform.hpp"
#include "FarrowApp.h"
#include <sstream>

using namespace std;
using namespace std::chrono;

string cpuSerial = "";
bool cpuSerialSet = false;

string getDeviceId()
{
	if (!cpuSerialSet)
	{
		cpuSerial = CrossPlatform::getDeviceId();
		cpuSerialSet = true;
	}
	stringstream strStr;
	strStr << cpuSerial;
	return strStr.str();
}


string produceTimeStamp()
{
	return Util::hexPadded(time(nullptr), 8);
}

string LoraRequestBuilder::getSessionId()
{
	return Util::hexPadded(sessionId, 4);
}


void LoraRequestBuilder::calculateAndSetSessionId()
{
	auto now = system_clock::now();
	time_t tnow = system_clock::to_time_t(now);
	tm* date = localtime(&tnow);
	date->tm_hour = 0;
	date->tm_min = 0;
	date->tm_sec = 0;
	auto midnight = system_clock::from_time_t(mktime(date));

	int secsSinceMidnight = duration_cast<seconds>(now - midnight).count();

	sessionId = secsSinceMidnight / 2;

	AppLog::writef("Calculated session id to: %i", sessionId);
}



unsigned char LoraRequestBuilder::batteryLevel = 0;

unsigned short LoraRequestBuilder::sessionId = 0;

LoraRequestBuilder::LoraRequestBuilder()
{
}


LoraRequestBuilder::~LoraRequestBuilder()
{
}

Request LoraRequestBuilder::getHeartbeatRequest(const Request::cb_t& cb)
{
	stringstream reqBody = getStreamWithHeader(Request::COMMAND_TYPE::HEARTBEAT);
	return Request(reqBody.str(), cb);
}

Request LoraRequestBuilder::getBirthDetectedEventRequest(unsigned char numberInLitter)
{
	stringstream reqBody = getStreamWithHeader(Request::COMMAND_TYPE::BIRTH);

	reqBody << getSessionId();

	reqBody << produceTimeStamp();

	reqBody << Util::hexPadded(numberInLitter, 2);

	return Request(reqBody.str());
}

Request LoraRequestBuilder::getPlacentaDetectedEventRequest(unsigned char pigletsBornSoFar)
{
	stringstream reqBody = getStreamWithHeader(Request::COMMAND_TYPE::PLACENTA_BIRTH);

	reqBody << getSessionId();

	reqBody << produceTimeStamp();

	reqBody << Util::hexPadded(pigletsBornSoFar, 2);

	return Request(reqBody.str());
}

Request LoraRequestBuilder::getAlarmStartedEventRequest(unsigned char pigletsBornSoFar)
{
	stringstream reqBody = getStreamWithHeader(Request::COMMAND_TYPE::ALARM_START);

	reqBody << getSessionId();

	reqBody << produceTimeStamp();

	reqBody << Util::hexPadded(pigletsBornSoFar, 2);

	return Request(reqBody.str());
}

Request LoraRequestBuilder::getAssistanceStartedEventRequest(unsigned char pigletsBornSoFar)
{
	stringstream reqBody = getStreamWithHeader(Request::COMMAND_TYPE::ASSIST_STARTED);

	reqBody << getSessionId();

	reqBody << produceTimeStamp();

	reqBody << Util::hexPadded(pigletsBornSoFar, 2);

	return Request(reqBody.str());
}

Request LoraRequestBuilder::getAssistanceEndedEventRequest(unsigned char liveCount, unsigned char deadCount, unsigned char pigletsBornSoFar)
{
	stringstream reqBody = getStreamWithHeader(Request::COMMAND_TYPE::ASSIST_ENDED);

	reqBody << getSessionId();

	reqBody << produceTimeStamp();

	reqBody << Util::hexPadded(pigletsBornSoFar, 2);

	reqBody << Util::hexPadded(liveCount, 2);

	reqBody << Util::hexPadded(deadCount, 2);

	return Request(reqBody.str());
}

Request LoraRequestBuilder::getFaultEventRequest(unsigned char errCode)
{
	stringstream reqBody = getStreamWithHeader(Request::COMMAND_TYPE::FAULT_SITUATION);

	reqBody << produceTimeStamp();

	reqBody << Util::hexPadded(errCode, 2);

	return Request(reqBody.str());
}


Request LoraRequestBuilder::getSignalTestRequest(const Request::cb_t& cb)
{
	Request req("!RSSI", cb);
	req.hasDeviceIdAndType = false;
	return req;
}

Request LoraRequestBuilder::getRecordingStartedEventRequest(unsigned char pigletsBornSoFar, unsigned short sowNr, unsigned short penNr)
{
	stringstream reqBody = getStreamWithHeader(Request::COMMAND_TYPE::RECORDING_STARTED);

	reqBody << getSessionId();

	reqBody << produceTimeStamp();

	reqBody << Util::hexPadded(pigletsBornSoFar, 2);

	reqBody << Util::hexPadded(sowNr, 4);

	reqBody << Util::hexPadded(penNr, 4);

	return Request(reqBody.str());
}

Request LoraRequestBuilder::getRecordingEndedEventRequest(unsigned char totalLiveCount, unsigned char totalDeadCount)
{
	stringstream reqBody = getStreamWithHeader(Request::COMMAND_TYPE::RECORDING_ENDED);

	reqBody << getSessionId();

	reqBody << produceTimeStamp();

	reqBody << Util::hexPadded(totalLiveCount, 2);

	reqBody << Util::hexPadded(totalDeadCount, 2);

	return Request(reqBody.str());
}

Request LoraRequestBuilder::getGetTimeRequest(const Request::cb_t& cb /*= nullptr*/)
{
	stringstream reqBody = getStreamWithHeader(Request::COMMAND_TYPE::GET_TIME);

	return Request(reqBody.str(), cb);
}


stringstream LoraRequestBuilder::getStreamWithHeader(Request::COMMAND_TYPE ty)
{
	stringstream header;
	header << getDeviceId();

	header << Util::hexPadded(ty, 2);

	header << Util::hexPadded(batteryLevel, 2);

	return header;
}


