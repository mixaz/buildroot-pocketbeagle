#pragma once
#include <string>
#include "opencv2/imgproc/imgproc.hpp"
class FarrowImageMetaData
{
public:
	FarrowImageMetaData();
	FarrowImageMetaData(std::string jsonStr);
	
	~FarrowImageMetaData();

	std::string dumpToString();

	//float t_cpu;
	std::string t_fpa;
	//float t_ext;
	//float t_aux;
	long long rawTime = 0;
	int imgNr = -1;
	std::string stringTime;
	//long long newRawTime = 0;
	//std::string newStringTime;
};

class ImageAndMetaData
{
public:
	
	ImageAndMetaData() {};// : image(cv::Mat()) {};
	ImageAndMetaData(cv::Mat img, FarrowImageMetaData meta) : image(img), metaData(meta) {}

	bool operator==(ImageAndMetaData rhs)const {
		return (image.ptr() == rhs.image.ptr());
	}

	FarrowImageMetaData metaData;
	cv::Mat image;
};
