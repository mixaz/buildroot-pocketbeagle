#include "StateCycle.h"

float StateCycle::getValue()
{
	float rawValue = -1;

	unsigned long long timeNow = timer.getStopwatchRawTimeMS();

	if (multiplyFactor != 1 && timeNow > multiplyUntil)
		multiplyFactor = 1;

	switch (shape)
	{
	case CycleShape::SQUARE:
	{
		const bool on = ((int)(timeNow * doubleInversePeriod * multiplyFactor) + 2) % 2 == 0;
		rawValue = on ? 1 : 0;
		break;
	}
	default:
		break;
	}

	return rawValue == -1 ? -1 : rawValue * scale + minValue;
}

void StateCycle::setFreqMultiplier(float factor, int durationMS)
{
	multiplyFactor = factor;
	multiplyUntil = timer.getStopwatchRawTimeMS() + durationMS;
}
