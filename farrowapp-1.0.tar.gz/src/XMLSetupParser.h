#pragma once
#include "tinyxml2.h"
#include "FarrowImageGrabber.h"
#include <vector>
#include <string>
#include <memory>
#include <queue>
#include "FarrowUI.h"
#include "Request.hpp"

class FarrowApp;

class XMLSetupParser
{
public:
	XMLSetupParser(void);
	~XMLSetupParser(void);

	struct ConstantsFromXML
	{
		int grabFrameRate;
		int stackDurationMinutes;
		//bool useSecondsInTif;
		bool saveImages;
		bool analyseImages;
		std::vector<int> alarmIntervals;
		int minDiskSpace;
		//bool outputIntermediateAnalysisVars;
		//bool replaceTrackingLog;
		bool useGlobalAppLog;
		bool lowBatShutdown;
		bool useLoraCom;
		bool requireGatewayTime;
	};

	static std::unique_ptr<tinyxml2::XMLDocument> loadXMLfromFile(std::string path, int retries = 0);

	static FarrowImageGrabber *parseToGrabber(tinyxml2::XMLElement *grabberElement, FarrowApp& app);

	static std::vector<FarrowImageGrabber *> parseToGrabbers(tinyxml2::XMLElement *rootNode, FarrowApp& app);

	static void parseToConstants(tinyxml2::XMLElement *rootNode, ConstantsFromXML& constantsStruct);

	static FarrowUI *parseToUI(tinyxml2::XMLElement *uiElement, FarrowApp& app);

#ifdef USE_WEBCOM
	static WebCommunicator *parseToWebCom(tinyxml2::XMLElement *rootNode, FarrowApp& app, std::string deviceId);
#endif

	static std::vector<FarrowUI *> parseToUIs(tinyxml2::XMLElement *rootNode, FarrowApp& app);

	static std::vector<tinyxml2::XMLElement *> getElementsWidthActiveBoolAttribute(tinyxml2::XMLElement *rootNode, char *elementTag);

	static std::unique_ptr<std::queue<Request>> XMLToLoraRequests(tinyxml2::XMLElement* rootElem);
	static std::unique_ptr<tinyxml2::XMLDocument> LoraRequestsToXML(std::queue<Request> reqs);

};

