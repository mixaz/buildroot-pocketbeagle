#pragma once
#include "device_drivers/TCA9555_cpp.hpp"
#include "FarrowTimer.h"
#include <mutex>
#include <atomic>

class BeagleKeypad
{
public:
	enum ButtonStatus
	{
		QUARANTINED,
		UP,
		DOWN,
		SHORT_PRESS,
		LONG_PRESS,
		NONE,
	};

	BeagleKeypad(TCA9555& tca);
	~BeagleKeypad();

	void init();
	void update();

	int getCurrentButton();
	ButtonStatus getCurrentButtonStatus();

private:

	FarrowTimer btnDownTimer;

	std::mutex keypadMtx;

	unsigned short currentReadValue = 0x00;	
	/*std::atomic_int currentButton{ -1 };
	std::atomic<ButtonStatus> btnStatus{ UP };*/
	int currentButton = -1;
	ButtonStatus btnStatus = UP;

	// Button status booleans
	bool btnDownLastFrame = false;
	bool btnDownThisFrame = false;
	bool buttonQuarantined = false;

	// Masks for ignoring bits not used in keypad (1 = used 0 = not used)
	unsigned char inputMask0 = 0xFF;
	unsigned char inputMask1 = 0b00001111;

	TCA9555& tca;
};

