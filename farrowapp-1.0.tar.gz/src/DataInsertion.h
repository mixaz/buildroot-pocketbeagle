#pragma once
#include "StateCycle.h"

class FarrowApp;
class DataInsertionStep {
public:
	DataInsertionStep(std::vector<std::string> msgLines, std::string summaryLine, int& editedVal) :
		messageLines(msgLines), summaryLine(summaryLine), editedValue(editedVal)
	{
		value = editedVal;
	};

	std::vector<std::string> messageLines;
	std::string summaryLine;
	int& editedValue;
	int value = 0;
	int value_cached = 0;
};

class DataInsertionSession {
public:
	DataInsertionSession(FarrowApp& app) :app(app) {};
	FarrowApp& app;
	bool update();
	std::vector<DataInsertionStep> steps;
	std::vector<int> cachedValues;
	int getCurrentStepIndex() { return currentStepIndex; }
private:
	void flashCursor();
	void transition(bool isForward);
	FarrowTimer stepWaitTimer;
	std::string getTypeinNrString(int nr);
	int currentStepIndex = 0;
	int lastStepIndex = -1;
	int lastKeyPressed = -1;
	std::string lastInputLine = "SOME_NONE_MATCHING_LINE";
	StateCycle displayBlinkCycle;
	bool showingSummary = false;
	bool showedSummaryLastFrame = false;
	unsigned long long transitionUntil = 0;
	int transitionPhaseStepDuration;
	bool lastTransitionWasForward;
	int transitionedFromIndex = -1;
};