#include "FarrowLog.h"
#include "CrossPlatform.hpp"
#include <chrono>
#include <ctime>
#include <thread>
#ifndef WIN32
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#endif
#include "Util.h"

//#include "DoubleBuffer.hpp"

//#include "CrossPlatform.hpp"

using namespace std;
using namespace std::chrono;

thread fileWriterThread;
bool fileWriterThreadStarted = false;
bool fileWriterShouldRun = false;

FarrowLog::FarrowLog(std::string filePath, FarrowTimer& timer, bool subscribeToGlobalLog) :
	timer(timer), filePath(filePath)
{
	cout << "Setting up farrow log \n";
	if (!fileWriterThreadStarted)
	{
		fileWriterShouldRun = true;
		fileWriterThreadStarted = true;
		fileWriterThread = thread(&AppLog::fileWriteLoop);
	}
	/*
	if (std::ifstream(filePath))
	{
		std::cout << "File already exists - logging will append to this" << std::endl;
		return;
	}
	*/
	fileStream = new ofstream(filePath, ios_base::app);
	if (!fileStream)
	{
		cout << "logfile: " << filePath.c_str() << " - could not be created \n";
		return;
	}

	printf("Successfully created logfile: %s\n", filePath.c_str());

	AppLog::registerLog(this, subscribeToGlobalLog);
}

FarrowLog::~FarrowLog()
{
	AppLog::deregisterLog(this);
	writeToFile(false);
	fileStream->close();

#ifndef WIN32
	chmod(filePath.c_str(), 0777);
#endif

	
	delete fileStream;
}

void FarrowLog::writeToFile(bool aquireMutexLock /*= true*/)
{
	if (!hasUnwrittenData)
		return;

	if(aquireMutexLock)
		doubleBufferMutex.lock();

	doubleBufferStream.swap();
	
	if (aquireMutexLock)
		doubleBufferMutex.unlock();

	*fileStream << doubleBufferStream.getFrontRef();
	fileStream->flush();
	doubleBufferStream.getFrontRef() = "";

	hasUnwrittenData = false;
	//string msg = "Writing log at: " + filePath + "\n";
	//cout << msg;
}

void FarrowLog::write(string message, bool addTimestamp, bool flushNow)
{
	std::string stampAndMsg = "";

	if (addTimestamp)
	{
		time_point<system_clock> time = system_clock::now();
		string ms = to_string(time.time_since_epoch().count());
		ms = ms.substr(ms.length() - 3, 3);

		string timeString = Util::getTimeStampNow(time);
		timeString += " ## ";
		stampAndMsg += timeString;
		stampAndMsg += ms + " ## ";
		//stampAndMsg += timer.convertMSToString(timer.getStopwatchRawTimeMS(), true, true) + " ## ";
		
		//doubleBufferStream.getBackRef() += timeString;

		//doubleBufferStream.getBackRef() += timer.convertMSToString(timer.getStopwatchRawTimeMS(), true, true) + " ## ";
		/*
		*fileStream << timeString;

		*fileStream << timer.convertMSToString(timer.getStopwatchRawTimeMS(), true, true) + " ## ";
		*/
	}

	stampAndMsg += message + "\n";
	doubleBufferMutex.lock();
	doubleBufferStream.getBackRef() += stampAndMsg;
	doubleBufferMutex.unlock();
	hasUnwrittenData = true;
}



AppLog *_instance;


void AppLog::stopFileWriteLoop()
{
	if (fileWriterThread.joinable())
	{
		fileWriterShouldRun = false;
		fileWriterThread.join();
		cout << "Joined file writer thread!";
	}
}

void AppLog::fileWriteLoop()
{
	try
	{
		while (fileWriterShouldRun)
		{
			instance()->logSetMutex.lock();

			for (auto fL : instance()->registeredLogs)
			{
				if (fL == nullptr)
					continue;

				fL->writeToFile();
			}

			instance()->logSetMutex.unlock();

			CrossPlatform::threadSleep(1000);
		}

		cout << "Done write log file.";
	}
	catch (...)
	{
		printf("Got exception from log wrote loop\n");
	}
}

AppLog *AppLog::instance()
{
	if (_instance == nullptr)
		_instance = new AppLog();

	return _instance;
}

std::mutex AppLog::vsprintfMutex;

char AppLog::sprintfBuffer[2048];
