#pragma once
#include <string>
#include <deque>
#include <memory>
#include <mutex>

class BeagleDisplay
{
public:
	BeagleDisplay();
	~BeagleDisplay();

	const static int _CHAR_WIDTH = 12;
	const static int CHAR_HEIGHT = 16;

	void clear();
	void update();

	void drawPigletCount(std::string s);
	void drawTimeSinceBirth(std::string s);
	void drawBattery(int startX, int startY, int percentage);
	void writeLine(std::string text, int line = 1, int alignment = 0, bool clear = true);
	void writeCenteredText(std::deque<std::string> lines);
	void clearBattery();
	void setOnOff(bool on);
private:

	int batteryX = 0;
	int batteryY = 0;

	std::mutex displayMtx;
};

