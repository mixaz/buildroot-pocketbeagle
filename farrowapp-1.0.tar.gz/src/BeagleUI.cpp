#include "BeagleUI.h"
#include "BeagleDisplay.h"
#include "CrossPlatform.hpp"
#include "device_drivers/TCA9555_cpp.hpp"
#include "FarrowApp.h"
#include "PinManager.h"
#include "BeagleHardwareButton.h"
#include "device_drivers/UART.h"
#include "FarrowApp.h"

#ifdef BEAGLE_BONE
#include <stdlib.h>
#endif
#include "SystemWideVars.h"
using namespace std;

BeagleUI::BeagleUI(FarrowApp& fA)  : app(fA), tca(), keypad(tca), startBtn(BTN_START, tca, "START"), laserBtn(BTN_1, tca, "LASER"), timeBtn(BTN_2, tca, "TIME"), loraTestBtn(BTN_3, tca, "LORA TEST"), assistBtn(BTN_ASSIST, tca, "ASSIST"),
display(), blinkCycle(StateCycle(1000))
{
	lock_guard<recursive_mutex> guard(SystemWideVars::i2cLock);

	FarrowTimer fT;
	tca.init();
	keypad.init();

	// Configure LED pins as outputs
	tca.changePin(TCA9555_CONFIG1, 5, 0);
	tca.changePin(TCA9555_CONFIG1, 7, 0);

	// Set LEDs
	tca.writeReg(TCA9555_OUTPUT1, 0x5F);

	display.writeCenteredText({ "STARTING","PLEASE", "WAIT" });
	display.update();

}


BeagleUI::~BeagleUI()
{
	clearDisplay(true);
}

/*Called once pr. frame - returning false indicates and error and
makes the entire program clean up and shut down.
You can use this method to check for input etc., so that calls from FarrowApp to ie. isBTN_START_Short
will have something meaningful to return.*/
bool BeagleUI::update()
{
	lock_guard<recursive_mutex> guard(SystemWideVars::i2cLock);
	//AppLog::write("Beagle UI aquired lock");
	keypad.update();
	startBtn.update();
	laserBtn.update();
	timeBtn.update();
	loraTestBtn.update();
	assistBtn.update();
	
	if (timeBtn.getIsVeryLongPress())
	{
		printf("Time VERY long\n");
	}
	if (timeBtn.getIsLongPress())
	{
		printf("Time Long\n");
	}
	if (timeBtn.getIsShortPress())
	{
		printf("Time Short\n");
	}
	
	//Hande all buttons on the keypad
	BeagleKeypad::ButtonStatus currentKeypadStatus = keypad.getCurrentButtonStatus();
	int currentKeypadButton = keypad.getCurrentButton();

	nrDownThisFrame = -1;
	backPressed_short = false;
	okPRessed_short = false;
	if (currentKeypadButton != oldKeypadButton || currentKeypadStatus != oldKeypadStatus)
	{
		//printf("Keypad change: status: %i, button: %i\n", currentKeypadStatus, currentKeypadButton);
		oldKeypadButton = currentKeypadButton;
		oldKeypadStatus = currentKeypadStatus;
		if (currentKeypadStatus == BeagleKeypad::ButtonStatus::DOWN)
		{
			if (currentKeypadButton >= 0 && currentKeypadButton <= 8)
			{
				nrDownThisFrame = currentKeypadButton + 1;
			}
			else if (currentKeypadButton == 10)
			{
				nrDownThisFrame = 0;
			}
			else
			{
				nrDownThisFrame = -1;
			}

			//HAndle back
			backPressed_short = currentKeypadButton == 9;

			//Handle ok
			okPRessed_short = currentKeypadButton == 11;
		}
	}

	if (updateDisplay)
	{
		display.update();
		updateDisplay = false;
	}
	/*
	if (loraTestPassed)
	{
		CrossPlatform::threadSleep(2000);
		loraTestPassed = false;
		currentState = oldState;
		updateDisplay = true;
	}
	*/

	return true;
}

//Do your writing to LED pins here
void BeagleUI::setLEDValue(UIOutputType ledKey, float value)
{

	lock_guard<recursive_mutex> guard(SystemWideVars::i2cLock);
	int pinNr = getPinForLED_Code(ledKey);

	if (pinNr == -1)
	{
		AppLog::write("led key " + to_string(ledKey) + " is Not registered with a pin number");
		return;
	}


	int val = static_cast<int>(value);
	tca.changePin(TCA9555_OUTPUT1, pinNr, val);
}

unsigned char BeagleUI::getBatteryLevelPercent()
{
	double maxV = 4.15;
	double minV = 3.1;

	double Volt1 = 3.8;
	double Volt2 = 3.45;
	int Life1 = 36;
	int Life2 = 4;

	int read = readAnalog(0);
	double tmp = (((float)read / 4096) * 1.8 * 3) + 0.1; // +0.1 because voltage drops ~100 mV from voltage divider to ADC

	// Multiply, round to integer then divide again to get wanted decimal precision
	batteryVoltage = round(tmp * 100) / 100;

	//batteryLife = 100 - (int)(((maxV - batteryVoltage) / (maxV - minV))  * 100);
	bL1 = 100 - (int)(((maxV - batteryVoltage) / (maxV - Volt1)) * (100-Life1));
	bL2 = Life1 - (int)(((Volt1 - batteryVoltage) / (Volt1 - Volt2)) * (Life1-Life2));
	bL3 = Life2 - (int)(((Volt2 - batteryVoltage) / (Volt2 - minV)) * (Life2-0));
	int batteryLife = batteryVoltage > Volt1 ? bL1 : batteryVoltage < Volt2 ? bL3 : bL2;
	batteryLife = batteryLife > 100 ? 100 : batteryLife < 0 ? 0 : batteryLife;

	return batteryLife;
}

double BeagleUI::getBatteryVoltage()
{
	getBatteryLevelPercent();

	return batteryVoltage;
}


void BeagleUI::setSecsSinceBirth(int secs)
{
	if(secs/60 != minsSinceBirth)
	{	
		minsSinceBirth = secs/60;
		updateDisplay = true;
	}
}


void BeagleUI::drawTextCentered(std::string txt)
{
	display.writeCenteredText({ txt });
	updateDisplay = true;
}


void BeagleUI::clearDisplay(bool forceNow)
{
	display.clear();
	if (forceNow)
	{
		display.update();
	}
	updateDisplay = true;
}

void BeagleUI::setDisplayLine(std::string txt, int line)
{
	display.writeLine(txt, line);
	updateDisplay = true;
}


void BeagleUI::setDisplayOnOff(bool on)
{
	display.setOnOff(on);
}


bool BeagleUI::getIsInCharger()
{
	return PinManager::digitalRead(PinManager::IN_CHARGER);
}

int BeagleUI::getPinForLED_Code(UIOutputType lEDCode)
{
	if (lEDCode == LED_CODE_BATT_STAT_G)
		return 7;
	else if (lEDCode == LED_CODE__STATUS_G)
		return 7;
	else if (lEDCode == LED_CODE_ALARM)
		return 5;

	return -1;
}

int BeagleUI::readAnalog(int number)
{
	string s = ADC_PATH + to_string(number) + "_raw";
	fstream fs;

	fs.open(s.c_str(), fstream::in);
	fs >> number;
	fs.close();

	return number;
}

void BeagleUI::toggleLaser(ToggleType togTyp /*= ToggleType::TOGGLE_TOGGLE*/)
{
	laserOn = togTyp == ToggleType::TOGGLE_TOGGLE ? !laserOn : togTyp == ToggleType::TOGGLE_ON;

	//printf("Setting laser to: %i\n", laserOn);
	PinManager::digitalWrite(PinManager::LED_laser, laserOn ? 0 : 1);
}
