#pragma once
#include <string>
#include <opencv2/core/core.hpp>


class Color {
public:
	static cv::Scalar black;
	static cv::Scalar white;
	static cv::Scalar grey;
	static cv::Scalar blue;
	static cv::Scalar red;
	static cv::Scalar green;
	static cv::Scalar darkBlue;
	static cv::Scalar darkRed;
	static cv::Scalar darkGreen;
	static cv::Scalar yellow;
};

class GraphicUILED
{
public:
	GraphicUILED() {};
	GraphicUILED(const cv::Mat& uiPanelMat, int graphicalIndex, std::string titel, cv::Scalar color);
	~GraphicUILED();

	void setValue(float value);

	void setColor(cv::Scalar newColor) { color = newColor; }

private:
	int graphIndex;
	std::string titel;
	cv::Scalar color;
	cv::Mat uiPanelMat;
	cv::Mat ledBlockROI;
	cv::Mat ledROI;
	cv::Mat titleROI;
};

