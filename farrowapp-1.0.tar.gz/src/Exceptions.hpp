#pragma once
#include <stdexcept>

class UARTException: public std::runtime_error
{
public:
	UARTException(const char* msg) : 
		std::runtime_error(msg) {}

	~UARTException() = default;

};
