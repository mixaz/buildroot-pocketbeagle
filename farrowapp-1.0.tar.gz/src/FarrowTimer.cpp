#include "FarrowTimer.h"
#include <chrono>
#include "Util.h"

using namespace std::chrono;
using namespace std;

FarrowTimer::FarrowTimer(void)
{
	reset();
}


FarrowTimer::~FarrowTimer(void)
{
}

void FarrowTimer::reset()
{
	auto dur = steady_clock::now().time_since_epoch();
	startMs = duration_cast<milliseconds>(dur);
	startUSec = duration_cast<microseconds>(dur);
}

unsigned long long FarrowTimer::getStopwatchRawTimeMS()
{
	auto dur = steady_clock::now().time_since_epoch();
	milliseconds elapsedMs = duration_cast<milliseconds>(dur) - startMs;
	return elapsedMs.count();
}

unsigned long long FarrowTimer::getStopwatchRawTimeUSec()
{
	auto dur = steady_clock::now().time_since_epoch();
	microseconds elapsedUSecs = duration_cast<microseconds>(dur) - startUSec ;
	return elapsedUSecs.count();
}

/*
FarrowTimeStamp FarrowTimer::getTimeStamp(bool truncateValues)
{
	auto dur = system_clock::now().time_since_epoch();
	milliseconds elapsedMs = duration_cast<milliseconds>(dur) - startMs;

	FarrowTimeStamp returnStamp;

	long long elapsedMsLong = elapsedMs.count();

	
}
*/
string FarrowTimer::convertMSToString(long long ellapsedMillis, bool truncateValues, bool includeMillis)
{
	static long millisPrSecond = 1000;
	static long millisPrMinut = millisPrSecond * 60;
	static long millisPrHour = millisPrMinut * 60;
	static long millisPrDay = millisPrHour * 24;

	long long mSeconds = ellapsedMillis;
	long long seconds = ellapsedMillis / millisPrSecond;
	long minutes = ellapsedMillis / millisPrMinut;
	long hours = ellapsedMillis / millisPrHour;
	long days = ellapsedMillis / millisPrDay;

	if (truncateValues)
	{
		mSeconds %= 1000;
		seconds %= 60;
		minutes %= 60;
		hours %= 24;
	}

	string returnStr = Util::padSomeZerosAtStart(to_string(days)) + "_" +
		Util::padSomeZerosAtStart(to_string(hours)) + "_" +
		Util::padSomeZerosAtStart(to_string(minutes)) + "_" +
		Util::padSomeZerosAtStart(to_string(seconds));
	
	if(includeMillis)
		returnStr += "_" + Util::padSomeZerosAtStart(to_string(mSeconds), 3);


	return returnStr;
}
